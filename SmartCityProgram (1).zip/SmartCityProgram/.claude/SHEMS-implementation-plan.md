# Smart Home Energy Management System (SHEMS) — Python Implementation Plan

Source: Smart-City-Home-Power-Management.pdf
Date saved: 2026-03-20

---

## Problem Statement

Manual home energy management in smart cities creates inefficiency bottlenecks — excessive
consumption, high utility costs, accelerated carbon footprints. 80%+ of residential energy waste
stems from unoptimized usage patterns and lack of real-time feedback.

---

## Project Overview

**Project Name:** Smart Home Energy AI
**Target Demographic:** Urban homeowners and renters aged 25–55 in smart city environments
**Anticipated Outcomes:**
- 30% reduction in household energy bills (Sarah — Eco-Conscious Homeowner)
- 22% decrease in monthly utility spend via off-peak automation (Marcus — Budget Renter)
- 40% drop in emergency demand-response grid interventions (Priya — Grid Manager)

---

## Three User Personas

### Persona 1 — Sarah (Eco-Conscious Homeowner, 34, UX Designer, $75K–$120K)
**Goals:** Reduce carbon footprint measurably, track real-time energy by device, automate
off-peak EV/appliance charging, receive sustainability scores & benchmarks
**Problems:** Fragmented smart home apps (Google, Apple, Zigbee), no visibility into energy
offender devices, sustainability goals hard to quantify
**Solution:** Automated device scheduling, sustainability dashboards, carbon offset tracking
integrated across smart home ecosystems

### Persona 2 — Marcus (Budget-Conscious Renter, 28, Financial Analyst, $45K–$75K)
**Goals:** Lower electricity bills without lifestyle sacrifice, simple actionable tips, understand
peak vs off-peak billing, spending caps + overage alerts instantly
**Constraints:** Cannot install hardware, frequent moves, low willingness to pay
**Solution:** Software-only mobile solution — real-time cost alerts, off-peak nudges, spending
caps (zero hardware required)

### Persona 3 — Priya (Smart City Grid Manager, 45, Grid Operations Manager, $95K–$140K)
**Goals:** Predict residential demand spikes before they occur, push load-shifting incentives,
monitor anomalies across thousands of homes, reduce costly emergency grid interventions
**Problems:** SCADA lacks household-level granularity, no direct consumer communication
during peak events, outdated demand forecasting models
**Solution:** Aggregated demand forecasting dashboard, anomaly detection, automated
demand-response triggers, household-level grid insights

---

## Architecture Decision

**Modular Monolith with Async Event Bus** → evolves to microservices at scale.

- **FastAPI** over Django — async-native, ideal for IoT ingestion + ML inference endpoints
- **PostgreSQL + TimescaleDB** — hypertables for 15-min meter readings at 10K+ household scale
- **Redis + Celery** — task queue for ML jobs, real-time alerts, demand-response triggers
- **Celery Beat** — scheduled ML retraining, off-peak recalculation, anomaly scans
- **Apache Kafka (Phase 2+)** — real-time grid feed ingestion at scale

---

## Project Folder Structure

```
shems/
├── pyproject.toml
├── alembic/
│   ├── env.py
│   └── versions/
├── shems/
│   ├── main.py                        # FastAPI app factory, router registration
│   ├── config.py                      # Pydantic BaseSettings — env-driven config
│   ├── database.py                    # SQLAlchemy async engine, session factory
│   ├── dependencies.py                # FastAPI dependency injectors
│   ├── exceptions.py                  # Global exception handlers
│   ├── core/
│   │   ├── security/
│   │   │   ├── jwt_handler.py
│   │   │   ├── password.py
│   │   │   └── dpdp.py                # Data Protection compliance helpers
│   │   ├── events/
│   │   │   ├── event_bus.py           # Internal pub/sub (Redis Streams)
│   │   │   └── event_types.py         # Typed event dataclasses
│   │   ├── cache/
│   │   │   └── redis_client.py
│   │   └── messaging/
│   │       └── notification_dispatcher.py
│   ├── domains/
│   │   ├── auth/                      # Shared authentication (all personas)
│   │   │   ├── models.py
│   │   │   ├── schemas.py
│   │   │   ├── service.py
│   │   │   ├── manager.py
│   │   │   └── router.py
│   │   ├── household/                 # Sarah — device & consumption tracking
│   │   │   ├── models.py              # Household, Device, EnergyReading
│   │   │   ├── schemas.py
│   │   │   ├── service.py
│   │   │   ├── manager.py
│   │   │   ├── router.py
│   │   │   ├── integrations/
│   │   │   │   ├── base_adapter.py
│   │   │   │   ├── google_home.py
│   │   │   │   ├── apple_homekit.py
│   │   │   │   └── zigbee_adapter.py
│   │   │   └── tasks.py               # Celery: schedule devices, poll readings
│   │   ├── sustainability/            # Sarah — carbon & sustainability scoring
│   │   │   ├── models.py              # CarbonScore, SustainabilityBenchmark
│   │   │   ├── schemas.py
│   │   │   ├── service.py
│   │   │   ├── manager.py
│   │   │   └── router.py
│   │   ├── billing/                   # Marcus — cost tracking & alerts
│   │   │   ├── models.py              # BillingPeriod, SpendingCap, OverageAlert
│   │   │   ├── schemas.py
│   │   │   ├── service.py
│   │   │   ├── manager.py
│   │   │   ├── router.py
│   │   │   └── tasks.py               # Celery: real-time spend monitoring
│   │   ├── tariff/                    # Shared — peak/off-peak rate engine
│   │   │   ├── models.py              # TariffZone, RateWindow, PeakSchedule
│   │   │   ├── schemas.py
│   │   │   ├── service.py
│   │   │   └── manager.py
│   │   └── grid/                      # Priya — grid management & demand response
│   │       ├── models.py              # GridZone, DemandEvent, AnomalyAlert, LoadForecast
│   │       ├── schemas.py
│   │       ├── service.py
│   │       ├── manager.py
│   │       ├── router.py
│   │       └── tasks.py               # Celery: DR triggers, anomaly scans
│   ├── ml/
│   │   ├── pipelines/
│   │   │   ├── anomaly_detection/
│   │   │   │   ├── trainer.py
│   │   │   │   ├── predictor.py
│   │   │   │   └── feature_engineering.py
│   │   │   ├── demand_forecasting/
│   │   │   │   ├── trainer.py
│   │   │   │   ├── predictor.py
│   │   │   │   └── feature_engineering.py
│   │   │   └── sustainability_scoring/
│   │   │       ├── scorer.py
│   │   │       └── benchmark_calculator.py
│   │   ├── model_registry.py          # MLflow model versioning interface
│   │   ├── feature_store.py           # Feature computation & caching
│   │   └── router.py                  # Internal ML inference endpoints
│   └── ingest/
│       ├── smart_meter_ingestor.py    # 15-min meter reading handler
│       ├── grid_feed_consumer.py      # Real-time grid load feed (Kafka consumer)
│       ├── schemas.py
│       └── router.py
├── tests/
│   ├── unit/
│   │   ├── domains/
│   │   └── ml/
│   ├── integration/
│   │   ├── test_billing_alerts.py
│   │   └── test_demand_response.py
│   └── conftest.py
├── scripts/
│   ├── seed_synthetic_data.py
│   └── backfill_features.py
└── docker/
    ├── Dockerfile
    ├── docker-compose.yml
    └── docker-compose.test.yml
```

---

## Tech Stack

| Layer             | Choice                        | Justification                                              |
|-------------------|-------------------------------|------------------------------------------------------------|
| Web framework     | FastAPI 0.111+                | Async-native, auto OpenAPI docs, Pydantic v2               |
| ORM               | SQLAlchemy 2.0 (async)        | Async sessions, works cleanly with Alembic                 |
| DB migrations     | Alembic                       | Flexible multi-schema TS workload migrations               |
| Database          | PostgreSQL 16 + TimescaleDB   | Hypertables for time-series meter readings                 |
| Cache / Broker    | Redis 7                       | Celery broker + result backend + dashboard cache           |
| Task queue        | Celery 5 + Celery Beat        | Scheduled ML jobs, DR triggers, alert dispatch             |
| Data validation   | Pydantic v2                   | FastAPI native; 5-17x faster than v1 via Rust core        |
| ML — forecasting  | Prophet + scikit-learn        | Seasonal energy patterns; sklearn for feature pipelines    |
| ML — anomaly      | Isolation Forest + PyOD       | Unsupervised; handles multivariate meter streams           |
| ML — deep learning| PyTorch (LSTM)                | 15-min sequence demand forecasting at grid scale (Phase 3) |
| ML tracking       | MLflow                        | Model versioning, experiment comparison, registry API      |
| Feature engineering| Pandas + Polars              | Pandas for training; Polars for high-throughput real-time  |
| IoT integration   | paho-mqtt + httpx             | MQTT for Zigbee/Z-Wave; httpx for Google Home/HomeKit APIs |
| Real-time streaming| aiokafka                     | Async Kafka consumer for grid load feed                    |
| Authentication    | python-jose + passlib         | JWT tokens, bcrypt password hashing                        |
| Notifications     | Firebase Admin + Twilio       | Push (Marcus mobile-first), SMS for critical grid alerts   |
| Testing           | pytest + pytest-asyncio + factory-boy | Async test support, fixture factories             |
| Compliance        | Custom middleware              | DPDP request audit logging, PII masking, data retention    |

---

## Data Models

### Auth Domain (Shared)
```python
class User(Base):
    id: UUID (PK)
    email: str (unique, indexed)
    hashed_password: str
    persona_type: Enum("HOMEOWNER", "RENTER", "GRID_MANAGER")
    is_active: bool
    is_verified: bool
    created_at: datetime

class Session(Base):
    id: UUID (PK)
    user_id: UUID (FK -> users)
    token_hash: str
    device_fingerprint: str
    expires_at: datetime
```

### Household Domain (Sarah)
```python
class Household(Base):
    id: UUID (PK)
    user_id: UUID (FK -> users)
    address_hash: str           # PII hashed for DPDP compliance
    district_id: UUID
    smart_meter_id: str
    ecosystem_type: Enum("GOOGLE_HOME", "APPLE_HOMEKIT", "ZIGBEE", "MANUAL")
    square_footage: int
    occupant_count: int

class Device(Base):
    id: UUID (PK)
    household_id: UUID (FK)
    external_device_id: str
    name: str
    device_type: Enum("EV_CHARGER", "HVAC", "WASHER", "DRYER", "DISHWASHER", "LIGHTING", "OTHER")
    rated_power_watts: float
    is_schedulable: bool
    ecosystem: Enum("GOOGLE_HOME", "APPLE_HOMEKIT", "ZIGBEE", "MANUAL")

class EnergyReading(Base):                # TimescaleDB hypertable on timestamp
    id: UUID (PK)
    household_id: UUID (FK)
    device_id: UUID (FK, nullable)
    timestamp: datetime (partition key)
    consumption_kwh: float
    cost_estimate_inr: float
    is_peak_hour: bool
    source: Enum("SMART_METER", "DEVICE_API", "MANUAL_ENTRY")

class DeviceSchedule(Base):
    id: UUID (PK)
    device_id: UUID (FK)
    schedule_type: Enum("OFF_PEAK_AUTO", "MANUAL", "AI_SUGGESTED")
    start_time: time
    end_time: time
    days_of_week: JSON
    is_active: bool
    created_by_ai: bool
```

### Sustainability Domain (Sarah)
```python
class CarbonScore(Base):
    id: UUID (PK)
    household_id: UUID (FK)
    period_start: datetime
    period_end: datetime
    total_kwh: float
    carbon_kg_co2e: float       # kwh * grid emission factor
    score: float                # 0-100 sustainability index
    percentile_rank: float      # vs district peers

class SustainabilityBenchmark(Base):
    id: UUID (PK)
    district_id: UUID
    period: str                 # "2025-Q1"
    avg_consumption_kwh: float
    median_carbon_kg: float
    top_10pct_threshold_kwh: float

class CarbonOffsetGoal(Base):
    id: UUID (PK)
    household_id: UUID (FK)
    target_reduction_pct: float
    baseline_carbon_kg: float
    target_carbon_kg: float
    deadline: date
    current_progress_pct: float
    status: Enum("ACTIVE", "ACHIEVED", "MISSED")
```

### Billing Domain (Marcus)
```python
class BillingAccount(Base):
    id: UUID (PK)
    user_id: UUID (FK)
    utility_provider: str
    meter_reference: str        # Soft link — no hardware install required
    billing_cycle_day: int
    currency: str = "INR"

class SpendingCap(Base):
    id: UUID (PK)
    billing_account_id: UUID (FK)
    monthly_cap_inr: float
    warning_threshold_pct: float
    is_active: bool

class OverageAlert(Base):
    id: UUID (PK)
    billing_account_id: UUID (FK)
    alert_type: Enum("WARNING_THRESHOLD", "CAP_REACHED", "PEAK_SPIKE")
    triggered_at: datetime
    current_spend_inr: float
    cap_inr: float
    notification_sent: bool
    channel: Enum("PUSH", "SMS", "EMAIL")

class UsageSummary(Base):       # Materialized by Celery, not computed on-read
    id: UUID (PK)
    billing_account_id: UUID (FK)
    period_date: date
    total_kwh: float
    peak_kwh: float
    off_peak_kwh: float
    estimated_cost_inr: float
    potential_savings_inr: float
```

### Tariff Domain (Shared)
```python
class TariffZone(Base):
    id: UUID (PK)
    district_id: UUID
    utility_provider: str
    currency: str

class RateWindow(Base):
    id: UUID (PK)
    tariff_zone_id: UUID (FK)
    window_type: Enum("PEAK", "OFF_PEAK", "SUPER_OFF_PEAK")
    start_time: time
    end_time: time
    days_of_week: JSON
    rate_per_kwh: float
    effective_from: date
    effective_until: date  # nullable
```

### Grid Domain (Priya)
```python
class GridZone(Base):
    id: UUID (PK)
    zone_name: str
    district_code: str
    city: str
    total_households: int
    peak_capacity_kw: float

class GridLoadReading(Base):    # TimescaleDB hypertable
    id: UUID (PK)
    zone_id: UUID (FK)
    timestamp: datetime (partition key)
    current_load_kw: float
    capacity_utilization_pct: float
    source: Enum("SCADA", "SYNTHETIC", "ESTIMATED")

class DemandForecast(Base):
    id: UUID (PK)
    zone_id: UUID (FK)
    forecast_timestamp: datetime
    horizon_hours: int          # 1, 6, 24, 48
    predicted_load_kw: float
    confidence_lower: float
    confidence_upper: float
    model_version: str

class AnomalyAlert(Base):
    id: UUID (PK)
    zone_id: UUID (FK)
    household_id: UUID (FK, nullable)
    detected_at: datetime
    anomaly_type: Enum("CONSUMPTION_SPIKE", "METER_FAULT", "UNUSUAL_PATTERN", "GRID_STRESS")
    severity: Enum("LOW", "MEDIUM", "HIGH", "CRITICAL")
    anomaly_score: float
    is_acknowledged: bool

class DemandResponseEvent(Base):
    id: UUID (PK)
    zone_id: UUID (FK)
    triggered_by: UUID (FK -> users)
    trigger_type: Enum("MANUAL", "AUTOMATED_ML", "SCHEDULED")
    status: Enum("PENDING", "ACTIVE", "COMPLETED", "CANCELLED")
    target_load_reduction_kw: float
    actual_load_reduction_kw: float  # nullable — filled on completion
    households_targeted: int
    incentive_offer_inr: float
    started_at: datetime
    ended_at: datetime  # nullable
```

---

## ML Pipeline Design

### Anomaly Detection
- **Algorithm:** Isolation Forest (primary) + DBSCAN (secondary for cluster anomalies)
- **Features per 15-min window:** `kwh_current`, `kwh_rolling_mean_7d`, `kwh_z_score`,
  `is_peak_hour`, `day_of_week` (cyclic), `hour_of_day` (cyclic), `outdoor_temp_c`,
  `occupant_count`
- **Training:** One model per household cluster (grouped by size + occupants); weekly retraining
- **Inference:** Celery task every 15 min after meter ingestion
- **Severity thresholds:** score < -0.1 → LOW | < -0.2 → MEDIUM | < -0.35 → HIGH | < -0.5 → CRITICAL

### Demand Forecasting
- **Algorithm:** Prophet (Phase 1–2) → LSTM (Phase 3)
- **Prophet config:** multiplicative seasonality, daily/weekly/yearly, temperature + holiday regressors
- **LSTM:** 2-layer (hidden=256) + Dropout(0.2) + Linear(1); 96-step input (24h); PyTorch Lightning
- **Inference:** Celery Beat hourly; 4 horizons per zone; auto-DR trigger at 85% capacity forecast

### Sustainability Scoring
- **Algorithm:** Deterministic rule-based (explainable) + peer benchmarking
- **Formula:** `carbon_kg = kwh × district_emission_factor`
  `score = 0.6 × raw_score + 0.4 × percentile_rank`
- **Schedule:** Nightly Celery job at 00:30; push notification on 5-point improvement

### Feature Store
- **Hot tier:** Redis cache with 15-min TTL — real-time features for inference
- **Warm tier:** TimescaleDB continuous aggregates — hourly/daily rollups pre-computed

---

## API Endpoints

### Authentication (All Personas)
```
POST   /api/v1/auth/signup
POST   /api/v1/auth/login
POST   /api/v1/auth/logout
POST   /api/v1/auth/refresh
POST   /api/v1/auth/validate-token
```

### Sarah — Household & Sustainability
```
GET/PUT  /api/v1/households/me
GET/POST /api/v1/households/me/devices
DELETE   /api/v1/households/me/devices/{device_id}
GET      /api/v1/households/me/devices/{device_id}/readings
GET      /api/v1/households/me/readings?from=&to=&granularity=15m|1h|1d
POST     /api/v1/households/me/sync          # Trigger ecosystem sync
GET/POST /api/v1/households/me/schedules
PUT/DELETE /api/v1/households/me/schedules/{id}
POST     /api/v1/households/me/schedules/ai-suggest

GET      /api/v1/sustainability/me/score?period=daily|weekly|monthly
GET      /api/v1/sustainability/me/carbon-history?from=&to=
GET      /api/v1/sustainability/me/benchmark
GET/POST /api/v1/sustainability/me/goals
PUT      /api/v1/sustainability/me/goals/{id}
GET      /api/v1/sustainability/me/device-offenders
```

### Marcus — Billing & Tariff
```
GET/POST/PUT /api/v1/billing/me/account
GET/POST/PUT /api/v1/billing/me/spending-cap
GET      /api/v1/billing/me/alerts
GET      /api/v1/billing/me/alerts/active
GET      /api/v1/billing/me/usage?period=today|week|month|custom
GET      /api/v1/billing/me/usage/breakdown       # Peak vs off-peak split
GET      /api/v1/billing/me/usage/potential-savings
GET      /api/v1/billing/me/tips                  # Top-3 actionable savings tips

GET      /api/v1/tariff/current
GET      /api/v1/tariff/schedule?days=7
```

### Priya — Grid Management
```
GET      /api/v1/grid/zones
GET      /api/v1/grid/zones/{zone_id}
GET      /api/v1/grid/zones/{zone_id}/load-history?from=&to=
GET      /api/v1/grid/zones/{zone_id}/households
GET      /api/v1/grid/zones/{zone_id}/forecast?horizon=1h|6h|24h|48h
GET      /api/v1/grid/zones/{zone_id}/forecast/history

GET      /api/v1/grid/anomalies?zone_id=&severity=&status=
GET      /api/v1/grid/anomalies/{alert_id}
PUT      /api/v1/grid/anomalies/{alert_id}/acknowledge

GET/POST /api/v1/grid/demand-response/events
GET      /api/v1/grid/demand-response/events/{id}
PUT      /api/v1/grid/demand-response/events/{id}/cancel
GET      /api/v1/grid/demand-response/events/{id}/participation

POST     /api/v1/ingest/meter-reading            # Smart meter webhook
POST     /api/v1/ingest/grid-load                # Grid feed push endpoint
```

---

## Design Patterns

| Pattern | Location | Purpose |
|---|---|---|
| Repository/Manager | `domains/*/manager.py` | DB access layer; mirrors existing userManager.py convention |
| Strategy | `household/integrations/` | Swappable IoT adapters (Google/Apple/Zigbee) via `BaseEcosystemAdapter` |
| Factory | `ml/model_registry.py` | Abstract MLflow model loading from inference code |
| Observer/Event Bus | `core/events/event_bus.py` | Cross-domain side effects: anomaly → notify Priya; spike → auto-DR |
| Dependency Injection | All `router.py` files | FastAPI `Depends()` for thin routes — session, user, service |

---

## Development Phases

### Phase 1 — Foundation (Weeks 1–4)
**Goal:** Auth + household + billing + ingest pipeline running

- **Week 1:** FastAPI app factory, SQLAlchemy async, Alembic migrations for auth + household + billing. Docker Compose (Postgres+TimescaleDB, Redis).
- **Week 2:** Auth domain complete (signup, login, JWT, persona routing). Household device CRUD.
- **Week 3:** Tariff domain seed data (5 districts). Billing service — rolling cost computation. Spending cap + Celery alert task every 15 min.
- **Week 4:** IoT ingest router (smart meter webhook → EnergyReading hypertable). Synthetic data seed script (3yr/10K households with `faker`). Integration tests for billing alert flow.

**Milestone:** Marcus can register, link a meter ID, set a spending cap, and receive alerts. Sarah can register a household and devices.

### Phase 2 — Intelligence Layer (Weeks 5–8)
**Goal:** ML pipelines operational, sustainability scoring live, grid domain for Priya

- **Week 5:** ML feature store + anomaly detection trainer. Isolation Forest on synthetic dataset. Predictor in 15-min Celery task.
- **Week 6:** Demand forecasting with Prophet — per-zone trainer + hourly Celery Beat inference.
- **Week 7:** Sustainability scoring nightly pipeline. Sarah's sustainability API endpoints.
- **Week 8:** Grid domain — `AnomalyAlert`, `DemandResponseEvent` APIs. Priya's dashboard endpoints. Auto-DR trigger on 85% capacity forecast breach.

**Milestone:** Priya's demand forecasting dashboard live. Sarah sees sustainability scores + device offender rankings. Anomaly alerts firing.

### Phase 3 — Integrations + Real-Time (Weeks 9–12)
**Goal:** IoT ecosystem integration, real-time notifications, AI scheduling

- **Week 9:** Google Home + Apple HomeKit adapters (OAuth + device polling). Zigbee2MQTT bridge via MQTT.
- **Week 10:** Firebase push (Marcus spending alerts, Sarah sustainability milestones). Twilio SMS for critical grid alerts to Priya.
- **Week 11:** AI-generated off-peak schedule suggestions for Sarah. Device schedule automation via Celery + device API commands.
- **Week 12:** aiokafka consumer for real-time grid load feed. DPDP compliance middleware — audit logging, PII masking, data retention enforcement.

**Milestone:** Full end-to-end: IoT device → smart meter → anomaly detection → demand-response trigger → household notification.

### Phase 4 — Hardening + Scale (Weeks 13–16)
**Goal:** Production readiness, LSTM model, performance optimization

- **Week 13:** LSTM demand forecasting (PyTorch Lightning) — replaces Prophet for 1h/6h horizons.
- **Week 14:** TimescaleDB continuous aggregates for hourly/daily rollups. Redis cache-aside for dashboards. Load testing with Locust.
- **Week 15:** Full test coverage — unit (service layers), integration (cross-domain flows), async path tests.
- **Week 16:** API docs review, security audit (JWT expiry, rate limiting via `slowapi`), Docker health checks, deployment pipeline.

**Milestone:** Production-ready system. 30% bill reduction measurable in simulation. 40% DR intervention reduction in backtesting.

---

## Testing Strategy

```
           /\
          /  \   E2E (5%) — Full API → DB → notification flow
         /----\
        /      \  Integration (25%) — Async DB + Celery eager mode + factory-boy
       /--------\
      /          \ Unit (70%) — Service logic with mocked Managers;
     /            \             ML scorer with fixture DataFrames
    /______________\
```

**Coverage targets:**
- `domains/*/service.py` — 90%+ unit coverage
- `domains/*/manager.py` — 80%+ integration coverage
- `ml/pipelines/*/predictor.py` — 85%+ unit coverage with fixture models
- `ml/pipelines/*/trainer.py` — smoke tests only (nightly CI, not per-PR)

**DPDP compliance test:**
```python
def test_address_not_stored_in_plaintext(household_response):
    assert "address" not in household_response.keys()
    assert "address_hash" in household_response.keys()
    assert len(household_response["address_hash"]) == 64  # SHA-256 hex digest
```

---

## Technical Data Requirements

- Anonymized smart meter IoT sensor logs at 15-minute granularity
- Minimum 3 years of consumption data across 10,000+ households in 5+ smart city districts
- Real-time grid load feed required for dynamic demand-response scaling
- Security: sandboxed environment, DPDP-compliant data handling, access via Secure API

**Available now:** Open-source grid topology data (OGD), synthetic consumption datasets
**Needed:** AlkIsh-facilitated smart meter records for localized model accuracy
