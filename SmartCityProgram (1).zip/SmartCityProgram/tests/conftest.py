"""
Pytest fixtures for async integration tests.

Requirements:
  - A running PostgreSQL+TimescaleDB instance at TEST_DATABASE_URL
  - Run: docker compose -f docker/docker-compose.yml up db -d
"""
import asyncio
import os
import uuid
from datetime import date, datetime, timezone

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from shems.database import Base
from shems.domains.auth.models import PersonaType, User
from shems.domains.billing.models import BillingAccount, SpendingCap, UsageSummary
from shems.domains.household.models import EnergyReading, Household
from shems.domains.tariff.models import TariffZone

TEST_DATABASE_URL = os.getenv(
    "TEST_DATABASE_URL",
    "postgresql+asyncpg://shems:shems@localhost:5432/shems_test",
)


@pytest.fixture(scope="session")
def event_loop():
    policy = asyncio.get_event_loop_policy()
    loop = policy.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="session")
async def test_engine():
    engine = create_async_engine(TEST_DATABASE_URL, echo=False)
    async with engine.begin() as conn:
        # Enable timescaledb if available; ignore error in plain Postgres
        try:
            await conn.execute(__import__("sqlalchemy").text("CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;"))
        except Exception:
            pass
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest_asyncio.fixture
async def db(test_engine) -> AsyncSession:
    session_factory = async_sessionmaker(test_engine, class_=AsyncSession, expire_on_commit=False)
    async with session_factory() as session:
        yield session
        await session.rollback()


@pytest_asyncio.fixture
async def client(test_engine):
    from shems.dependencies import get_db
    from shems.main import app

    session_factory = async_sessionmaker(test_engine, class_=AsyncSession, expire_on_commit=False)

    async def override_get_db():
        async with session_factory() as session:
            try:
                yield session
            finally:
                await session.close()

    app.dependency_overrides[get_db] = override_get_db
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac
    app.dependency_overrides.clear()


# ── Factory helpers ──────────────────────────────────────────────────────────

async def create_test_user(
    db: AsyncSession,
    email: str = "test@example.com",
    persona_type: PersonaType = PersonaType.RENTER,
    password: str = "testpassword123",
) -> User:
    from shems.core.security.password import hash_password
    user = User(
        email=email,
        hashed_password=hash_password(password),
        persona_type=persona_type,
        is_active=True,
        is_verified=True,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


async def create_test_household(
    db: AsyncSession,
    user_id: uuid.UUID,
    smart_meter_id: str = "METER001",
) -> Household:
    household = Household(
        user_id=user_id,
        address_hash="a" * 64,
        smart_meter_id=smart_meter_id,
    )
    db.add(household)
    await db.commit()
    await db.refresh(household)
    return household


async def create_test_billing_account(
    db: AsyncSession,
    user_id: uuid.UUID,
) -> BillingAccount:
    account = BillingAccount(
        user_id=user_id,
        utility_provider="Test Utility",
        billing_cycle_day=1,
        currency="INR",
    )
    db.add(account)
    await db.commit()
    await db.refresh(account)
    return account


async def create_test_spending_cap(
    db: AsyncSession,
    billing_account_id: uuid.UUID,
    monthly_cap_inr: float = 1000.0,
    warning_threshold_pct: float = 80.0,
) -> SpendingCap:
    cap = SpendingCap(
        billing_account_id=billing_account_id,
        monthly_cap_inr=monthly_cap_inr,
        warning_threshold_pct=warning_threshold_pct,
        is_active=True,
    )
    db.add(cap)
    await db.commit()
    await db.refresh(cap)
    return cap


async def inject_usage_summaries(
    db: AsyncSession,
    billing_account_id: uuid.UUID,
    total_spend_inr: float,
    days: int = 5,
) -> None:
    per_day = total_spend_inr / days
    today = date.today()
    for i in range(days):
        d = date(today.year, today.month, max(1, today.day - i))
        summary = UsageSummary(
            billing_account_id=billing_account_id,
            period_date=d,
            total_kwh=per_day / 8.0,
            peak_kwh=(per_day / 8.0) * 0.6,
            off_peak_kwh=(per_day / 8.0) * 0.4,
            estimated_cost_inr=per_day,
            potential_savings_inr=per_day * 0.15,
        )
        db.add(summary)
    await db.commit()
