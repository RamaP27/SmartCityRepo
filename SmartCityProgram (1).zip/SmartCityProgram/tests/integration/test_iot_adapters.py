"""
Integration tests for IoT ecosystem adapters (Phase 3 — Week 9).

Tests use:
  - ManualAdapter (no external I/O)
  - GoogleHomeAdapter / AppleHomeKitAdapter with respx HTTP mocking
  - ZigbeeAdapter with a mock paho-mqtt client
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from shems.domains.household.integrations.base_adapter import (
    DeviceCommand,
    DeviceState,
)
from shems.domains.household.integrations.manual_adapter import ManualAdapter
from shems.domains.household.integrations.google_home import GoogleHomeAdapter
from shems.domains.household.integrations.apple_homekit import AppleHomeKitAdapter
from shems.domains.household.integrations.adapter_factory import AdapterFactory


# ── ManualAdapter ─────────────────────────────────────────────────────────────

class TestManualAdapter:
    @pytest.mark.asyncio
    async def test_authenticate_always_succeeds(self):
        adapter = ManualAdapter()
        assert await adapter.authenticate({}) is True

    @pytest.mark.asyncio
    async def test_discover_returns_empty(self):
        adapter = ManualAdapter()
        devices = await adapter.discover_devices(uuid.uuid4())
        assert devices == []

    @pytest.mark.asyncio
    async def test_get_device_state_returns_none(self):
        adapter = ManualAdapter()
        state = await adapter.get_device_state("device-123")
        assert state is None

    @pytest.mark.asyncio
    async def test_send_command_returns_true(self):
        adapter = ManualAdapter()
        result = await adapter.send_command(
            DeviceCommand(external_device_id="dev1", action="on")
        )
        assert result is True

    @pytest.mark.asyncio
    async def test_turn_on_off_helpers(self):
        adapter = ManualAdapter()
        assert await adapter.turn_on("dev1") is True
        assert await adapter.turn_off("dev1") is True


# ── AdapterFactory ────────────────────────────────────────────────────────────

class TestAdapterFactory:
    def test_creates_manual_adapter(self):
        adapter = AdapterFactory.create("MANUAL")
        assert adapter.ecosystem_name == "MANUAL"

    def test_creates_zigbee_adapter(self):
        adapter = AdapterFactory.create("ZIGBEE")
        assert adapter.ecosystem_name == "ZIGBEE"

    def test_creates_apple_homekit_adapter(self):
        adapter = AdapterFactory.create("APPLE_HOMEKIT")
        assert adapter.ecosystem_name == "APPLE_HOMEKIT"

    def test_unknown_ecosystem_raises(self):
        with pytest.raises(ValueError, match="Unsupported ecosystem"):
            AdapterFactory.create("UNKNOWN_ECOSYSTEM")

    def test_case_insensitive(self):
        adapter = AdapterFactory.create("manual")
        assert adapter.ecosystem_name == "MANUAL"


# ── GoogleHomeAdapter (mocked HTTP) ──────────────────────────────────────────

class TestGoogleHomeAdapter:
    @pytest.fixture
    def adapter(self):
        return GoogleHomeAdapter(
            client_id="test-client",
            client_secret="test-secret",
            project_id="test-project",
        )

    @pytest.mark.asyncio
    async def test_authenticate_with_valid_refresh_token(self, adapter):
        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_resp = MagicMock()
            mock_resp.is_success = True
            mock_resp.json.return_value = {"access_token": "new-token"}
            mock_client = MagicMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(return_value=mock_resp)
            mock_client_cls.return_value = mock_client

            result = await adapter.authenticate({"refresh_token": "rt-123"})
            assert result is True
            assert adapter._access_token == "new-token"

    @pytest.mark.asyncio
    async def test_authenticate_without_refresh_token_fails(self, adapter):
        result = await adapter.authenticate({})
        assert result is False

    @pytest.mark.asyncio
    async def test_discover_devices_parses_response(self, adapter):
        adapter._access_token = "test-token"
        mock_response = {
            "devices": [
                {
                    "name": "enterprises/proj/devices/dev1",
                    "displayName": "Living Room Thermostat",
                    "traits": {
                        "sdm.devices.traits.Connectivity": {"status": "ONLINE"},
                    },
                }
            ]
        }
        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_resp = MagicMock()
            mock_resp.is_success = True
            mock_resp.json.return_value = mock_response
            mock_resp.status_code = 200
            mock_client = MagicMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.get = AsyncMock(return_value=mock_resp)
            mock_client_cls.return_value = mock_client

            devices = await adapter.discover_devices(uuid.uuid4())
            assert len(devices) == 1
            assert devices[0].name == "Living Room Thermostat"
            assert devices[0].is_on is True

    @pytest.mark.asyncio
    async def test_send_on_command(self, adapter):
        adapter._access_token = "test-token"
        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_resp = MagicMock()
            mock_resp.is_success = True
            mock_resp.status_code = 200
            mock_client = MagicMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(return_value=mock_resp)
            mock_client_cls.return_value = mock_client

            result = await adapter.send_command(
                DeviceCommand(external_device_id="enterprises/proj/devices/dev1", action="on")
            )
            assert result is True

    def test_parse_online_device(self, adapter):
        raw = {
            "name": "enterprises/proj/devices/dev1",
            "displayName": "Smart Plug",
            "traits": {"sdm.devices.traits.Connectivity": {"status": "ONLINE"}},
        }
        state = adapter._parse_device(raw)
        assert state is not None
        assert state.is_on is True
        assert state.external_device_id == "enterprises/proj/devices/dev1"

    def test_parse_offline_device(self, adapter):
        raw = {
            "name": "enterprises/proj/devices/dev2",
            "displayName": "Offline Device",
            "traits": {"sdm.devices.traits.Connectivity": {"status": "OFFLINE"}},
        }
        state = adapter._parse_device(raw)
        assert state is not None
        assert state.is_on is False

    def test_build_on_command(self, adapter):
        cmd = DeviceCommand(external_device_id="dev1", action="on")
        payload = adapter._build_sdm_command(cmd)
        assert payload is not None
        assert payload["params"]["on"] is True

    def test_build_off_command(self, adapter):
        cmd = DeviceCommand(external_device_id="dev1", action="off")
        payload = adapter._build_sdm_command(cmd)
        assert payload["params"]["on"] is False

    def test_unsupported_action_returns_none(self, adapter):
        cmd = DeviceCommand(external_device_id="dev1", action="unknown_action")
        payload = adapter._build_sdm_command(cmd)
        assert payload is None


# ── AppleHomeKitAdapter (mocked HTTP) ────────────────────────────────────────

class TestAppleHomeKitAdapter:
    @pytest.fixture
    def adapter(self):
        a = AppleHomeKitAdapter()
        a._bridge_url = "http://192.168.1.100:8581"
        a._api_key = "test-key"
        return a

    @pytest.mark.asyncio
    async def test_send_on_command(self, adapter):
        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_resp = MagicMock()
            mock_resp.is_success = True
            mock_client = MagicMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.put = AsyncMock(return_value=mock_resp)
            mock_client_cls.return_value = mock_client

            result = await adapter.send_command(
                DeviceCommand(external_device_id="acc-1", action="on")
            )
            assert result is True

    def test_parse_accessory_with_on_char(self, adapter):
        acc = {
            "uniqueId": "acc-42",
            "serviceName": "Smart Plug",
            "serviceCharacteristics": [
                {"type": "25", "value": True},
                {"type": "E3", "value": 120.5},
            ],
        }
        state = adapter._parse_accessory(acc)
        assert state is not None
        assert state.is_on is True
        assert state.power_watts == 120.5
        assert state.external_device_id == "acc-42"

    def test_parse_empty_accessory_returns_none(self, adapter):
        state = adapter._parse_accessory({})
        assert state is None
