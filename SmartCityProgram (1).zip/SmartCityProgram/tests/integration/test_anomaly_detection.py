"""
Integration tests for anomaly detection pipeline.

Tests the feature engineering, model training, and prediction flow
using in-memory data (no TimescaleDB required beyond schema creation).
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
import pytest

from shems.ml.pipelines.anomaly_detection.feature_engineering import (
    FEATURE_COLS,
    build_features,
    latest_window_features,
)
from shems.ml.pipelines.anomaly_detection.predictor import (
    AnomalyResult,
    _score_to_severity,
    score_household,
)
from shems.ml.pipelines.anomaly_detection.trainer import (
    AnomalyBundle,
    _fit as _fit_cluster,
)


# ── Fixtures ─────────────────────────────────────────────────────────────────

def _make_readings(n: int = 2500, spike_at: int | None = None) -> pd.DataFrame:
    """Generates synthetic 15-min household readings."""
    rng = np.random.default_rng(42)
    base = datetime(2025, 1, 1, tzinfo=timezone.utc)
    timestamps = [base + timedelta(minutes=15 * i) for i in range(n)]
    consumption = rng.normal(loc=1.5, scale=0.4, size=n).clip(0.1)

    if spike_at is not None and 0 <= spike_at < n:
        consumption[spike_at] = 25.0   # massive spike

    return pd.DataFrame({
        "timestamp": timestamps,
        "consumption_kwh": consumption,
        "is_peak_hour": [1.0 if 6 <= t.hour < 22 else 0.0 for t in timestamps],
    })


# ── Feature engineering tests ─────────────────────────────────────────────────

class TestAnomalyFeatureEngineering:
    def test_build_features_shape(self):
        df = _make_readings(500)
        features = build_features(df)
        assert not features.empty
        for col in FEATURE_COLS:
            assert col in features.columns, f"Missing feature column: {col}"

    def test_cyclic_encoding_bounds(self):
        df = _make_readings(200)
        features = build_features(df)
        for col in ("hour_sin", "hour_cos", "day_sin", "day_cos"):
            assert features[col].between(-1.01, 1.01).all(), f"{col} out of [-1, 1]"

    def test_z_score_clipped(self):
        df = _make_readings(500, spike_at=400)
        features = build_features(df)
        assert features["z_score"].between(-10, 10).all()

    def test_no_nans_in_feature_cols(self):
        df = _make_readings(600)
        features = build_features(df)
        assert features[FEATURE_COLS].isna().sum().sum() == 0

    def test_latest_window_features_single_row(self):
        df = _make_readings(200)
        features = latest_window_features(df)
        assert len(features) == 1
        for col in FEATURE_COLS:
            assert col in features.columns

    def test_empty_df_returns_empty(self):
        features = build_features(pd.DataFrame())
        assert features.empty

    def test_latest_window_empty_input(self):
        features = latest_window_features(pd.DataFrame())
        assert features.empty


# ── Severity thresholds ───────────────────────────────────────────────────────

class TestSeverityMapping:
    @pytest.mark.parametrize("score,expected", [
        (-0.55, "CRITICAL"),
        (-0.40, "HIGH"),
        (-0.25, "MEDIUM"),
        (-0.15, "LOW"),
        (-0.05, None),
        (0.10, None),
    ])
    def test_score_to_severity(self, score, expected):
        assert _score_to_severity(score) == expected


# ── Training ──────────────────────────────────────────────────────────────────

class TestAnomalyTraining:
    def test_fit_produces_bundle(self):
        df = _make_readings(3000)
        bundle = _fit_cluster(df)
        assert isinstance(bundle, AnomalyBundle)

    def test_bundle_score_returns_values(self):
        df = _make_readings(3000)
        bundle = _fit_cluster(df)
        features = build_features(df)
        scores = bundle.score(features.tail(10))
        assert len(scores) == 10

    def test_spike_scores_lower(self):
        """A data spike row should have a lower (more anomalous) score."""
        normal_df = _make_readings(3000)
        bundle = _fit_cluster(normal_df, cluster_key="medium_1-2")

        spike_df = _make_readings(500, spike_at=490)
        spike_features = build_features(spike_df)

        normal_features = build_features(normal_df)
        normal_score = float(bundle.score(normal_features.tail(1))[0])
        spike_score = float(bundle.score(spike_features.tail(1))[0])

        # Spike row should score lower (more anomalous)
        assert spike_score < normal_score


# ── Prediction ────────────────────────────────────────────────────────────────

class TestAnomalyPredictor:
    def test_score_household_no_model_returns_none_severity(self):
        """When no model exists for a cluster, severity should be None."""
        hh_id = uuid.uuid4()
        recent_df = _make_readings(200)
        result = score_household(hh_id, "nonexistent_cluster_xyz", recent_df)
        assert isinstance(result, AnomalyResult)
        assert result.severity is None
        assert result.anomaly_score == 0.0

    def test_score_household_empty_df_returns_none_severity(self):
        hh_id = uuid.uuid4()
        result = score_household(hh_id, "medium_3-4", pd.DataFrame())
        assert result.severity is None
