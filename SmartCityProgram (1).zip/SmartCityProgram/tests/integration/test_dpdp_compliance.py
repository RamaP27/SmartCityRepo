"""
Tests for DPDP compliance layer (Phase 3 — Week 12).

Covers:
  - AuditLogMiddleware writes structured records
  - PIIMaskingFilter masks sensitive fields in logs
  - DataRetentionManager correctly identifies purgeable records
  - Address hash validation (no plaintext address in API responses)
"""
from __future__ import annotations

import json
import logging
import tempfile
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from shems.core.security.dpdp import (
    DataRetentionManager,
    PIIMaskingFilter,
    _PII_PATTERNS,
)


# ── PIIMaskingFilter ──────────────────────────────────────────────────────────

class TestPIIMaskingFilter:
    def _apply(self, message: str) -> str:
        record = logging.LogRecord(
            name="test", level=logging.INFO,
            pathname="", lineno=0,
            msg=message, args=(), exc_info=None,
        )
        f = PIIMaskingFilter()
        f.filter(record)
        return record.msg

    def test_masks_password_field(self):
        msg = '{"email": "user@example.com", "password": "secret123"}'
        masked = self._apply(msg)
        assert "secret123" not in masked
        assert '"password": "***"' in masked

    def test_masks_access_token(self):
        msg = '{"access_token": "eyJhbGciOiJIUzI1NiJ9.payload.sig"}'
        masked = self._apply(msg)
        assert "eyJhbGciOiJIUzI1NiJ9.payload.sig" not in masked

    def test_masks_refresh_token(self):
        msg = 'refresh_token": "long-secret-refresh-token"'
        masked = self._apply(msg)
        assert "long-secret-refresh-token" not in masked

    def test_masks_email_address(self):
        msg = "User sarah@example.com logged in"
        masked = self._apply(msg)
        assert "sarah@example.com" not in masked
        assert "***@***.***" in masked

    def test_masks_indian_phone_number(self):
        msg = "SMS sent to +919876543210"
        masked = self._apply(msg)
        assert "9876543210" not in masked

    def test_preserves_non_pii_content(self):
        msg = "Zone utilization at 85% capacity"
        masked = self._apply(msg)
        assert masked == msg

    def test_args_tuple_masked(self):
        record = logging.LogRecord(
            name="test", level=logging.INFO,
            pathname="", lineno=0,
            msg="User %s logged in from %s",
            args=("test@user.com", "192.168.1.1"),
            exc_info=None,
        )
        f = PIIMaskingFilter()
        f.filter(record)
        assert "test@user.com" not in str(record.args)


# ── AuditLogMiddleware ────────────────────────────────────────────────────────

class TestAuditLogMiddleware:
    @pytest.mark.asyncio
    async def test_writes_audit_record_to_file(self):
        from shems.core.security.dpdp import AuditLogMiddleware
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        with tempfile.TemporaryDirectory() as tmpdir:
            log_path = Path(tmpdir) / "audit.jsonl"
            app = FastAPI()

            @app.get("/api/v1/test")
            async def test_endpoint():
                return {"status": "ok"}

            # Add middleware with custom log path
            middleware = AuditLogMiddleware(app, log_path=str(log_path))

            # Simulate a dispatch
            from starlette.testclient import TestClient as StarletteClient
            from starlette.requests import Request
            from starlette.responses import JSONResponse

            mock_request = MagicMock()
            mock_request.method = "GET"
            mock_request.url.path = "/api/v1/test"
            mock_request.query_params = MagicMock(__str__=lambda _: "")
            mock_request.headers = {"User-Agent": "pytest/8.0", "Authorization": ""}
            mock_request.client = MagicMock()
            mock_request.client.host = "127.0.0.1"

            mock_response = MagicMock()
            mock_response.status_code = 200

            async def mock_call_next(req):
                return mock_response

            await middleware.dispatch(mock_request, mock_call_next)

            # Verify audit file was written
            assert log_path.exists()
            lines = log_path.read_text().strip().split("\n")
            assert len(lines) == 1
            record = json.loads(lines[0])
            assert record["method"] == "GET"
            assert record["path"] == "/api/v1/test"
            assert "audit_id" in record
            assert "timestamp" in record

    @pytest.mark.asyncio
    async def test_health_check_not_logged(self):
        from shems.core.security.dpdp import AuditLogMiddleware

        with tempfile.TemporaryDirectory() as tmpdir:
            log_path = Path(tmpdir) / "audit.jsonl"
            app = MagicMock()
            middleware = AuditLogMiddleware(app, log_path=str(log_path))

            mock_request = MagicMock()
            mock_request.url.path = "/health"
            mock_request.headers = {"Authorization": ""}
            mock_request.client = MagicMock()
            mock_request.client.host = "127.0.0.1"

            mock_response = MagicMock()
            mock_response.status_code = 200

            await middleware.dispatch(mock_request, AsyncMock(return_value=mock_response))

            # Health check should NOT be logged
            assert not log_path.exists() or log_path.read_text() == ""


# ── DataRetentionManager ──────────────────────────────────────────────────────

class TestDataRetentionManager:
    def test_uses_settings_retention_days_by_default(self):
        mgr = DataRetentionManager()
        from shems.config import settings
        assert mgr.retention_days == settings.dpdp_data_retention_days

    def test_custom_retention_days(self):
        mgr = DataRetentionManager(retention_days=180)
        assert mgr.retention_days == 180

    @pytest.mark.asyncio
    async def test_purge_old_readings_calls_delete(self):
        mgr = DataRetentionManager(retention_days=365)
        mock_db = AsyncMock()

        mock_result = MagicMock()
        mock_result.rowcount = 42
        mock_db.execute = AsyncMock(return_value=mock_result)

        counts = await mgr.purge_old_readings(mock_db)
        assert counts["energy_readings_deleted"] == 42
        assert counts["grid_load_readings_deleted"] == 42
        assert "cutoff_date" in counts
        mock_db.commit.assert_called_once()

    @pytest.mark.asyncio
    async def test_purge_expired_sessions(self):
        mgr = DataRetentionManager()
        mock_db = AsyncMock()
        mock_result = MagicMock()
        mock_result.rowcount = 15
        mock_db.execute = AsyncMock(return_value=mock_result)

        count = await mgr.purge_expired_sessions(mock_db)
        assert count == 15
        mock_db.commit.assert_called_once()

    @pytest.mark.asyncio
    async def test_anonymise_old_anomaly_alerts(self):
        mgr = DataRetentionManager()
        mock_db = AsyncMock()
        mock_result = MagicMock()
        mock_result.rowcount = 7
        mock_db.execute = AsyncMock(return_value=mock_result)

        count = await mgr.anonymise_old_anomaly_alerts(mock_db)
        assert count == 7


# ── DPDP address hash validation ─────────────────────────────────────────────

class TestDPDPAddressHash:
    """Ensure no plaintext address is ever stored or returned."""

    def test_address_hash_is_sha256_length(self):
        """SHA-256 hex digest must be exactly 64 characters."""
        import hashlib
        address = "42 MG Road, Bengaluru, Karnataka 560001"
        h = hashlib.sha256(address.encode()).hexdigest()
        assert len(h) == 64
        assert h.isalnum()

    def test_different_addresses_produce_different_hashes(self):
        import hashlib
        h1 = hashlib.sha256("address 1".encode()).hexdigest()
        h2 = hashlib.sha256("address 2".encode()).hexdigest()
        assert h1 != h2

    def test_same_address_produces_same_hash(self):
        import hashlib
        addr = "42 MG Road"
        assert (
            hashlib.sha256(addr.encode()).hexdigest()
            == hashlib.sha256(addr.encode()).hexdigest()
        )
