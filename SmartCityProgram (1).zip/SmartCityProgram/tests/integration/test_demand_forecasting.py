"""
Integration tests for demand forecasting pipeline.

Tests feature engineering, model training (in-memory),
and the predictor logic (without a live DB).
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
import pytest

from shems.ml.pipelines.demand_forecasting.feature_engineering import (
    FEATURE_COLS,
    build_features,
    build_inference_features,
)
from shems.ml.pipelines.demand_forecasting.predictor import (
    ForecastResult,
    Z95,
    forecast_zone,
)
from shems.ml.pipelines.demand_forecasting.trainer import (
    ForecastBundle,
    HORIZONS,
    _fit,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────

def _make_zone_readings(n: int = 6000) -> pd.DataFrame:
    """Generate synthetic 15-min grid load readings."""
    rng = np.random.default_rng(7)
    base = datetime(2024, 10, 1, tzinfo=timezone.utc)
    timestamps = [base + timedelta(minutes=15 * i) for i in range(n)]
    # Simulate diurnal pattern + noise
    loads = [
        200 + 100 * np.sin(2 * np.pi * t.hour / 24) + rng.normal(0, 10)
        for t in timestamps
    ]
    return pd.DataFrame({
        "timestamp": timestamps,
        "current_load_kw": np.clip(loads, 50, 500),
    })


# ── Feature engineering ───────────────────────────────────────────────────────

class TestDemandForecastFeatureEngineering:
    def test_build_features_has_all_cols(self):
        df = _make_zone_readings(2000)
        feat = build_features(df, target_shift=4)
        assert not feat.empty
        for col in FEATURE_COLS + ["target_load_kw"]:
            assert col in feat.columns, f"Missing: {col}"

    def test_target_shift_alignment(self):
        """Larger shift → smaller resulting DataFrame (more NaN dropped at tail)."""
        df = _make_zone_readings(2000)
        feat_1h = build_features(df, target_shift=4)
        feat_24h = build_features(df, target_shift=96)
        assert len(feat_1h) > len(feat_24h)

    def test_cyclic_encoding_in_unit_circle(self):
        df = _make_zone_readings(500)
        feat = build_features(df, target_shift=4)
        for col in ("hour_sin", "hour_cos", "week_sin", "week_cos"):
            assert feat[col].between(-1.01, 1.01).all()

    def test_no_nans_in_features(self):
        df = _make_zone_readings(1500)
        feat = build_features(df, target_shift=4)
        assert feat[FEATURE_COLS].isna().sum().sum() == 0

    def test_inference_features_no_target_col(self):
        df = _make_zone_readings(200)
        feat = build_inference_features(df)
        assert not feat.empty
        assert "target_load_kw" not in feat.columns

    def test_inference_features_all_feature_cols(self):
        df = _make_zone_readings(200)
        feat = build_inference_features(df)
        for col in FEATURE_COLS:
            assert col in feat.columns

    def test_is_weekend_flag(self):
        df = _make_zone_readings(700)
        feat = build_features(df, target_shift=4)
        assert feat["is_weekend"].isin([0.0, 1.0]).all()

    def test_is_peak_hour_flag(self):
        df = _make_zone_readings(700)
        feat = build_features(df, target_shift=4)
        assert feat["is_peak_hour"].isin([0.0, 1.0]).all()

    def test_empty_df_returns_empty(self):
        feat = build_features(pd.DataFrame(), target_shift=4)
        assert feat.empty


# ── Training ──────────────────────────────────────────────────────────────────

class TestDemandForecastTraining:
    @pytest.fixture(scope="class")
    def trained_bundle(self) -> ForecastBundle:
        df = _make_zone_readings(6000)
        feat = build_features(df, target_shift=4)
        return _fit(feat, zone_name="TestZone", label="1h")

    def test_fit_returns_bundle(self, trained_bundle):
        assert isinstance(trained_bundle, ForecastBundle)

    def test_mae_is_positive(self, trained_bundle):
        assert trained_bundle.mae > 0

    def test_std_residuals_positive(self, trained_bundle):
        assert trained_bundle.std_residuals > 0

    def test_model_predict_positive(self, trained_bundle):
        df = _make_zone_readings(200)
        feat = build_inference_features(df)
        X = feat.tail(1)[FEATURE_COLS].values
        X_scaled = trained_bundle.scaler.transform(X)
        pred = float(trained_bundle.model.predict(X_scaled)[0])
        assert pred >= 0

    def test_ci_width(self, trained_bundle):
        """95% CI should be positive and proportional to std_residuals."""
        margin = Z95 * trained_bundle.std_residuals
        assert margin > 0


# ── Predictor ─────────────────────────────────────────────────────────────────

class TestDemandForecastPredictor:
    def test_forecast_zone_no_model_returns_empty(self):
        """With no trained models in registry, forecast_zone returns []."""
        zone_id = uuid.uuid4()
        df = _make_zone_readings(200)
        results = forecast_zone(zone_id, df)
        # May return 0 results if models not trained (cold start)
        assert isinstance(results, list)
        for r in results:
            assert isinstance(r, ForecastResult)

    def test_forecast_zone_empty_df_returns_empty(self):
        zone_id = uuid.uuid4()
        results = forecast_zone(zone_id, pd.DataFrame())
        assert results == []

    def test_forecast_result_non_negative(self):
        """All forecast values should be ≥ 0."""
        zone_id = uuid.uuid4()
        df = _make_zone_readings(200)
        for fr in forecast_zone(zone_id, df):
            assert fr.predicted_load_kw >= 0
            assert fr.confidence_lower >= 0
            assert fr.confidence_upper >= fr.confidence_lower


# ── HORIZONS constant ─────────────────────────────────────────────────────────

def test_horizons_constant_has_four_entries():
    assert len(HORIZONS) == 4


@pytest.mark.parametrize("label,shift,hours", HORIZONS)
def test_horizon_shift_proportional(label, shift, hours):
    """Slot shift should equal horizon_hours × 4 (15-min slots per hour)."""
    assert shift == hours * 4
