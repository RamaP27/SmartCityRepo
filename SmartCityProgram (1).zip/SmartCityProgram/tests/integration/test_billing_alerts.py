"""
Integration tests for billing alert flow.

Tests the end-to-end path:
  UsageSummary data → BillingService.check_and_fire_alerts → OverageAlert created

Run with:
    pytest tests/integration/test_billing_alerts.py -v
"""
import pytest
import pytest_asyncio

from shems.domains.auth.models import PersonaType
from shems.domains.billing.models import AlertType
from shems.domains.billing.manager import BillingManager
from shems.domains.billing.service import BillingService

from tests.conftest import (
    create_test_billing_account,
    create_test_spending_cap,
    create_test_user,
    inject_usage_summaries,
)


@pytest.mark.asyncio
async def test_no_alert_when_spend_below_threshold(db):
    user = await create_test_user(db, email="below@test.com", persona_type=PersonaType.RENTER)
    account = await create_test_billing_account(db, user.id)
    await create_test_spending_cap(db, account.id, monthly_cap_inr=1000.0, warning_threshold_pct=80.0)

    # Inject spend at 70% of cap (700 INR)
    await inject_usage_summaries(db, account.id, total_spend_inr=700.0)

    service = BillingService(BillingManager(db))
    await service.check_and_fire_alerts(account.id)

    alerts = await BillingManager(db).list_alerts(account.id)
    assert len(alerts) == 0, "No alert should fire below warning threshold"


@pytest.mark.asyncio
async def test_warning_alert_fires_at_threshold(db):
    user = await create_test_user(db, email="warning@test.com", persona_type=PersonaType.RENTER)
    account = await create_test_billing_account(db, user.id)
    await create_test_spending_cap(db, account.id, monthly_cap_inr=1000.0, warning_threshold_pct=80.0)

    # Inject spend at 85% of cap (850 INR)
    await inject_usage_summaries(db, account.id, total_spend_inr=850.0)

    service = BillingService(BillingManager(db))
    await service.check_and_fire_alerts(account.id)

    alerts = await BillingManager(db).list_alerts(account.id)
    assert len(alerts) == 1
    assert alerts[0].alert_type == AlertType.WARNING_THRESHOLD
    assert alerts[0].current_spend_inr == pytest.approx(850.0, rel=0.01)
    assert alerts[0].cap_inr == 1000.0


@pytest.mark.asyncio
async def test_cap_reached_alert_fires_at_100_pct(db):
    user = await create_test_user(db, email="cap@test.com", persona_type=PersonaType.RENTER)
    account = await create_test_billing_account(db, user.id)
    await create_test_spending_cap(db, account.id, monthly_cap_inr=1000.0, warning_threshold_pct=80.0)

    # Inject spend at 105% of cap (1050 INR)
    await inject_usage_summaries(db, account.id, total_spend_inr=1050.0)

    service = BillingService(BillingManager(db))
    await service.check_and_fire_alerts(account.id)

    alerts = await BillingManager(db).list_alerts(account.id)
    assert len(alerts) == 1
    assert alerts[0].alert_type == AlertType.CAP_REACHED


@pytest.mark.asyncio
async def test_no_duplicate_alert_within_one_hour(db):
    user = await create_test_user(db, email="dedup@test.com", persona_type=PersonaType.RENTER)
    account = await create_test_billing_account(db, user.id)
    await create_test_spending_cap(db, account.id, monthly_cap_inr=1000.0, warning_threshold_pct=80.0)
    await inject_usage_summaries(db, account.id, total_spend_inr=850.0)

    service = BillingService(BillingManager(db))

    # Fire twice in quick succession
    await service.check_and_fire_alerts(account.id)
    await service.check_and_fire_alerts(account.id)

    alerts = await BillingManager(db).list_alerts(account.id)
    assert len(alerts) == 1, "Duplicate alert within 1 hour should be suppressed"


@pytest.mark.asyncio
async def test_no_alert_when_no_spending_cap(db):
    user = await create_test_user(db, email="nocap@test.com", persona_type=PersonaType.RENTER)
    account = await create_test_billing_account(db, user.id)
    # No spending cap created

    await inject_usage_summaries(db, account.id, total_spend_inr=5000.0)

    service = BillingService(BillingManager(db))
    await service.check_and_fire_alerts(account.id)

    alerts = await BillingManager(db).list_alerts(account.id)
    assert len(alerts) == 0, "No alert when no cap is set"


@pytest.mark.asyncio
async def test_full_api_flow_marcus(client, db):
    """End-to-end: signup → create billing account → set cap → check alerts via API."""
    # Signup
    resp = await client.post("/api/v1/auth/signup", json={
        "email": "marcus@test.com",
        "password": "testpassword123",
        "persona_type": "RENTER",
    })
    assert resp.status_code == 201
    tokens = resp.json()
    headers = {"Authorization": f"Bearer {tokens['access_token']}"}

    # Create billing account
    resp = await client.post("/api/v1/billing/me/account", json={
        "utility_provider": "City Power Co",
        "billing_cycle_day": 1,
    }, headers=headers)
    assert resp.status_code == 201
    account_data = resp.json()
    assert account_data["utility_provider"] == "City Power Co"

    # Set spending cap
    resp = await client.post("/api/v1/billing/me/spending-cap", json={
        "monthly_cap_inr": 2000.0,
        "warning_threshold_pct": 75.0,
    }, headers=headers)
    assert resp.status_code == 201
    cap_data = resp.json()
    assert cap_data["monthly_cap_inr"] == 2000.0

    # Get spending cap
    resp = await client.get("/api/v1/billing/me/spending-cap", headers=headers)
    assert resp.status_code == 200
    assert resp.json()["is_active"] is True

    # No alerts yet
    resp = await client.get("/api/v1/billing/me/alerts", headers=headers)
    assert resp.status_code == 200
    assert resp.json() == []
