"""
Tests for the AI off-peak schedule suggestion engine (Phase 3 — Week 11).
"""
from __future__ import annotations

import uuid
from datetime import datetime, time, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from shems.domains.household.ai_scheduler import (
    OffPeakWindow,
    SuggestedSchedule,
    _materialise_windows,
    _suggest_for_device,
    generate_suggestions,
)


# ── OffPeakWindow ─────────────────────────────────────────────────────────────

class TestOffPeakWindow:
    def test_duration_hours(self):
        now = datetime.now(timezone.utc).replace(hour=22, minute=0, second=0, microsecond=0)
        end = now.replace(hour=23, minute=0)
        w = OffPeakWindow(window_type="OFF_PEAK", start=now, end=end)
        assert w.duration_hours == 1.0

    def test_duration_crossing_midnight(self):
        from datetime import timedelta
        now = datetime.now(timezone.utc).replace(hour=23, minute=0, second=0, microsecond=0)
        end = now + timedelta(hours=6)
        w = OffPeakWindow(window_type="SUPER_OFF_PEAK", start=now, end=end)
        assert w.duration_hours == 6.0


# ── Device suggestion heuristics ─────────────────────────────────────────────

class TestDeviceSuggestions:
    def _make_windows(self, types_and_hours: list[tuple[str, int, int]]) -> list[OffPeakWindow]:
        """Helper to create OffPeakWindow objects with (type, start_hour, end_hour)."""
        now = datetime.now(timezone.utc)
        windows = []
        for wtype, sh, eh in types_and_hours:
            start = now.replace(hour=sh, minute=0, second=0, microsecond=0)
            end = now.replace(hour=eh, minute=0, second=0, microsecond=0)
            if end <= start:
                from datetime import timedelta
                end += timedelta(days=1)
            windows.append(OffPeakWindow(window_type=wtype, start=start, end=end))
        return windows

    def _make_device(self, device_type: str) -> MagicMock:
        device = MagicMock()
        device.id = uuid.uuid4()
        device.name = f"Test {device_type}"
        device.device_type = MagicMock()
        device.device_type.value = device_type
        device.is_schedulable = True
        return device

    def test_ev_charger_picks_longest_window(self):
        windows = self._make_windows([
            ("OFF_PEAK", 22, 23),        # 1h — too short for EV
            ("OFF_PEAK", 23, 5),         # 6h — longest
        ])
        device = self._make_device("EV_CHARGER")
        suggestion = _suggest_for_device(device, windows)
        assert suggestion is not None
        assert suggestion.device_type == "EV_CHARGER"
        # EV should pick the 6h window
        assert suggestion.suggested_end.hour == 5 or suggestion.suggested_end.hour == 23

    def test_ev_charger_no_suggestion_if_no_long_window(self):
        # Only 3h window; EV needs 4h minimum
        windows = self._make_windows([("OFF_PEAK", 22, 1)])  # 3h
        device = self._make_device("EV_CHARGER")
        suggestion = _suggest_for_device(device, windows)
        assert suggestion is None

    def test_dishwasher_prefers_evening_window(self):
        windows = self._make_windows([
            ("OFF_PEAK", 14, 16),   # afternoon, 2h
            ("OFF_PEAK", 21, 23),   # evening, 2h — should be preferred
        ])
        device = self._make_device("DISHWASHER")
        suggestion = _suggest_for_device(device, windows)
        assert suggestion is not None
        assert suggestion.suggested_start.hour >= 21

    def test_washer_picks_shortest_window(self):
        windows = self._make_windows([
            ("OFF_PEAK", 22, 4),    # 6h
            ("OFF_PEAK", 14, 16),   # 2h — shortest that fits
        ])
        device = self._make_device("WASHER")
        suggestion = _suggest_for_device(device, windows)
        assert suggestion is not None
        # Should pick the 2h window at 14:00
        assert suggestion.suggested_start.hour == 14

    def test_suggestion_has_all_seven_days(self):
        windows = self._make_windows([("OFF_PEAK", 22, 4)])
        device = self._make_device("DRYER")
        suggestion = _suggest_for_device(device, windows)
        assert suggestion is not None
        assert len(suggestion.days_of_week) == 7

    def test_suggestion_savings_pct_positive(self):
        windows = self._make_windows([("OFF_PEAK", 22, 4)])
        device = self._make_device("EV_CHARGER")
        suggestion = _suggest_for_device(device, windows)
        assert suggestion is not None
        assert suggestion.estimated_savings_pct > 0

    def test_no_windows_returns_none(self):
        device = self._make_device("EV_CHARGER")
        suggestion = _suggest_for_device(device, [])
        assert suggestion is None


# ── generate_suggestions (integration with DB mock) ──────────────────────────

class TestGenerateSuggestions:
    @pytest.mark.asyncio
    async def test_no_household_returns_empty(self):
        mock_db = AsyncMock()
        mock_result = AsyncMock()
        mock_result.scalar_one_or_none = MagicMock(return_value=None)
        mock_db.execute = AsyncMock(return_value=mock_result)

        result = await generate_suggestions(uuid.uuid4(), mock_db)
        assert result == []

    @pytest.mark.asyncio
    async def test_no_schedulable_devices_returns_empty(self):
        mock_db = AsyncMock()
        household_id = uuid.uuid4()

        call_count = 0

        async def mock_execute(stmt):
            nonlocal call_count
            call_count += 1
            mock_result = MagicMock()
            if call_count == 1:
                # Household district_id
                mock_result.scalar_one_or_none = MagicMock(return_value=uuid.uuid4())
            elif call_count == 2:
                # Devices (empty)
                mock_result.scalars = MagicMock(return_value=MagicMock(all=MagicMock(return_value=[])))
            return mock_result

        mock_db.execute = mock_execute
        result = await generate_suggestions(household_id, mock_db)
        assert result == []
