"""
Tests for the notification dispatcher and event-driven notification flow (Phase 3 — Week 10).
"""
from __future__ import annotations

import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from shems.core.messaging.notification_dispatcher import (
    NotificationDispatcher,
    NotificationPayload,
    get_dispatcher,
)


# ── NotificationPayload ───────────────────────────────────────────────────────

class TestNotificationPayload:
    def test_creates_with_required_fields(self):
        p = NotificationPayload(title="Hello", body="World")
        assert p.title == "Hello"
        assert p.body == "World"
        assert p.data is None

    def test_creates_with_data(self):
        p = NotificationPayload(title="T", body="B", data={"key": "val"})
        assert p.data["key"] == "val"


# ── Push notification ─────────────────────────────────────────────────────────

class TestPushNotification:
    @pytest.mark.asyncio
    async def test_push_skipped_when_firebase_not_configured(self):
        disp = NotificationDispatcher.__new__(NotificationDispatcher)
        disp._twilio_client = None
        NotificationDispatcher._firebase_initialised = False

        result = await disp.send_push(
            "some-fcm-token",
            NotificationPayload(title="Test", body="Body"),
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_push_skipped_with_empty_token(self):
        disp = NotificationDispatcher.__new__(NotificationDispatcher)
        disp._twilio_client = None
        NotificationDispatcher._firebase_initialised = True

        result = await disp.send_push(
            "",
            NotificationPayload(title="Test", body="Body"),
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_push_sends_when_firebase_configured(self):
        disp = NotificationDispatcher.__new__(NotificationDispatcher)
        NotificationDispatcher._firebase_initialised = True

        mock_messaging = MagicMock()
        mock_messaging.Message = MagicMock(return_value=MagicMock())
        mock_messaging.Notification = MagicMock(return_value=MagicMock())
        mock_messaging.send = MagicMock(return_value="message-id-123")

        with patch.dict("sys.modules", {"firebase_admin": MagicMock(), "firebase_admin.messaging": mock_messaging}):
            result = await disp.send_push(
                "valid-fcm-token",
                NotificationPayload(title="Test", body="Body"),
            )
        # If firebase_admin is not installed in test env, will be False
        # Just verify no exception is raised
        assert isinstance(result, bool)


# ── SMS notification ──────────────────────────────────────────────────────────

class TestSMSNotification:
    @pytest.mark.asyncio
    async def test_sms_skipped_when_twilio_not_configured(self):
        disp = NotificationDispatcher.__new__(NotificationDispatcher)
        disp._twilio_client = None

        result = await disp.send_sms("+919876543210", "Test SMS")
        assert result is False

    @pytest.mark.asyncio
    async def test_sms_skipped_with_empty_phone(self):
        disp = NotificationDispatcher.__new__(NotificationDispatcher)
        disp._twilio_client = MagicMock()

        result = await disp.send_sms("", "Test SMS")
        assert result is False

    @pytest.mark.asyncio
    async def test_sms_sends_via_twilio(self):
        disp = NotificationDispatcher.__new__(NotificationDispatcher)
        mock_twilio = MagicMock()
        mock_message = MagicMock()
        mock_message.sid = "SM123"
        mock_twilio.messages.create.return_value = mock_message
        disp._twilio_client = mock_twilio

        with patch.object(disp, "_twilio_client", mock_twilio):
            # Patch settings for from_number
            with patch("shems.core.messaging.notification_dispatcher.settings") as mock_settings:
                mock_settings.twilio_from_number = "+910000000000"
                result = await disp.send_sms("+919876543210", "Grid alert test")

        assert result is True
        mock_twilio.messages.create.assert_called_once()


# ── Event-driven notification wiring ─────────────────────────────────────────

class TestEventBusNotificationHandlers:
    @pytest.mark.asyncio
    async def test_overage_alert_event_triggers_notification_handler(self):
        """OverageAlertTriggeredEvent should invoke registered handler."""
        from shems.core.events.event_bus import publish
        from shems.core.events.event_types import OverageAlertTriggeredEvent
        from shems.core.messaging.notification_dispatcher import register_handlers

        register_handlers()  # Register handlers (idempotent)

        event = OverageAlertTriggeredEvent(
            billing_account_id=uuid.uuid4(),
            user_id=uuid.uuid4(),
            current_spend_inr=850.0,
            cap_inr=1000.0,
            alert_type="WARNING_THRESHOLD",
        )
        # Should not raise even with no FCM token configured
        await publish(event)

    @pytest.mark.asyncio
    async def test_anomaly_event_skips_push_without_fcm_token(self):
        """AnomalyDetectedEvent with no FCM token should not raise."""
        from shems.core.events.event_bus import publish
        from shems.core.events.event_types import AnomalyDetectedEvent
        from shems.core.messaging.notification_dispatcher import register_handlers

        register_handlers()

        event = AnomalyDetectedEvent(
            household_id=uuid.uuid4(),
            zone_id=uuid.uuid4(),
            user_id=uuid.uuid4(),
            anomaly_score=-0.45,
            severity="HIGH",
            user_fcm_token="",   # No token
            user_phone="",
        )
        await publish(event)  # Must not raise

    @pytest.mark.asyncio
    async def test_sustainability_milestone_event_handled(self):
        from shems.core.events.event_bus import publish
        from shems.core.events.event_types import SustainabilityMilestoneEvent
        from shems.core.messaging.notification_dispatcher import register_handlers

        register_handlers()

        event = SustainabilityMilestoneEvent(
            household_id=uuid.uuid4(),
            user_id=uuid.uuid4(),
            previous_score=62.0,
            new_score=68.5,
            grade="B",
            user_fcm_token="",
        )
        await publish(event)
