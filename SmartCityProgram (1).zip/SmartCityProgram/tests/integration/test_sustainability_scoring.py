"""
Integration tests for sustainability scoring pipeline.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from shems.ml.pipelines.sustainability_scoring.scorer import (
    EMISSION_FACTOR,
    MAX_CARBON_KG,
    SustainabilityScore,
    _grade,
    _percentile_rank,
    score_household,
)
from shems.ml.pipelines.sustainability_scoring.benchmark_calculator import (
    _default_benchmark,
)


# ── Scoring formula tests ─────────────────────────────────────────────────────

class TestSustainabilityScorer:
    @pytest.fixture
    def period(self):
        now = datetime.now(timezone.utc)
        return now - timedelta(days=30), now

    def test_score_returns_dataclass(self, period):
        s = score_household(
            total_kwh=150.0,
            cluster_median_kwh=200.0,
            cluster_p75_kwh=280.0,
            household_id="test-uuid",
            cluster_key="medium_3-4",
            period_start=period[0],
            period_end=period[1],
        )
        assert isinstance(s, SustainabilityScore)

    def test_carbon_kg_calculation(self, period):
        total_kwh = 100.0
        s = score_household(
            total_kwh=total_kwh,
            cluster_median_kwh=200.0,
            cluster_p75_kwh=280.0,
            household_id="test-uuid",
            cluster_key="medium_3-4",
            period_start=period[0],
            period_end=period[1],
        )
        assert abs(s.carbon_kg - round(total_kwh * EMISSION_FACTOR, 2)) < 0.01

    def test_score_in_0_100_range(self, period):
        for kwh in [10.0, 100.0, 300.0, 600.0, 900.0]:
            s = score_household(
                total_kwh=kwh,
                cluster_median_kwh=300.0,
                cluster_p75_kwh=400.0,
                household_id="test-uuid",
                cluster_key="medium_1-2",
                period_start=period[0],
                period_end=period[1],
            )
            assert 0.0 <= s.final_score <= 100.0, f"Score out of range for kwh={kwh}"

    def test_lower_consumption_higher_score(self, period):
        s_low = score_household(
            total_kwh=80.0,
            cluster_median_kwh=200.0,
            cluster_p75_kwh=280.0,
            household_id="hh1",
            cluster_key="medium_3-4",
            period_start=period[0],
            period_end=period[1],
        )
        s_high = score_household(
            total_kwh=400.0,
            cluster_median_kwh=200.0,
            cluster_p75_kwh=280.0,
            household_id="hh2",
            cluster_key="medium_3-4",
            period_start=period[0],
            period_end=period[1],
        )
        assert s_low.final_score > s_high.final_score

    def test_grade_a_plus_for_excellent(self, period):
        s = score_household(
            total_kwh=30.0,
            cluster_median_kwh=200.0,
            cluster_p75_kwh=280.0,
            household_id="hh",
            cluster_key="small_1-2",
            period_start=period[0],
            period_end=period[1],
        )
        assert s.grade in ("A+", "A")

    def test_grade_d_for_high_consumption(self, period):
        s = score_household(
            total_kwh=800.0,
            cluster_median_kwh=200.0,
            cluster_p75_kwh=280.0,
            household_id="hh",
            cluster_key="small_1-2",
            period_start=period[0],
            period_end=period[1],
        )
        assert s.grade in ("D", "C")


class TestGradeFunction:
    @pytest.mark.parametrize("score,expected", [
        (90.0, "A+"),
        (75.0, "A"),
        (60.0, "B"),
        (45.0, "C"),
        (20.0, "D"),
    ])
    def test_grade_thresholds(self, score, expected):
        assert _grade(score) == expected


class TestPercentileRank:
    def test_below_half_median_gets_95(self):
        rank = _percentile_rank(carbon_kg=20.0, cluster_median=50.0, cluster_p75=80.0)
        assert rank == 95.0

    def test_at_median_gets_75(self):
        rank = _percentile_rank(carbon_kg=50.0, cluster_median=50.0, cluster_p75=80.0)
        assert abs(rank - 75.0) < 1.0

    def test_above_p75_gets_25(self):
        rank = _percentile_rank(carbon_kg=200.0, cluster_median=50.0, cluster_p75=80.0)
        assert rank == 25.0

    def test_rank_monotone_decreasing_with_carbon(self):
        median, p75 = 100.0, 150.0
        prev = 100.0
        for carbon in [10.0, 60.0, 100.0, 130.0, 200.0]:
            rank = _percentile_rank(carbon, median, p75)
            assert rank <= prev
            prev = rank


class TestDefaultBenchmarks:
    def test_all_clusters_have_defaults(self):
        clusters = [
            "small_1-2", "small_3-4", "small_5+",
            "medium_1-2", "medium_3-4", "medium_5+",
            "large_1-2", "large_3-4", "large_5+",
        ]
        for c in clusters:
            bm = _default_benchmark(c)
            assert "median_kwh" in bm
            assert "p75_kwh" in bm
            assert bm["p75_kwh"] >= bm["median_kwh"]

    def test_unknown_cluster_returns_sensible_default(self):
        bm = _default_benchmark("unknown_cluster")
        assert bm["median_kwh"] > 0
        assert bm["p75_kwh"] > bm["median_kwh"]
