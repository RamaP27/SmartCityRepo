"""
IoT ingest endpoints.

These endpoints receive data from:
- Smart meters (15-min readings posted via webhook)
- Grid load feed (real-time zone-level load data)

In Phase 1 they write directly to the DB.
In Phase 3 these will be replaced/augmented by Kafka consumers.
"""
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from shems.dependencies import get_db
from shems.domains.household.models import EnergyReading, Household, ReadingSource
from shems.domains.grid.models import GridLoadReading, GridLoadSource, GridZone
from shems.ingest.schemas import GridLoadPayload, IngestResponse, MeterReadingPayload

router = APIRouter()
logger = logging.getLogger(__name__)


@router.post("/meter-reading", response_model=IngestResponse, status_code=202)
async def ingest_meter_reading(
    payload: MeterReadingPayload,
    db: AsyncSession = Depends(get_db),
):
    """
    Receive a 15-minute smart meter reading.
    Looks up the household by smart_meter_id and stores the reading.
    """
    result = await db.execute(
        select(Household).where(Household.smart_meter_id == payload.smart_meter_id)
    )
    household = result.scalar_one_or_none()

    if not household:
        logger.warning("No household found for meter_id=%s", payload.smart_meter_id)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Household with smart_meter_id '{payload.smart_meter_id}' not found",
        )

    # Determine if this timestamp falls in a peak window
    is_peak = _is_peak_hour(payload.timestamp)

    reading = EnergyReading(
        household_id=household.id,
        timestamp=payload.timestamp,
        consumption_kwh=payload.consumption_kwh,
        cost_estimate_inr=0.0,  # Will be updated by billing Celery task
        is_peak_hour=is_peak,
        source=ReadingSource.SMART_METER,
    )
    db.add(reading)
    await db.commit()

    logger.info(
        "Ingested meter reading: household=%s kwh=%.4f ts=%s",
        household.id,
        payload.consumption_kwh,
        payload.timestamp,
    )
    return IngestResponse(status="accepted", processed=1)


@router.post("/grid-load", response_model=IngestResponse, status_code=202)
async def ingest_grid_load(
    payload: GridLoadPayload,
    db: AsyncSession = Depends(get_db),
):
    """Receive a real-time grid load reading for a zone."""
    zone_result = await db.execute(
        select(GridZone).where(GridZone.id == payload.zone_id)
    )
    zone = zone_result.scalar_one_or_none()
    if not zone:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Grid zone '{payload.zone_id}' not found",
        )

    reading = GridLoadReading(
        zone_id=payload.zone_id,
        timestamp=payload.timestamp,
        current_load_kw=payload.current_load_kw,
        capacity_utilization_pct=payload.capacity_utilization_pct,
        source=GridLoadSource(payload.source) if payload.source in GridLoadSource.__members__ else GridLoadSource.ESTIMATED,
    )
    db.add(reading)
    await db.commit()

    return IngestResponse(status="accepted", processed=1)


def _is_peak_hour(ts: datetime) -> bool:
    """
    Simple default peak hour rule (06:00–22:00 local approximation).
    In Phase 2 this is replaced by a live TariffZone lookup.
    """
    hour = ts.hour
    return 6 <= hour < 22
