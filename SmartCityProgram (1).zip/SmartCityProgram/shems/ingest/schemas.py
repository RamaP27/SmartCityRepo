import uuid
from datetime import datetime

from pydantic import BaseModel, field_validator


class MeterReadingPayload(BaseModel):
    """Incoming 15-minute smart meter reading via webhook."""
    smart_meter_id: str
    timestamp: datetime
    consumption_kwh: float
    source: str = "SMART_METER"

    @field_validator("consumption_kwh")
    @classmethod
    def positive_consumption(cls, v: float) -> float:
        if v < 0:
            raise ValueError("consumption_kwh must be non-negative")
        return round(v, 6)


class GridLoadPayload(BaseModel):
    """Incoming grid load reading from utility feed."""
    zone_id: uuid.UUID
    timestamp: datetime
    current_load_kw: float
    capacity_utilization_pct: float
    source: str = "SCADA"

    @field_validator("capacity_utilization_pct")
    @classmethod
    def valid_utilization(cls, v: float) -> float:
        if not 0 <= v <= 200:
            raise ValueError("capacity_utilization_pct out of range")
        return round(v, 2)


class IngestResponse(BaseModel):
    status: str
    processed: int
    message: str = ""
