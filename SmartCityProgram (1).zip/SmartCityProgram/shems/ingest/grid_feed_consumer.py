"""
aiokafka consumer for real-time grid load feed (Phase 3 — Week 12).

Topic: shems.grid.load
Message schema:
  {
    "zone_id": "<uuid>",
    "timestamp": "<ISO-8601>",
    "current_load_kw": 320.5,
    "capacity_utilization_pct": 64.1,
    "source": "SCADA"
  }

Lifecycle:
  - start_grid_feed_consumer() is called from main.py lifespan on startup.
  - stop_grid_feed_consumer() is called on shutdown.
  - The consumer runs as a background asyncio task.

Auto-DR trigger:
  If a reading shows utilization ≥ 85%, the consumer publishes a
  DemandResponseTriggeredEvent on the internal event bus AND queues
  the demand-forecasting Celery task immediately (outside the hourly schedule).
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import datetime, timezone

from shems.config import settings

logger = logging.getLogger(__name__)

_consumer_task: asyncio.Task | None = None
_STOP_FLAG = False

# Capacity utilization threshold that triggers auto-DR
_AUTO_DR_THRESHOLD = 0.85


async def start_grid_feed_consumer():
    """Start the Kafka consumer as a background asyncio task."""
    global _consumer_task, _STOP_FLAG
    _STOP_FLAG = False
    _consumer_task = asyncio.create_task(_consume_loop(), name="grid-feed-consumer")
    logger.info(
        "Grid feed consumer started — topic=%s brokers=%s",
        settings.kafka_grid_load_topic,
        settings.kafka_bootstrap_servers,
    )


async def stop_grid_feed_consumer():
    """Signal the consumer to stop and wait for clean shutdown."""
    global _STOP_FLAG
    _STOP_FLAG = True
    if _consumer_task and not _consumer_task.done():
        _consumer_task.cancel()
        try:
            await _consumer_task
        except asyncio.CancelledError:
            pass
    logger.info("Grid feed consumer stopped")


async def _consume_loop():
    """Main consumer loop — runs indefinitely until stopped."""
    try:
        from aiokafka import AIOKafkaConsumer
    except ImportError:
        logger.warning("aiokafka not installed — grid feed consumer disabled")
        return

    consumer = AIOKafkaConsumer(
        settings.kafka_grid_load_topic,
        bootstrap_servers=settings.kafka_bootstrap_servers,
        group_id=settings.kafka_consumer_group,
        auto_offset_reset="latest",
        enable_auto_commit=True,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
    )

    try:
        await consumer.start()
        logger.info("Kafka consumer connected")

        async for msg in consumer:
            if _STOP_FLAG:
                break
            try:
                await _process_message(msg.value)
            except Exception as exc:
                logger.error(
                    "Grid feed consumer: error processing message offset=%d: %s",
                    msg.offset, exc,
                )
    finally:
        await consumer.stop()


async def _process_message(payload: dict):
    """Persist a grid load reading and trigger auto-DR if threshold exceeded."""
    from shems.database import AsyncSessionLocal
    from shems.domains.grid.models import GridLoadReading, GridLoadSource, GridZone
    from sqlalchemy import select

    zone_id_str = payload.get("zone_id")
    if not zone_id_str:
        return

    zone_id = uuid.UUID(zone_id_str)
    timestamp_str = payload.get("timestamp", "")
    current_load_kw = float(payload.get("current_load_kw", 0))
    utilization_pct = float(payload.get("capacity_utilization_pct", 0))
    source_str = payload.get("source", "SCADA").upper()

    try:
        source = GridLoadSource[source_str]
    except KeyError:
        source = GridLoadSource.ESTIMATED

    timestamp = (
        datetime.fromisoformat(timestamp_str)
        if timestamp_str
        else datetime.now(timezone.utc)
    )

    async with AsyncSessionLocal() as db:
        # Persist the reading
        reading = GridLoadReading(
            zone_id=zone_id,
            timestamp=timestamp,
            current_load_kw=current_load_kw,
            capacity_utilization_pct=utilization_pct,
            source=source,
        )
        db.add(reading)

        # Check auto-DR threshold
        if utilization_pct >= _AUTO_DR_THRESHOLD * 100:
            await _trigger_auto_dr(db, zone_id, current_load_kw, utilization_pct)

        await db.commit()

    logger.debug(
        "Grid reading persisted zone=%s load=%.1f kW util=%.1f%%",
        zone_id, current_load_kw, utilization_pct,
    )


async def _trigger_auto_dr(db, zone_id: uuid.UUID, load_kw: float, util_pct: float):
    """
    Trigger automated demand response and publish event.
    Only creates a new DR event if no PENDING/ACTIVE event exists for this zone.
    """
    from shems.domains.grid.models import DemandResponseEvent, DRStatus, DRTriggerType, GridZone
    from shems.core.events.event_bus import publish
    from shems.core.events.event_types import DemandResponseTriggeredEvent
    from sqlalchemy import and_, func, select

    # Check for existing active DR event
    existing = await db.execute(
        select(func.count(DemandResponseEvent.id)).where(
            and_(
                DemandResponseEvent.zone_id == zone_id,
                DemandResponseEvent.status.in_([DRStatus.PENDING, DRStatus.ACTIVE]),
            )
        )
    )
    if existing.scalar() > 0:
        return  # Already handling this zone

    # Fetch zone details
    zone_result = await db.execute(
        select(GridZone).where(GridZone.id == zone_id)
    )
    zone = zone_result.scalar_one_or_none()
    if not zone:
        return

    target_reduction = load_kw * 0.15   # target 15% reduction
    dr_event = DemandResponseEvent(
        zone_id=zone_id,
        triggered_by=zone_id,   # system-generated; no specific user
        trigger_type=DRTriggerType.AUTOMATED_ML,
        status=DRStatus.PENDING,
        target_load_reduction_kw=round(target_reduction, 1),
        incentive_offer_inr=50.0,
        households_targeted=zone.total_households,
        started_at=datetime.now(timezone.utc),
    )
    db.add(dr_event)

    logger.warning(
        "Auto-DR triggered zone=%s util=%.1f%% target_reduction=%.1f kW",
        zone.zone_name, util_pct, target_reduction,
    )

    await publish(DemandResponseTriggeredEvent(
        zone_id=zone_id,
        zone_name=zone.zone_name,
        predicted_load_kw=load_kw,
        peak_capacity_kw=zone.peak_capacity_kw,
        dr_event_id=dr_event.id,
    ))
