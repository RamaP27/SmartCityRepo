"""
Sustainability scorer — deterministic carbon & efficiency scoring.

Score formula (0–100):
  carbon_kg      = total_kwh × emission_factor   (0.82 kg CO2/kWh, India CEA 2023)
  raw_score      = 100 × (1 - carbon_kg / max_carbon_kg)  (clamped to 0–100)
  final_score    = 0.6 × raw_score + 0.4 × percentile_rank

Percentile rank is computed against the cluster benchmark (median & p75).
Cluster key: FeatureStore.get_cluster_key(square_footage, occupant_count)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone

from shems.ml.feature_store import FeatureStore

logger = logging.getLogger(__name__)

# India CEA 2023 grid emission factor (kg CO2 per kWh)
EMISSION_FACTOR = 0.82

# Assumed max monthly carbon reference for normalization (kg CO2)
# Corresponds to a large household consuming ~600 kWh/month
MAX_CARBON_KG = 600.0 * EMISSION_FACTOR  # 492 kg

BLEND_RAW = 0.6
BLEND_PERCENTILE = 0.4


@dataclass
class SustainabilityScore:
    household_id: str
    period_start: datetime
    period_end: datetime
    total_kwh: float
    carbon_kg: float
    raw_score: float
    percentile_rank: float    # 0–100
    final_score: float        # 0–100
    grade: str                # A+/A/B/C/D
    cluster_key: str


def _grade(score: float) -> str:
    if score >= 85:
        return "A+"
    if score >= 70:
        return "A"
    if score >= 55:
        return "B"
    if score >= 40:
        return "C"
    return "D"


def _percentile_rank(carbon_kg: float, cluster_median: float, cluster_p75: float) -> float:
    """
    Estimate percentile rank in cluster.
    Better (lower carbon) → higher rank.
    Uses a simple piecewise linear map:
      carbon ≤ cluster_median/2 → 95th
      carbon ≤ cluster_median   → 75th
      carbon ≤ cluster_p75      → 50th
      carbon > cluster_p75      → 25th (floor)
    """
    if carbon_kg <= cluster_median / 2:
        return 95.0
    if carbon_kg <= cluster_median:
        # linear: median/2 → 95, median → 75
        t = (carbon_kg - cluster_median / 2) / (cluster_median - cluster_median / 2)
        return 95.0 - t * 20.0
    if carbon_kg <= cluster_p75:
        # linear: median → 75, p75 → 50
        t = (carbon_kg - cluster_median) / max(cluster_p75 - cluster_median, 1)
        return 75.0 - t * 25.0
    return 25.0


def score_household(
    total_kwh: float,
    cluster_median_kwh: float,
    cluster_p75_kwh: float,
    household_id: str,
    cluster_key: str,
    period_start: datetime,
    period_end: datetime,
) -> SustainabilityScore:
    """
    Compute sustainability score for a single household over a time period.

    Args:
        total_kwh:          Actual consumption for the period.
        cluster_median_kwh: Median consumption in this cluster (from benchmarks).
        cluster_p75_kwh:    75th-percentile consumption in this cluster.
        household_id:       UUID string.
        cluster_key:        e.g. "medium_3-4"
        period_start/end:   The billing/scoring window.
    """
    carbon_kg = total_kwh * EMISSION_FACTOR

    # Raw efficiency score: lower carbon → higher score
    raw_score = max(0.0, min(100.0, 100.0 * (1.0 - carbon_kg / MAX_CARBON_KG)))

    # Percentile rank vs cluster
    cluster_median_carbon = cluster_median_kwh * EMISSION_FACTOR
    cluster_p75_carbon = cluster_p75_kwh * EMISSION_FACTOR
    percentile = _percentile_rank(carbon_kg, cluster_median_carbon, cluster_p75_carbon)

    final = round(BLEND_RAW * raw_score + BLEND_PERCENTILE * percentile, 1)
    final = max(0.0, min(100.0, final))

    return SustainabilityScore(
        household_id=household_id,
        period_start=period_start,
        period_end=period_end,
        total_kwh=round(total_kwh, 2),
        carbon_kg=round(carbon_kg, 2),
        raw_score=round(raw_score, 1),
        percentile_rank=round(percentile, 1),
        final_score=final,
        grade=_grade(final),
        cluster_key=cluster_key,
    )


async def score_all_households(db, period_days: int = 30) -> list[SustainabilityScore]:
    """
    Score all households for the last `period_days`.
    Called nightly by Celery Beat.
    """
    from datetime import timedelta
    from shems.domains.household.models import Household
    from shems.ml.pipelines.sustainability_scoring.benchmark_calculator import (
        get_cluster_benchmarks,
    )
    from sqlalchemy import select

    now = datetime.now(timezone.utc)
    period_start = now - timedelta(days=period_days)

    store = FeatureStore(db)

    # Fetch cluster benchmarks (computed from all households)
    benchmarks = await get_cluster_benchmarks(db, lookback_days=period_days)

    result = await db.execute(
        select(
            Household.id,
            Household.square_footage,
            Household.occupant_count,
        )
    )
    households = result.fetchall()

    scores: list[SustainabilityScore] = []
    for h in households:
        cluster_key = FeatureStore.get_cluster_key(h.square_footage, h.occupant_count)
        bm = benchmarks.get(cluster_key, {"median_kwh": 300.0, "p75_kwh": 450.0})

        # Get total consumption for period
        total_kwh = await store.get_household_total_kwh(
            h.id, period_start, now
        )
        if total_kwh is None or total_kwh == 0.0:
            continue

        s = score_household(
            total_kwh=total_kwh,
            cluster_median_kwh=bm["median_kwh"],
            cluster_p75_kwh=bm["p75_kwh"],
            household_id=str(h.id),
            cluster_key=cluster_key,
            period_start=period_start,
            period_end=now,
        )
        scores.append(s)
        logger.debug(
            "Scored household=%s cluster=%s kwh=%.1f score=%.1f grade=%s",
            h.id, cluster_key, total_kwh, s.final_score, s.grade,
        )

    logger.info("Sustainability scoring complete — %d households scored", len(scores))
    return scores
