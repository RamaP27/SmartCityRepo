"""
Cluster benchmark calculator.

Computes median and 75th-percentile consumption per cluster so the scorer
can rank a household against its peers.

Clusters are defined by FeatureStore.get_cluster_key():
  size (small/medium/large) × occupancy (1-2/3-4/5+) = 9 clusters
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

import numpy as np

from shems.ml.feature_store import FeatureStore

logger = logging.getLogger(__name__)


async def get_cluster_benchmarks(
    db,
    lookback_days: int = 30,
) -> dict[str, dict[str, float]]:
    """
    Returns a dict keyed by cluster_key with:
      { "median_kwh": float, "p75_kwh": float, "count": int }

    Falls back to sensible defaults if a cluster has fewer than 5 households.
    """
    from datetime import timedelta
    from shems.domains.household.models import EnergyReading, Household
    from sqlalchemy import func, select

    now = datetime.now(timezone.utc)
    since = now - timedelta(days=lookback_days)

    # Aggregate total kWh per household over the lookback window
    stmt = (
        select(
            Household.id,
            Household.square_footage,
            Household.occupant_count,
            func.coalesce(
                func.sum(EnergyReading.consumption_kwh), 0.0
            ).label("total_kwh"),
        )
        .outerjoin(
            EnergyReading,
            (EnergyReading.household_id == Household.id)
            & (EnergyReading.timestamp >= since),
        )
        .group_by(Household.id, Household.square_footage, Household.occupant_count)
    )
    result = await db.execute(stmt)
    rows = result.fetchall()

    # Group by cluster_key
    cluster_data: dict[str, list[float]] = {}
    for row in rows:
        key = FeatureStore.get_cluster_key(row.square_footage, row.occupant_count)
        cluster_data.setdefault(key, []).append(float(row.total_kwh))

    benchmarks: dict[str, dict[str, float]] = {}
    for key, values in cluster_data.items():
        arr = np.array(values)
        count = len(arr)
        if count < 5:
            # Too few data points; use a generic default
            benchmarks[key] = _default_benchmark(key)
            logger.debug(
                "Cluster %s has only %d households, using defaults", key, count
            )
        else:
            benchmarks[key] = {
                "median_kwh": float(np.median(arr)),
                "p75_kwh": float(np.percentile(arr, 75)),
                "count": count,
            }
            logger.debug(
                "Cluster %s: n=%d median=%.1f p75=%.1f kWh",
                key, count, benchmarks[key]["median_kwh"], benchmarks[key]["p75_kwh"],
            )

    return benchmarks


def _default_benchmark(cluster_key: str) -> dict[str, float]:
    """
    Fallback benchmarks when cluster has insufficient data.
    Based on Indian residential consumption averages (30-day figures).
    """
    _defaults = {
        "small_1-2":   {"median_kwh": 80.0,  "p75_kwh": 110.0, "count": 0},
        "small_3-4":   {"median_kwh": 110.0, "p75_kwh": 150.0, "count": 0},
        "small_5+":    {"median_kwh": 140.0, "p75_kwh": 190.0, "count": 0},
        "medium_1-2":  {"median_kwh": 130.0, "p75_kwh": 180.0, "count": 0},
        "medium_3-4":  {"median_kwh": 180.0, "p75_kwh": 240.0, "count": 0},
        "medium_5+":   {"median_kwh": 230.0, "p75_kwh": 300.0, "count": 0},
        "large_1-2":   {"median_kwh": 200.0, "p75_kwh": 270.0, "count": 0},
        "large_3-4":   {"median_kwh": 270.0, "p75_kwh": 360.0, "count": 0},
        "large_5+":    {"median_kwh": 350.0, "p75_kwh": 460.0, "count": 0},
    }
    return _defaults.get(cluster_key, {"median_kwh": 200.0, "p75_kwh": 300.0, "count": 0})
