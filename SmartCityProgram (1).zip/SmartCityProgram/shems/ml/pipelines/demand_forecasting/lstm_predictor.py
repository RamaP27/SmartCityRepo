"""
LSTM demand forecasting predictor (Week 13).

Replaces GBR for 1h and 6h horizons when an LSTM model exists in the registry.
Falls back transparently to the GBR predictor if no LSTM model is found.

Cascade:
  1. Try lstm_forecast registry for the horizon.
  2. If miss → fall through to GBR forecast registry.
  3. If both miss → return nothing for that horizon.
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
import torch

from shems.ml.model_registry import ModelRegistry
from shems.ml.pipelines.demand_forecasting.feature_engineering import (
    FEATURE_COLS,
    build_inference_features,
)
from shems.ml.pipelines.demand_forecasting.lstm_dataset import SEQ_LEN
from shems.ml.pipelines.demand_forecasting.predictor import ForecastResult

logger = logging.getLogger(__name__)

Z95 = 1.96

# Horizons handled by LSTM (1h and 6h)
LSTM_HORIZONS = {
    "1h": 1,
    "6h": 6,
}


def forecast_zone_lstm(
    zone_id: uuid.UUID,
    recent_df: pd.DataFrame,
) -> list[ForecastResult]:
    """
    Generate LSTM-based forecasts for 1h and 6h horizons.
    Falls back to GBR if no LSTM model is registered.
    Returns [] on cold start.
    """
    if recent_df.empty or len(recent_df) < SEQ_LEN + 10:
        return []

    features_df = build_inference_features(recent_df)
    if features_df.empty:
        return []

    now = datetime.now(timezone.utc)
    results = []

    for label, horizon_hours in LSTM_HORIZONS.items():
        model_key = f"{zone_id}_{label}"
        bundle = ModelRegistry.load("lstm_forecast", model_key)

        if bundle is None:
            # Fall back to GBR predictor
            from shems.ml.pipelines.demand_forecasting.predictor import HORIZON_MAP
            gbr_bundle = ModelRegistry.load("forecast", model_key)
            if gbr_bundle is not None:
                X = features_df.tail(1)[FEATURE_COLS].values
                X_scaled = gbr_bundle.scaler.transform(X)
                pred = float(gbr_bundle.model.predict(X_scaled)[0])
                pred = max(0.0, pred)
                margin = Z95 * gbr_bundle.std_residuals
                results.append(ForecastResult(
                    zone_id=zone_id,
                    forecast_timestamp=now + timedelta(hours=horizon_hours),
                    horizon_hours=horizon_hours,
                    predicted_load_kw=round(pred, 2),
                    confidence_lower=round(max(0.0, pred - margin), 2),
                    confidence_upper=round(pred + margin, 2),
                    model_version="gbr-v1",
                ))
            logger.debug("LSTM miss for zone=%s horizon=%s — used GBR fallback", zone_id, label)
            continue

        # LSTM inference
        try:
            model = bundle.build_model()
            X_raw = features_df.tail(SEQ_LEN)[FEATURE_COLS].values.astype("float32")

            if len(X_raw) < SEQ_LEN:
                # Pad with first row if not enough history
                pad = np.repeat(X_raw[:1], SEQ_LEN - len(X_raw), axis=0)
                X_raw = np.vstack([pad, X_raw])

            X_scaled = bundle.scaler.transform(X_raw).astype("float32")
            X_tensor = torch.from_numpy(X_scaled).unsqueeze(0)  # (1, seq_len, features)

            pred = float(model.predict(X_tensor).item())
            pred = max(0.0, pred)
            margin = Z95 * bundle.std_residuals

            results.append(ForecastResult(
                zone_id=zone_id,
                forecast_timestamp=now + timedelta(hours=horizon_hours),
                horizon_hours=horizon_hours,
                predicted_load_kw=round(pred, 2),
                confidence_lower=round(max(0.0, pred - margin), 2),
                confidence_upper=round(pred + margin, 2),
                model_version="lstm-v1",
            ))
        except Exception as exc:
            logger.error(
                "LSTM inference failed zone=%s horizon=%s: %s", zone_id, label, exc
            )

    return results


def forecast_zone_all_horizons(
    zone_id: uuid.UUID,
    recent_df: pd.DataFrame,
) -> list[ForecastResult]:
    """
    Unified forecaster: LSTM for 1h/6h + GBR for 24h/48h.
    Replaces the original forecast_zone() function in the predictor.
    """
    from shems.ml.pipelines.demand_forecasting.predictor import (
        HORIZON_MAP,
        forecast_zone as gbr_forecast_zone,
    )

    # LSTM handles 1h and 6h
    lstm_results = forecast_zone_lstm(zone_id, recent_df)
    lstm_horizons = {r.horizon_hours for r in lstm_results}

    # GBR handles remaining horizons (24h, 48h) + any LSTM misses
    gbr_results = gbr_forecast_zone(zone_id, recent_df)
    gbr_filtered = [r for r in gbr_results if r.horizon_hours not in lstm_horizons]

    return lstm_results + gbr_filtered
