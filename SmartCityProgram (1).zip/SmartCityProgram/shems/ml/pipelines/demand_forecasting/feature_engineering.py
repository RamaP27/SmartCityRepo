"""
Demand forecasting feature engineering.

Input:  DataFrame[timestamp, current_load_kw]
Output: DataFrame with FEATURE_COLS + target column 'target_load_kw'

Features:
  - Cyclic time encodings (hour, day, week, month)
  - Lag features (1h, 6h, 24h, 7d back from current slot)
  - Rolling statistics (mean/std over last 24h)
  - Boolean flags (is_weekend, is_peak_hour)
"""
from math import pi

import numpy as np
import pandas as pd

FEATURE_COLS = [
    "hour_sin", "hour_cos",
    "day_sin", "day_cos",
    "week_sin", "week_cos",
    "month_sin", "month_cos",
    "is_weekend",
    "is_peak_hour",
    "lag_1h",       # 4 slots back
    "lag_6h",       # 24 slots back
    "lag_24h",      # 96 slots back
    "lag_7d",       # 672 slots back
    "rolling_mean_24h",
    "rolling_std_24h",
]


def build_features(df: pd.DataFrame, target_shift: int = 1) -> pd.DataFrame:
    """
    Build feature matrix for training.

    target_shift: how many 15-min slots ahead to predict.
      1  → next 15 min (1h model uses 4 predictions)
      4  → 1h ahead
      24 → 6h ahead
      96 → 24h ahead
      192→ 48h ahead
    """
    if df.empty:
        return df

    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = df.sort_values("timestamp").reset_index(drop=True)

    hour = df["timestamp"].dt.hour
    day = df["timestamp"].dt.dayofweek
    week = df["timestamp"].dt.isocalendar().week.astype(int)
    month = df["timestamp"].dt.month

    df["hour_sin"] = np.sin(2 * pi * hour / 24)
    df["hour_cos"] = np.cos(2 * pi * hour / 24)
    df["day_sin"] = np.sin(2 * pi * day / 7)
    df["day_cos"] = np.cos(2 * pi * day / 7)
    df["week_sin"] = np.sin(2 * pi * week / 52)
    df["week_cos"] = np.cos(2 * pi * week / 52)
    df["month_sin"] = np.sin(2 * pi * (month - 1) / 12)
    df["month_cos"] = np.cos(2 * pi * (month - 1) / 12)

    df["is_weekend"] = (day >= 5).astype(float)
    df["is_peak_hour"] = hour.apply(lambda h: 1.0 if (6 <= h < 10 or 18 <= h < 22) else 0.0)

    # Lag features (shift by n slots of 15-min intervals)
    df["lag_1h"] = df["current_load_kw"].shift(4)
    df["lag_6h"] = df["current_load_kw"].shift(24)
    df["lag_24h"] = df["current_load_kw"].shift(96)
    df["lag_7d"] = df["current_load_kw"].shift(672)

    # Rolling stats over last 24h (96 slots)
    df["rolling_mean_24h"] = df["current_load_kw"].rolling(96, min_periods=24).mean()
    df["rolling_std_24h"] = (
        df["current_load_kw"].rolling(96, min_periods=24).std().fillna(1.0).clip(lower=0.01)
    )

    # Target: load n slots ahead
    df["target_load_kw"] = df["current_load_kw"].shift(-target_shift)

    return df.dropna(subset=FEATURE_COLS + ["target_load_kw"])


def build_inference_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Build features for the current last row (for real-time prediction).
    No target column; returns only FEATURE_COLS.
    """
    if df.empty:
        return df

    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = df.sort_values("timestamp").reset_index(drop=True)

    hour = df["timestamp"].dt.hour
    day = df["timestamp"].dt.dayofweek
    week = df["timestamp"].dt.isocalendar().week.astype(int)
    month = df["timestamp"].dt.month

    df["hour_sin"] = np.sin(2 * pi * hour / 24)
    df["hour_cos"] = np.cos(2 * pi * hour / 24)
    df["day_sin"] = np.sin(2 * pi * day / 7)
    df["day_cos"] = np.cos(2 * pi * day / 7)
    df["week_sin"] = np.sin(2 * pi * week / 52)
    df["week_cos"] = np.cos(2 * pi * week / 52)
    df["month_sin"] = np.sin(2 * pi * (month - 1) / 12)
    df["month_cos"] = np.cos(2 * pi * (month - 1) / 12)

    df["is_weekend"] = (day >= 5).astype(float)
    df["is_peak_hour"] = hour.apply(lambda h: 1.0 if (6 <= h < 10 or 18 <= h < 22) else 0.0)

    df["lag_1h"] = df["current_load_kw"].shift(4).fillna(method="bfill")
    df["lag_6h"] = df["current_load_kw"].shift(24).fillna(method="bfill")
    df["lag_24h"] = df["current_load_kw"].shift(96).fillna(method="bfill")
    df["lag_7d"] = df["current_load_kw"].shift(672).fillna(method="bfill")

    df["rolling_mean_24h"] = df["current_load_kw"].rolling(96, min_periods=1).mean()
    df["rolling_std_24h"] = (
        df["current_load_kw"].rolling(96, min_periods=1).std().fillna(1.0).clip(lower=0.01)
    )

    return df.dropna(subset=FEATURE_COLS)
