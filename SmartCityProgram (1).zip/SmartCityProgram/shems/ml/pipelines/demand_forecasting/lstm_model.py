"""
LSTM Forecast Model — PyTorch Lightning LightningModule.

Architecture:
  Input  → LSTM(hidden=256, layers=2, dropout=0.2)
         → Linear(256 → 64) + ReLU
         → Linear(64 → 1)

Training details:
  - Loss:      Huber loss (robust to outliers in grid load spikes)
  - Optimiser: AdamW with lr=1e-3, weight_decay=1e-4
  - Scheduler: CosineAnnealingLR over max_epochs
  - Gradient clipping: max_norm=1.0 (prevents exploding gradients in LSTM)

Replaces GradientBoostingRegressor for 1h and 6h horizons at grid scale.
GBR remains for 24h and 48h (less sequential data needed for longer horizon).
"""
from __future__ import annotations

import torch
import torch.nn as nn
import lightning as L
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR

from shems.ml.pipelines.demand_forecasting.lstm_dataset import SEQ_LEN
from shems.ml.pipelines.demand_forecasting.feature_engineering import FEATURE_COLS

N_FEATURES = len(FEATURE_COLS)


class LSTMForecastModel(L.LightningModule):
    """
    Two-layer LSTM with a two-layer MLP head for grid load forecasting.
    Predicts a single scalar: load_kw `horizon` steps ahead.
    """

    def __init__(
        self,
        n_features: int = N_FEATURES,
        hidden_size: int = 256,
        num_layers: int = 2,
        dropout: float = 0.2,
        lr: float = 1e-3,
        weight_decay: float = 1e-4,
        max_epochs: int = 50,
    ):
        super().__init__()
        self.save_hyperparameters()

        self.lstm = nn.LSTM(
            input_size=n_features,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.head = nn.Sequential(
            nn.Linear(hidden_size, 64),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(64, 1),
        )
        self.loss_fn = nn.HuberLoss(delta=50.0)   # delta in kW units

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, n_features)
        lstm_out, _ = self.lstm(x)
        # Take the last timestep's hidden state
        last = lstm_out[:, -1, :]       # (batch, hidden_size)
        out = self.head(last).squeeze(-1)  # (batch,)
        return torch.clamp(out, min=0.0)   # Load must be non-negative

    def training_step(self, batch, batch_idx):
        x, y = batch
        y_hat = self(x)
        loss = self.loss_fn(y_hat, y)
        self.log("train_loss", loss, on_step=False, on_epoch=True, prog_bar=True)
        return loss

    def validation_step(self, batch, batch_idx):
        x, y = batch
        y_hat = self(x)
        loss = self.loss_fn(y_hat, y)
        # MAE for interpretability
        mae = torch.mean(torch.abs(y_hat - y))
        self.log("val_loss", loss, on_epoch=True, prog_bar=True)
        self.log("val_mae_kw", mae, on_epoch=True, prog_bar=True)

    def configure_optimizers(self):
        optimiser = AdamW(
            self.parameters(),
            lr=self.hparams.lr,
            weight_decay=self.hparams.weight_decay,
        )
        scheduler = CosineAnnealingLR(
            optimiser,
            T_max=self.hparams.max_epochs,
            eta_min=1e-6,
        )
        return {
            "optimizer": optimiser,
            "lr_scheduler": {"scheduler": scheduler, "interval": "epoch"},
        }

    def predict(self, x: torch.Tensor) -> torch.Tensor:
        """Inference convenience method (no grad)."""
        self.eval()
        with torch.no_grad():
            return self(x)
