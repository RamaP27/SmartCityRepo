"""
Demand forecasting predictor — called every hour by Celery Beat.

For each zone × horizon, generates a DemandForecast record with
95% confidence interval estimated from training residual std.
"""
import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd

from shems.ml.model_registry import ModelRegistry
from shems.ml.pipelines.demand_forecasting.feature_engineering import (
    FEATURE_COLS,
    build_inference_features,
)

logger = logging.getLogger(__name__)

# 95% CI multiplier
Z95 = 1.96

HORIZON_MAP = {
    "1h": 1,
    "6h": 6,
    "24h": 24,
    "48h": 48,
}


@dataclass
class ForecastResult:
    zone_id: uuid.UUID
    forecast_timestamp: datetime
    horizon_hours: int
    predicted_load_kw: float
    confidence_lower: float
    confidence_upper: float
    model_version: str = "v1"


def forecast_zone(
    zone_id: uuid.UUID,
    recent_df: pd.DataFrame,
) -> list[ForecastResult]:
    """
    Generate DemandForecast records for all 4 horizons for a zone.
    Returns empty list if models are not trained yet.
    """
    if recent_df.empty:
        return []

    features_df = build_inference_features(recent_df)
    if features_df.empty:
        return []

    now = datetime.now(timezone.utc)
    results = []

    for label, horizon_hours in HORIZON_MAP.items():
        model_key = f"{zone_id}_{label}"
        bundle = ModelRegistry.load("forecast", model_key)
        if bundle is None:
            logger.debug("No forecast model for zone=%s horizon=%s", zone_id, label)
            continue

        # Use latest feature row for prediction
        X = features_df.tail(1)[FEATURE_COLS].values
        X_scaled = bundle.scaler.transform(X)
        pred = float(bundle.model.predict(X_scaled)[0])
        pred = max(0.0, pred)

        margin = Z95 * bundle.std_residuals
        results.append(
            ForecastResult(
                zone_id=zone_id,
                forecast_timestamp=now + timedelta(hours=horizon_hours),
                horizon_hours=horizon_hours,
                predicted_load_kw=round(pred, 2),
                confidence_lower=round(max(0.0, pred - margin), 2),
                confidence_upper=round(pred + margin, 2),
            )
        )

    return results


async def forecast_all_zones(db) -> int:
    """Run forecasting for all zones. Persists DemandForecast records. Returns count."""
    from shems.domains.grid.models import DemandForecast, GridZone
    from shems.ml.feature_store import FeatureStore
    from sqlalchemy import select

    store = FeatureStore(db)
    result = await db.execute(select(GridZone.id, GridZone.zone_name, GridZone.peak_capacity_kw))
    zones = result.fetchall()

    total_forecasts = 0
    auto_dr_candidates: list[tuple] = []  # (zone_id, predicted_load_kw, peak_capacity_kw)

    for zone in zones:
        recent_df = await store.get_recent_zone_readings(zone.id, n_readings=700)
        forecast_results = forecast_zone(zone.id, recent_df)

        for fr in forecast_results:
            db.add(
                DemandForecast(
                    zone_id=fr.zone_id,
                    forecast_timestamp=fr.forecast_timestamp,
                    horizon_hours=fr.horizon_hours,
                    predicted_load_kw=fr.predicted_load_kw,
                    confidence_lower=fr.confidence_lower,
                    confidence_upper=fr.confidence_upper,
                    model_version=fr.model_version,
                    generated_at=datetime.now(timezone.utc),
                )
            )
            total_forecasts += 1

            # Flag zones where 1h forecast exceeds 85% capacity
            if fr.horizon_hours == 1:
                utilization = fr.predicted_load_kw / zone.peak_capacity_kw
                if utilization >= 0.85:
                    auto_dr_candidates.append(
                        (zone.id, fr.predicted_load_kw, zone.peak_capacity_kw)
                    )

        if forecast_results:
            await db.commit()

    if auto_dr_candidates:
        logger.warning(
            "Demand spike predicted for %d zones — auto-DR candidates: %s",
            len(auto_dr_candidates),
            [(str(z[0]), f"{z[1]:.0f}/{z[2]:.0f} kW") for z in auto_dr_candidates],
        )

    logger.info("Demand forecasting complete — %d records generated", total_forecasts)
    return total_forecasts
