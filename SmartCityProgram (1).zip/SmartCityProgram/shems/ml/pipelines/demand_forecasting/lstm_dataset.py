"""
PyTorch Dataset for LSTM demand forecasting.

Input:  DataFrame[timestamp, current_load_kw]  (15-min intervals)
Output: Sliding-window tensors (X: seq_len × n_features, y: scalar)

Features fed to LSTM (same cyclic encodings as GBR pipeline):
  hour_sin, hour_cos, day_sin, day_cos, week_sin, week_cos,
  month_sin, month_cos, is_weekend, is_peak_hour,
  lag_1h, lag_6h, lag_24h, rolling_mean_24h, rolling_std_24h

Target: current_load_kw shifted `horizon_slots` steps ahead (e.g. 4 = 1h).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from shems.ml.pipelines.demand_forecasting.feature_engineering import (
    FEATURE_COLS,
    build_features,
)

# LSTM uses a 96-slot (24h) lookback window
SEQ_LEN = 96


class GridLoadDataset(Dataset):
    """
    Sliding-window dataset over a zone's historical load readings.

    Each sample:
      X: float32 tensor of shape (SEQ_LEN, n_features)
      y: float32 scalar — load `horizon_slots` steps ahead
    """

    def __init__(
        self,
        df: pd.DataFrame,
        horizon_slots: int = 4,          # 4 slots = 1h ahead
        seq_len: int = SEQ_LEN,
        scaler=None,
    ):
        features_df = build_features(df, target_shift=horizon_slots)
        if features_df.empty:
            self._X = np.empty((0, len(FEATURE_COLS)), dtype=np.float32)
            self._y = np.empty((0,), dtype=np.float32)
            return

        X_raw = features_df[FEATURE_COLS].values.astype(np.float32)
        y_raw = features_df["target_load_kw"].values.astype(np.float32)

        if scaler is not None:
            X_raw = scaler.transform(X_raw).astype(np.float32)

        # Build sliding windows
        n = len(X_raw)
        X_windows, y_windows = [], []
        for i in range(seq_len, n):
            X_windows.append(X_raw[i - seq_len : i])
            y_windows.append(y_raw[i])

        self._X = np.stack(X_windows).astype(np.float32) if X_windows else np.empty((0, seq_len, len(FEATURE_COLS)), dtype=np.float32)
        self._y = np.array(y_windows, dtype=np.float32)
        self.seq_len = seq_len
        self.n_features = len(FEATURE_COLS)

    def __len__(self) -> int:
        return len(self._y)

    def __getitem__(self, idx: int):
        return (
            torch.from_numpy(self._X[idx]),
            torch.tensor(self._y[idx], dtype=torch.float32),
        )
