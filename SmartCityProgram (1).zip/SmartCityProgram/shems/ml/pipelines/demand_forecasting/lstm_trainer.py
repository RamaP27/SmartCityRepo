"""
LSTM demand forecasting trainer (Week 13).

Trains one LSTMForecastModel per zone per short-horizon (1h, 6h).
GBR models remain for 24h and 48h.

Saves with ModelRegistry under model_type="lstm_forecast", key="{zone_id}_{label}"

Minimum data requirement: 10,000 rows (≈ 104 days of 15-min readings)
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass

import numpy as np
import torch
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, random_split

from shems.ml.model_registry import ModelRegistry
from shems.ml.pipelines.demand_forecasting.lstm_dataset import (
    SEQ_LEN,
    GridLoadDataset,
)
from shems.ml.pipelines.demand_forecasting.lstm_model import LSTMForecastModel
from shems.ml.pipelines.demand_forecasting.feature_engineering import FEATURE_COLS

logger = logging.getLogger(__name__)

# Only replace GBR for the two short horizons
LSTM_HORIZONS = [
    ("1h", 4,  1),
    ("6h", 24, 6),
]

_MIN_ROWS = 10_000       # ~104 days
_BATCH_SIZE = 256
_MAX_EPOCHS = 50
_VAL_FRACTION = 0.15
_EARLY_STOP_PATIENCE = 7


@dataclass
class LSTMBundle:
    """Serialisable bundle stored in ModelRegistry."""
    scaler: StandardScaler
    model_state: dict        # torch state_dict — avoids pickling the full model
    hparams: dict
    mae_kw: float
    std_residuals: float

    def build_model(self) -> LSTMForecastModel:
        model = LSTMForecastModel(**self.hparams)
        model.load_state_dict(self.model_state)
        model.eval()
        return model


async def train_lstm_all_zones(db, min_rows: int = _MIN_ROWS) -> int:
    """Train LSTM for all zones. Returns count of zones trained."""
    from shems.domains.grid.models import GridZone
    from shems.ml.feature_store import FeatureStore
    from sqlalchemy import select

    store = FeatureStore(db)
    result = await db.execute(select(GridZone.id, GridZone.zone_name))
    zones = result.fetchall()

    trained = 0
    for zone in zones:
        ok = await train_lstm_zone(store, zone.id, zone.zone_name, min_rows)
        if ok:
            trained += 1

    logger.info("LSTM training complete — %d zones trained", trained)
    return trained


async def train_lstm_zone(
    store,
    zone_id: uuid.UUID,
    zone_name: str,
    min_rows: int = _MIN_ROWS,
) -> bool:
    import pandas as pd
    from shems.ml.pipelines.demand_forecasting.feature_engineering import build_features

    df = await store.get_zone_training_data(zone_id, lookback_days=120)
    if df.empty or len(df) < min_rows:
        logger.info(
            "LSTM: zone %s has only %d rows (need %d), skipping",
            zone_name, len(df), min_rows,
        )
        return False

    trained_any = False
    for label, horizon_slots, horizon_hours in LSTM_HORIZONS:
        bundle = _fit_lstm(df, zone_name, label, horizon_slots)
        if bundle is None:
            continue

        model_key = f"{zone_id}_{label}"
        ModelRegistry.save(
            model_type="lstm_forecast",
            key=model_key,
            model=bundle,
            metadata={
                "zone_id": str(zone_id),
                "zone_name": zone_name,
                "horizon_label": label,
                "horizon_hours": horizon_hours,
                "mae_kw": round(bundle.mae_kw, 2),
                "architecture": "LSTM-2L-256H",
            },
        )
        logger.info(
            "LSTM trained zone=%s horizon=%s MAE=%.2f kW",
            zone_name, label, bundle.mae_kw,
        )
        trained_any = True

    return trained_any


def _fit_lstm(df, zone_name: str, label: str, horizon_slots: int) -> LSTMBundle | None:
    from shems.ml.pipelines.demand_forecasting.feature_engineering import build_features

    # Fit scaler on raw feature values (without windowing)
    features_df = build_features(df, target_shift=horizon_slots)
    if len(features_df) < SEQ_LEN + 100:
        logger.warning("LSTM: insufficient rows after feature engineering for %s %s", zone_name, label)
        return None

    X_raw = features_df[FEATURE_COLS].values.astype("float32")
    scaler = StandardScaler()
    scaler.fit(X_raw)

    # Build dataset with scaled features
    dataset = GridLoadDataset(df, horizon_slots=horizon_slots, scaler=scaler)
    if len(dataset) < 200:
        return None

    n_val = max(50, int(len(dataset) * _VAL_FRACTION))
    n_train = len(dataset) - n_val
    train_ds, val_ds = random_split(
        dataset, [n_train, n_val],
        generator=torch.Generator().manual_seed(42),
    )

    train_loader = DataLoader(train_ds, batch_size=_BATCH_SIZE, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_ds, batch_size=_BATCH_SIZE, shuffle=False, num_workers=0)

    hparams = {
        "n_features": len(FEATURE_COLS),
        "hidden_size": 256,
        "num_layers": 2,
        "dropout": 0.2,
        "lr": 1e-3,
        "weight_decay": 1e-4,
        "max_epochs": _MAX_EPOCHS,
    }
    model = LSTMForecastModel(**hparams)

    try:
        import lightning as L
        from lightning.pytorch.callbacks import EarlyStopping, ModelCheckpoint

        trainer = L.Trainer(
            max_epochs=_MAX_EPOCHS,
            gradient_clip_val=1.0,
            enable_progress_bar=False,
            enable_model_summary=False,
            log_every_n_steps=10,
            callbacks=[
                EarlyStopping(monitor="val_loss", patience=_EARLY_STOP_PATIENCE, mode="min"),
            ],
        )
        trainer.fit(model, train_loader, val_loader)
    except Exception as exc:
        logger.error("LSTM training failed for %s %s: %s", zone_name, label, exc)
        return None

    # Compute MAE + std_residuals on validation set
    model.eval()
    all_preds, all_targets = [], []
    with torch.no_grad():
        for xb, yb in val_loader:
            preds = model(xb).numpy()
            all_preds.extend(preds.tolist())
            all_targets.extend(yb.numpy().tolist())

    preds_arr = np.array(all_preds)
    targets_arr = np.array(all_targets)
    mae = float(np.mean(np.abs(preds_arr - targets_arr)))
    std_res = float(np.std(targets_arr - preds_arr))

    return LSTMBundle(
        scaler=scaler,
        model_state=model.state_dict(),
        hparams=hparams,
        mae_kw=mae,
        std_residuals=std_res,
    )
