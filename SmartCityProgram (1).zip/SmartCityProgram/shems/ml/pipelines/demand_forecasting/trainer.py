"""
Demand forecasting trainer.

Strategy:
  - Direct multi-step: train one GradientBoostingRegressor per zone per horizon
  - Horizons: 4 (1h), 24 (6h), 96 (24h), 192 (48h) → 4 models per zone
  - Requires ≥30 days of zone load data
  - Saves with ModelRegistry under model_type="forecast", key="{zone_id}_{horizon}h"
"""
import logging
import uuid
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from shems.ml.model_registry import ModelRegistry
from shems.ml.pipelines.demand_forecasting.feature_engineering import (
    FEATURE_COLS,
    build_features,
)

logger = logging.getLogger(__name__)

# (label, target_shift in 15-min slots, horizon_hours for DemandForecast)
HORIZONS = [
    ("1h", 4, 1),
    ("6h", 24, 6),
    ("24h", 96, 24),
    ("48h", 192, 48),
]


@dataclass
class ForecastBundle:
    scaler: StandardScaler
    model: GradientBoostingRegressor
    mae: float          # training MAE (kW)
    std_residuals: float  # for confidence interval estimation


async def train_all_zones(db, min_rows: int = 5000) -> int:
    """Train forecasting models for every zone. Returns count of trained zones."""
    from shems.domains.grid.models import GridZone
    from shems.ml.feature_store import FeatureStore
    from sqlalchemy import select

    store = FeatureStore(db)
    result = await db.execute(select(GridZone.id, GridZone.zone_name))
    zones = result.fetchall()

    trained_count = 0
    for zone in zones:
        ok = await train_zone(store, zone.id, zone.zone_name, min_rows)
        if ok:
            trained_count += 1

    logger.info("Demand forecast training complete — %d zones trained", trained_count)
    return trained_count


async def train_zone(
    store, zone_id: uuid.UUID, zone_name: str, min_rows: int = 5000
) -> bool:
    df = await store.get_zone_training_data(zone_id, lookback_days=90)
    if df.empty or len(df) < min_rows:
        logger.info(
            "Zone %s has only %d rows (need %d), skipping", zone_name, len(df), min_rows
        )
        return False

    trained_horizons = 0
    for label, shift, horizon_hours in HORIZONS:
        features_df = build_features(df, target_shift=shift)
        if len(features_df) < 1000:
            continue

        bundle = _fit(features_df, zone_name, label)
        model_key = f"{zone_id}_{label}"
        ModelRegistry.save(
            model_type="forecast",
            key=model_key,
            model=bundle,
            metadata={
                "zone_id": str(zone_id),
                "zone_name": zone_name,
                "horizon_label": label,
                "horizon_hours": horizon_hours,
                "n_training_rows": len(features_df),
                "mae_kw": round(bundle.mae, 2),
            },
        )
        trained_horizons += 1
        logger.info(
            "Trained forecast zone=%s horizon=%s rows=%d MAE=%.2f kW",
            zone_name, label, len(features_df), bundle.mae,
        )

    return trained_horizons > 0


def _fit(features_df: pd.DataFrame, zone_name: str, label: str) -> ForecastBundle:
    X = features_df[FEATURE_COLS].values
    y = features_df["target_load_kw"].values

    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.15, shuffle=False
    )

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_val_s = scaler.transform(X_val)

    model = GradientBoostingRegressor(
        n_estimators=300,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.8,
        min_samples_leaf=20,
        random_state=42,
    )
    model.fit(X_train_s, y_train)

    preds = model.predict(X_val_s)
    mae = float(mean_absolute_error(y_val, preds))
    std_res = float(np.std(y_val - preds))

    return ForecastBundle(scaler=scaler, model=model, mae=mae, std_residuals=std_res)
