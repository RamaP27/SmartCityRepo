"""
Anomaly detection predictor — called every 15 minutes by Celery.

Severity thresholds (decision_function — lower = more anomalous):
  score < -0.10 → LOW
  score < -0.20 → MEDIUM
  score < -0.35 → HIGH
  score < -0.50 → CRITICAL
"""
import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

import pandas as pd

from shems.ml.model_registry import ModelRegistry
from shems.ml.pipelines.anomaly_detection.feature_engineering import (
    FEATURE_COLS,
    latest_window_features,
)

logger = logging.getLogger(__name__)

SEVERITY_THRESHOLDS = [
    (-0.50, "CRITICAL"),
    (-0.35, "HIGH"),
    (-0.20, "MEDIUM"),
    (-0.10, "LOW"),
]


@dataclass
class AnomalyResult:
    household_id: uuid.UUID
    anomaly_score: float
    severity: str | None   # None means no anomaly
    detected_at: datetime


def _score_to_severity(score: float) -> str | None:
    for threshold, severity in SEVERITY_THRESHOLDS:
        if score < threshold:
            return severity
    return None


def score_household(
    household_id: uuid.UUID,
    cluster_key: str,
    recent_df: pd.DataFrame,
) -> AnomalyResult:
    """
    Score the most-recent reading for a household.
    Returns AnomalyResult with severity=None if no anomaly detected or model missing.
    """
    bundle = ModelRegistry.load("anomaly", cluster_key)
    if bundle is None:
        logger.debug("No anomaly model for cluster=%s, skipping household=%s", cluster_key, household_id)
        return AnomalyResult(
            household_id=household_id,
            anomaly_score=0.0,
            severity=None,
            detected_at=datetime.now(timezone.utc),
        )

    features = latest_window_features(recent_df)
    if features.empty or not all(c in features.columns for c in FEATURE_COLS):
        return AnomalyResult(
            household_id=household_id,
            anomaly_score=0.0,
            severity=None,
            detected_at=datetime.now(timezone.utc),
        )

    score = float(bundle.score(features)[0])
    severity = _score_to_severity(score)

    return AnomalyResult(
        household_id=household_id,
        anomaly_score=round(score, 4),
        severity=severity,
        detected_at=datetime.now(timezone.utc),
    )


async def score_zone_households(
    db,
    zone_id: uuid.UUID,
) -> list[AnomalyResult]:
    """Score all households in a zone and return anomalous ones."""
    from shems.ml.feature_store import FeatureStore

    store = FeatureStore(db)
    households = await store.get_all_households_for_zone(zone_id)
    results = []

    for h in households:
        cluster_key = FeatureStore.get_cluster_key(h["square_footage"], h["occupant_count"])
        recent_df = await store.get_recent_household_readings(h["id"], n_readings=672)
        result = score_household(h["id"], cluster_key, recent_df)
        if result.severity is not None:
            results.append(result)

    logger.info(
        "Scored zone=%s households=%d anomalies=%d",
        zone_id, len(households), len(results),
    )
    return results
