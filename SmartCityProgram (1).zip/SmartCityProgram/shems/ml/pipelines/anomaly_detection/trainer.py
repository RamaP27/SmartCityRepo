"""
Anomaly detection trainer.

Strategy:
  - Group households by (size_bucket × occupant_bucket) → 9 clusters
  - Train one IsolationForest per cluster on 30 days of readings
  - Save with ModelRegistry under model_type="anomaly", key=cluster_key
  - Called by Celery Beat weekly
"""
import logging
import uuid

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

from shems.ml.model_registry import ModelRegistry
from shems.ml.pipelines.anomaly_detection.feature_engineering import (
    FEATURE_COLS,
    build_features,
)

logger = logging.getLogger(__name__)

# Wrap model + scaler together so predictor can use them as a unit
class AnomalyBundle:
    def __init__(self, scaler: StandardScaler, model: IsolationForest):
        self.scaler = scaler
        self.model = model

    def score(self, features: pd.DataFrame) -> np.ndarray:
        X = self.scaler.transform(features[FEATURE_COLS])
        return self.model.decision_function(X)   # lower = more anomalous


async def train_all_clusters(db, min_rows: int = 2000):
    """
    Train anomaly models for every cluster that has enough data.
    Called by the weekly Celery task.
    """
    from shems.domains.household.models import Household
    from shems.ml.feature_store import FeatureStore
    from sqlalchemy import select

    store = FeatureStore(db)
    result = await db.execute(
        select(Household.id, Household.occupant_count, Household.square_footage)
    )
    households = result.fetchall()

    # Group household IDs by cluster key
    clusters: dict[str, list[uuid.UUID]] = {}
    for h in households:
        key = FeatureStore.get_cluster_key(h.square_footage, h.occupant_count)
        clusters.setdefault(key, []).append(h.id)

    trained = 0
    for cluster_key, household_ids in clusters.items():
        frames = []
        for hid in household_ids[:50]:   # cap at 50 households per cluster
            df = await store.get_household_training_data(hid, lookback_days=30)
            if not df.empty:
                frames.append(df)

        if not frames:
            continue

        combined = pd.concat(frames, ignore_index=True)
        features = build_features(combined)
        if len(features) < min_rows:
            logger.info(
                "Cluster %s has only %d rows, skipping (need %d)",
                cluster_key, len(features), min_rows,
            )
            continue

        bundle = _fit(features)
        ModelRegistry.save(
            model_type="anomaly",
            key=cluster_key,
            model=bundle,
            metadata={
                "cluster": cluster_key,
                "n_households": len(household_ids),
                "n_training_rows": len(features),
            },
        )
        trained += 1
        logger.info("Trained anomaly model for cluster=%s rows=%d", cluster_key, len(features))

    logger.info("Anomaly training complete — %d models saved", trained)
    return trained


def _fit(features: pd.DataFrame) -> AnomalyBundle:
    X = features[FEATURE_COLS].values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = IsolationForest(
        n_estimators=200,
        contamination=0.02,   # assume 2% of readings are anomalous
        max_samples="auto",
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X_scaled)
    return AnomalyBundle(scaler=scaler, model=model)
