"""
Anomaly detection feature engineering.

Input:  DataFrame[timestamp, consumption_kwh, is_peak_hour]
Output: DataFrame with FEATURE_COLS ready for IsolationForest
"""
from math import pi

import numpy as np
import pandas as pd

FEATURE_COLS = [
    "consumption_kwh",
    "rolling_mean_7d",
    "z_score",
    "is_peak_hour",
    "hour_sin",
    "hour_cos",
    "day_sin",
    "day_cos",
    "month_sin",
    "month_cos",
]


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Full feature pipeline. Returns a clean DataFrame with FEATURE_COLS."""
    if df.empty:
        return df

    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = df.sort_values("timestamp").reset_index(drop=True)

    # Time-based cyclic features
    hour = df["timestamp"].dt.hour
    day = df["timestamp"].dt.dayofweek
    month = df["timestamp"].dt.month

    df["hour_sin"] = np.sin(2 * pi * hour / 24)
    df["hour_cos"] = np.cos(2 * pi * hour / 24)
    df["day_sin"] = np.sin(2 * pi * day / 7)
    df["day_cos"] = np.cos(2 * pi * day / 7)
    df["month_sin"] = np.sin(2 * pi * (month - 1) / 12)
    df["month_cos"] = np.cos(2 * pi * (month - 1) / 12)

    # Rolling mean on the same 15-min slot across past 7 days.
    # Use a simple 7-day rolling window (min_periods=48 = 12h minimum)
    df = df.set_index("timestamp")
    rolling = df["consumption_kwh"].rolling("7D", min_periods=48)
    df["rolling_mean_7d"] = rolling.mean()
    df["rolling_std_7d"] = rolling.std().fillna(1.0).clip(lower=0.001)
    df = df.reset_index()

    df["z_score"] = (
        (df["consumption_kwh"] - df["rolling_mean_7d"]) / df["rolling_std_7d"]
    ).clip(-10, 10)

    df["is_peak_hour"] = df["is_peak_hour"].astype(float)

    return df.dropna(subset=FEATURE_COLS)


def latest_window_features(df: pd.DataFrame) -> pd.DataFrame:
    """Return features for the most-recent reading only (for real-time inference)."""
    features = build_features(df)
    if features.empty:
        return features
    return features.tail(1).reset_index(drop=True)
