"""
Phase 2 ML Celery tasks.

Schedule (managed via celery_app.py beat schedule):
  - run_anomaly_detection     every 15 min  (real-time household scoring)
  - run_demand_forecasting    every hour    (zone demand forecasts)
  - run_sustainability_scoring nightly      (monthly carbon scores)
  - run_model_training        weekly        (retrain all models)
"""
import asyncio
import logging

from shems.celery_app import celery_app
from shems.database import AsyncSessionLocal

logger = logging.getLogger(__name__)


# ── Anomaly detection — every 15 min ─────────────────────────────────────────

@celery_app.task(name="shems.ml.tasks.run_anomaly_detection", bind=True, max_retries=2)
def run_anomaly_detection(self):
    """Score all households across all zones for anomalous consumption."""
    asyncio.run(_anomaly_detection_inner())


async def _anomaly_detection_inner():
    from shems.domains.grid.models import AnomalyType, GridZone
    from shems.domains.household.models import Household
    from shems.domains.sustainability.models import CarbonScore
    from shems.ml.pipelines.anomaly_detection.predictor import score_zone_households
    from shems.domains.grid.manager import GridManager
    from sqlalchemy import select

    async with AsyncSessionLocal() as db:
        result = await db.execute(select(GridZone.id))
        zone_ids = [row[0] for row in result.fetchall()]

        grid_mgr = GridManager(db)
        total_anomalies = 0

        for zone_id in zone_ids:
            anomaly_results = await score_zone_households(db, zone_id)

            for ar in anomaly_results:
                if ar.severity is None:
                    continue
                # Fetch zone for the household
                h_result = await db.execute(
                    select(Household.district_id).where(Household.id == ar.household_id)
                )
                h_zone_id = h_result.scalar_one_or_none() or zone_id

                await grid_mgr.create_anomaly_alert(
                    zone_id=h_zone_id,
                    household_id=ar.household_id,
                    anomaly_score=ar.anomaly_score,
                    severity=ar.severity,
                    anomaly_type=AnomalyType.UNUSUAL_PATTERN,
                )
                total_anomalies += 1

            if anomaly_results:
                await db.commit()

        logger.info("Anomaly detection run complete — %d alerts persisted", total_anomalies)


# ── Demand forecasting — every hour ──────────────────────────────────────────

@celery_app.task(name="shems.ml.tasks.run_demand_forecasting", bind=True, max_retries=2)
def run_demand_forecasting(self):
    """Generate demand forecasts for all grid zones."""
    asyncio.run(_demand_forecasting_inner())


async def _demand_forecasting_inner():
    from shems.ml.pipelines.demand_forecasting.predictor import forecast_all_zones

    async with AsyncSessionLocal() as db:
        count = await forecast_all_zones(db)
        logger.info("Demand forecasting run complete — %d forecast records", count)


# ── Sustainability scoring — nightly ──────────────────────────────────────────

@celery_app.task(name="shems.ml.tasks.run_sustainability_scoring", bind=True, max_retries=1)
def run_sustainability_scoring(self):
    """Compute and persist carbon scores for all households."""
    asyncio.run(_sustainability_scoring_inner())


async def _sustainability_scoring_inner():
    from datetime import timezone
    from datetime import datetime
    from shems.domains.sustainability.manager import SustainabilityManager
    from shems.ml.pipelines.sustainability_scoring.scorer import score_all_households
    from shems.ml.pipelines.sustainability_scoring.benchmark_calculator import (
        get_cluster_benchmarks,
    )

    async with AsyncSessionLocal() as db:
        scores = await score_all_households(db, period_days=30)
        mgr = SustainabilityManager(db)

        for s in scores:
            import uuid
            await mgr.upsert_score(
                household_id=uuid.UUID(s.household_id),
                period_start=s.period_start,
                period_end=s.period_end,
                total_kwh=s.total_kwh,
                carbon_kg=s.carbon_kg,
                score=s.final_score,
                grade=s.grade,
                percentile_rank=s.percentile_rank,
                cluster_key=s.cluster_key,
            )

        # Also persist cluster benchmarks
        benchmarks = await get_cluster_benchmarks(db, lookback_days=30)
        now = datetime.now(timezone.utc)
        from datetime import timedelta
        period_start = now - timedelta(days=30)
        for cluster_key, bm in benchmarks.items():
            await mgr.upsert_benchmark(
                cluster_key=cluster_key,
                period_start=period_start,
                period_end=now,
                median_kwh=bm["median_kwh"],
                p75_kwh=bm["p75_kwh"],
                sample_size=bm.get("count", 0),
            )

        await db.commit()
        logger.info(
            "Sustainability scoring run complete — %d scores, %d benchmarks",
            len(scores), len(benchmarks),
        )


# ── Model training — weekly ───────────────────────────────────────────────────

@celery_app.task(name="shems.ml.tasks.run_model_training", bind=True, max_retries=1)
def run_model_training(self):
    """Retrain anomaly detection and demand forecasting models."""
    asyncio.run(_model_training_inner())


async def _model_training_inner():
    from shems.ml.pipelines.anomaly_detection.trainer import train_all_clusters
    from shems.ml.pipelines.demand_forecasting.trainer import train_all_zones

    async with AsyncSessionLocal() as db:
        anomaly_clusters = await train_all_clusters(db)
        forecast_zones = await train_all_zones(db)
        logger.info(
            "Model training complete — %d anomaly clusters, %d forecast zones",
            anomaly_clusters, forecast_zones,
        )
