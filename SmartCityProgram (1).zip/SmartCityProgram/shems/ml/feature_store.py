"""
Two-tier Feature Store:
  Hot tier  — Redis cache (15-min TTL) for real-time inference
  Warm tier — TimescaleDB queries for training batch data
"""
import json
import uuid
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from shems.core.cache.redis_client import get_redis
from shems.domains.household.models import EnergyReading, Household

_CACHE_TTL = 900   # 15 minutes
_INDIA_EMISSION_FACTOR = 0.82   # kg CO2 per kWh (CEA 2023)


class FeatureStore:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ── Training data loaders ────────────────────────────────────────────────

    async def get_household_training_data(
        self,
        household_id: uuid.UUID,
        lookback_days: int = 30,
    ) -> pd.DataFrame:
        """Load historical 15-min readings for one household."""
        since = datetime.now(timezone.utc) - timedelta(days=lookback_days)
        result = await self.db.execute(
            select(
                EnergyReading.timestamp,
                EnergyReading.consumption_kwh,
                EnergyReading.is_peak_hour,
            )
            .where(
                and_(
                    EnergyReading.household_id == household_id,
                    EnergyReading.timestamp >= since,
                )
            )
            .order_by(EnergyReading.timestamp)
        )
        rows = result.fetchall()
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows, columns=["timestamp", "consumption_kwh", "is_peak_hour"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        return df

    async def get_zone_training_data(
        self,
        zone_id: uuid.UUID,
        lookback_days: int = 90,
    ) -> pd.DataFrame:
        """Load historical 15-min grid load readings for one zone."""
        from shems.domains.grid.models import GridLoadReading

        since = datetime.now(timezone.utc) - timedelta(days=lookback_days)
        result = await self.db.execute(
            select(
                GridLoadReading.timestamp,
                GridLoadReading.current_load_kw,
                GridLoadReading.capacity_utilization_pct,
            )
            .where(
                and_(
                    GridLoadReading.zone_id == zone_id,
                    GridLoadReading.timestamp >= since,
                )
            )
            .order_by(GridLoadReading.timestamp)
        )
        rows = result.fetchall()
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows, columns=["timestamp", "current_load_kw", "capacity_utilization_pct"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        return df

    async def get_all_households_for_zone(
        self, zone_id: uuid.UUID
    ) -> list[dict]:
        """Return list of household id/occupant_count/square_footage for a zone."""
        result = await self.db.execute(
            select(
                Household.id,
                Household.occupant_count,
                Household.square_footage,
            ).where(Household.district_id == zone_id)
        )
        return [
            {"id": r.id, "occupant_count": r.occupant_count, "square_footage": r.square_footage}
            for r in result.fetchall()
        ]

    async def get_recent_household_readings(
        self,
        household_id: uuid.UUID,
        n_readings: int = 672,  # ~1 week of 15-min readings
    ) -> pd.DataFrame:
        """Fetch the N most-recent readings for real-time inference."""
        result = await self.db.execute(
            select(
                EnergyReading.timestamp,
                EnergyReading.consumption_kwh,
                EnergyReading.is_peak_hour,
            )
            .where(EnergyReading.household_id == household_id)
            .order_by(EnergyReading.timestamp.desc())
            .limit(n_readings)
        )
        rows = result.fetchall()
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows, columns=["timestamp", "consumption_kwh", "is_peak_hour"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        return df.sort_values("timestamp").reset_index(drop=True)

    async def get_recent_zone_readings(
        self,
        zone_id: uuid.UUID,
        n_readings: int = 192,  # 48h of 15-min readings
    ) -> pd.DataFrame:
        """Fetch the N most-recent zone load readings for real-time inference."""
        from shems.domains.grid.models import GridLoadReading

        result = await self.db.execute(
            select(
                GridLoadReading.timestamp,
                GridLoadReading.current_load_kw,
            )
            .where(GridLoadReading.zone_id == zone_id)
            .order_by(GridLoadReading.timestamp.desc())
            .limit(n_readings)
        )
        rows = result.fetchall()
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows, columns=["timestamp", "current_load_kw"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        return df.sort_values("timestamp").reset_index(drop=True)

    # ── Redis hot-tier cache ─────────────────────────────────────────────────

    async def cache_features(self, key: str, features: dict) -> None:
        redis = await get_redis()
        await redis.setex(
            f"features:{key}", _CACHE_TTL, json.dumps(features, default=str)
        )

    async def get_cached_features(self, key: str) -> dict | None:
        redis = await get_redis()
        data = await redis.get(f"features:{key}")
        return json.loads(data) if data else None

    async def get_household_total_kwh(
        self,
        household_id: uuid.UUID,
        since: datetime,
        until: datetime,
    ) -> float:
        """Return total consumption_kwh for a household in [since, until)."""
        from sqlalchemy import func

        result = await self.db.execute(
            select(func.coalesce(func.sum(EnergyReading.consumption_kwh), 0.0))
            .where(
                and_(
                    EnergyReading.household_id == household_id,
                    EnergyReading.timestamp >= since,
                    EnergyReading.timestamp < until,
                )
            )
        )
        return float(result.scalar())

    # ── Helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def get_cluster_key(square_footage: int | None, occupant_count: int) -> str:
        """Map household attributes to a cluster label for model lookup."""
        sqft = square_footage or 1000
        if sqft < 800:
            size = "small"
        elif sqft <= 1800:
            size = "medium"
        else:
            size = "large"

        if occupant_count <= 2:
            occ = "1-2"
        elif occupant_count <= 4:
            occ = "3-4"
        else:
            occ = "5+"
        return f"{size}_{occ}"

    @staticmethod
    def emission_factor() -> float:
        return _INDIA_EMISSION_FACTOR
