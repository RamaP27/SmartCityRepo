"""
Simple file-based model registry backed by joblib.

Directory layout:
    models/
      anomaly/<cluster_key>.joblib
      forecast/<zone_id>_<horizon>h.joblib
      registry.json              ← metadata index
"""
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

import joblib

logger = logging.getLogger(__name__)

MODELS_DIR = Path(os.getenv("MODELS_DIR", "models"))

# In-memory cache: avoids repeated disk reads during a single worker lifetime
_cache: dict = {}


class ModelRegistry:

    @classmethod
    def save(cls, model_type: str, key: str, model, metadata: dict | None = None) -> str:
        model_dir = MODELS_DIR / model_type
        model_dir.mkdir(parents=True, exist_ok=True)

        model_path = model_dir / f"{key}.joblib"
        joblib.dump(model, model_path)

        registry = cls._load_index()
        registry[f"{model_type}/{key}"] = {
            "type": model_type,
            "key": key,
            "path": str(model_path),
            "saved_at": datetime.now(timezone.utc).isoformat(),
            "metadata": metadata or {},
        }
        cls._save_index(registry)
        _cache[f"{model_type}/{key}"] = model
        logger.info("Saved model %s/%s → %s", model_type, key, model_path)
        return str(model_path)

    @classmethod
    def load(cls, model_type: str, key: str):
        cache_key = f"{model_type}/{key}"
        if cache_key in _cache:
            return _cache[cache_key]

        model_path = MODELS_DIR / model_type / f"{key}.joblib"
        if not model_path.exists():
            logger.debug("Model not found: %s", model_path)
            return None

        model = joblib.load(model_path)
        _cache[cache_key] = model
        logger.info("Loaded model %s/%s from disk", model_type, key)
        return model

    @classmethod
    def exists(cls, model_type: str, key: str) -> bool:
        if f"{model_type}/{key}" in _cache:
            return True
        return (MODELS_DIR / model_type / f"{key}.joblib").exists()

    @classmethod
    def list_models(cls, model_type: str) -> list[dict]:
        return [v for v in cls._load_index().values() if v["type"] == model_type]

    @classmethod
    def evict_cache(cls) -> None:
        """Clear in-process model cache (useful for testing)."""
        _cache.clear()

    @classmethod
    def _load_index(cls) -> dict:
        idx_path = MODELS_DIR / "registry.json"
        if idx_path.exists():
            return json.loads(idx_path.read_text())
        return {}

    @classmethod
    def _save_index(cls, index: dict) -> None:
        MODELS_DIR.mkdir(parents=True, exist_ok=True)
        idx_path = MODELS_DIR / "registry.json"
        idx_path.write_text(json.dumps(index, indent=2))
