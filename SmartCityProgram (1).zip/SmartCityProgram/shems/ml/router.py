"""
ML inference and model status API.

Exposes:
  GET  /ml/models                 — list all registered models
  GET  /ml/anomaly/{household_id} — real-time anomaly score for one household
  GET  /ml/forecast/{zone_id}     — latest demand forecasts for a zone
  POST /ml/train                  — trigger ad-hoc training (admin only)
"""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from shems.dependencies import get_current_user, get_db
from shems.domains.auth.models import PersonaType, User
from shems.exceptions import ForbiddenException
from shems.ml.model_registry import ModelRegistry

router = APIRouter(prefix="/ml", tags=["ml"])


class ModelListResponse(BaseModel):
    models: list[dict]


class AnomalyScoreResponse(BaseModel):
    household_id: uuid.UUID
    anomaly_score: float
    severity: str | None
    detected_at: str


class ForecastResponse(BaseModel):
    zone_id: uuid.UUID
    horizon_hours: int
    predicted_load_kw: float
    confidence_lower: float
    confidence_upper: float
    forecast_timestamp: str


class TrainResponse(BaseModel):
    message: str
    anomaly_clusters_trained: int
    forecast_zones_trained: int


# ── Model registry ────────────────────────────────────────────────────────────

@router.get("/models", response_model=ModelListResponse)
async def list_models(
    current_user: User = Depends(get_current_user),
):
    """List all models in the registry. Grid managers only."""
    if current_user.persona_type != PersonaType.GRID_MANAGER:
        raise ForbiddenException("Model registry access requires GRID_MANAGER persona")
    models = ModelRegistry.list_models()
    return ModelListResponse(models=models)


# ── Real-time anomaly scoring ─────────────────────────────────────────────────

@router.get("/anomaly/{household_id}", response_model=AnomalyScoreResponse)
async def score_household_realtime(
    household_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Return a real-time anomaly score for a household.
    Homeowners may only query their own household.
    """
    from shems.domains.household.models import Household
    from shems.ml.feature_store import FeatureStore
    from shems.ml.pipelines.anomaly_detection.predictor import score_household
    from sqlalchemy import select

    # Access control
    if current_user.persona_type == PersonaType.HOMEOWNER:
        result = await db.execute(
            select(Household).where(Household.user_id == current_user.id)
        )
        hh = result.scalar_one_or_none()
        if not hh or hh.id != household_id:
            raise ForbiddenException("You may only view your own household anomaly score")

    # Fetch household metadata for cluster key
    result = await db.execute(
        select(Household).where(Household.id == household_id)
    )
    hh = result.scalar_one_or_none()
    if not hh:
        raise HTTPException(status_code=404, detail="Household not found")

    store = FeatureStore(db)
    cluster_key = FeatureStore.get_cluster_key(hh.square_footage, hh.occupant_count)
    recent_df = await store.get_recent_household_readings(household_id, n_readings=672)

    ar = score_household(household_id, cluster_key, recent_df)
    return AnomalyScoreResponse(
        household_id=ar.household_id,
        anomaly_score=ar.anomaly_score,
        severity=ar.severity,
        detected_at=ar.detected_at.isoformat(),
    )


# ── Latest demand forecasts ───────────────────────────────────────────────────

@router.get("/forecast/{zone_id}", response_model=list[ForecastResponse])
async def get_zone_forecast(
    zone_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Return the latest demand forecasts for a zone (all 4 horizons)."""
    if current_user.persona_type not in (PersonaType.GRID_MANAGER,):
        raise ForbiddenException("Forecast access requires GRID_MANAGER persona")

    from shems.ml.feature_store import FeatureStore
    from shems.ml.pipelines.demand_forecasting.predictor import forecast_zone

    store = FeatureStore(db)
    recent_df = await store.get_recent_zone_readings(zone_id, n_readings=700)
    results = forecast_zone(zone_id, recent_df)

    return [
        ForecastResponse(
            zone_id=fr.zone_id,
            horizon_hours=fr.horizon_hours,
            predicted_load_kw=fr.predicted_load_kw,
            confidence_lower=fr.confidence_lower,
            confidence_upper=fr.confidence_upper,
            forecast_timestamp=fr.forecast_timestamp.isoformat(),
        )
        for fr in results
    ]


# ── Ad-hoc training trigger ───────────────────────────────────────────────────

@router.post("/train", response_model=TrainResponse)
async def trigger_training(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Trigger ad-hoc model retraining. GRID_MANAGER only.
    Runs synchronously (may take several minutes on large datasets).
    """
    if current_user.persona_type != PersonaType.GRID_MANAGER:
        raise ForbiddenException("Training requires GRID_MANAGER persona")

    from shems.ml.pipelines.anomaly_detection.trainer import train_all_clusters
    from shems.ml.pipelines.demand_forecasting.trainer import train_all_zones

    anomaly_count = await train_all_clusters(db)
    forecast_count = await train_all_zones(db)

    return TrainResponse(
        message="Training complete",
        anomaly_clusters_trained=anomaly_count,
        forecast_zones_trained=forecast_count,
    )
