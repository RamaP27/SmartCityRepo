import hashlib
import uuid
from datetime import datetime, timezone

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from shems.domains.auth.models import Session, User


class AuthManager:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_email(self, email: str) -> User | None:
        result = await self.db.execute(select(User).where(User.email == email))
        return result.scalar_one_or_none()

    async def get_by_id(self, user_id: str | uuid.UUID) -> User | None:
        if isinstance(user_id, str):
            user_id = uuid.UUID(user_id)
        result = await self.db.execute(select(User).where(User.id == user_id))
        return result.scalar_one_or_none()

    async def create_user(self, email: str, hashed_password: str, persona_type: str) -> User:
        user = User(email=email, hashed_password=hashed_password, persona_type=persona_type)
        self.db.add(user)
        await self.db.commit()
        await self.db.refresh(user)
        return user

    async def create_session(
        self,
        user_id: uuid.UUID,
        access_token: str,
        refresh_token: str,
        expires_at: datetime,
        device_fingerprint: str | None = None,
    ) -> Session:
        session = Session(
            user_id=user_id,
            token_hash=self._hash_token(access_token),
            refresh_token_hash=self._hash_token(refresh_token),
            expires_at=expires_at,
            device_fingerprint=device_fingerprint,
        )
        self.db.add(session)
        await self.db.commit()
        await self.db.refresh(session)
        return session

    async def get_session_by_refresh_hash(self, refresh_token_hash: str) -> Session | None:
        result = await self.db.execute(
            select(Session).where(
                Session.refresh_token_hash == refresh_token_hash,
                Session.is_active == True,  # noqa: E712
            )
        )
        return result.scalar_one_or_none()

    async def invalidate_session(self, session_id: uuid.UUID) -> None:
        await self.db.execute(
            update(Session).where(Session.id == session_id).values(is_active=False)
        )
        await self.db.commit()

    async def invalidate_all_user_sessions(self, user_id: uuid.UUID) -> None:
        await self.db.execute(
            update(Session).where(Session.user_id == user_id).values(is_active=False)
        )
        await self.db.commit()

    @staticmethod
    def _hash_token(token: str) -> str:
        return hashlib.sha256(token.encode()).hexdigest()
