from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from shems.dependencies import get_current_user, get_db
from shems.domains.auth.manager import AuthManager
from shems.domains.auth.models import User
from shems.domains.auth.schemas import (
    LoginRequest,
    RefreshRequest,
    SignupRequest,
    TokenResponse,
    UserResponse,
    ValidateTokenRequest,
    ValidateTokenResponse,
)
from shems.domains.auth.service import AuthService

router = APIRouter()


def get_auth_service(db: AsyncSession = Depends(get_db)) -> AuthService:
    return AuthService(AuthManager(db))


@router.post("/signup", response_model=TokenResponse, status_code=201)
async def signup(
    request: SignupRequest,
    service: AuthService = Depends(get_auth_service),
):
    return await service.signup(request)


@router.post("/login", response_model=TokenResponse)
async def login(
    request: LoginRequest,
    service: AuthService = Depends(get_auth_service),
):
    return await service.login(request)


@router.post("/refresh", response_model=TokenResponse)
async def refresh(
    request: RefreshRequest,
    service: AuthService = Depends(get_auth_service),
):
    return await service.refresh(request.refresh_token)


@router.post("/logout", status_code=204)
async def logout(
    request: RefreshRequest | None = None,
    current_user: User = Depends(get_current_user),
    service: AuthService = Depends(get_auth_service),
):
    refresh_token = request.refresh_token if request else None
    await service.logout(current_user, refresh_token)


@router.post("/validate-token", response_model=ValidateTokenResponse)
async def validate_token(
    request: ValidateTokenRequest,
    service: AuthService = Depends(get_auth_service),
):
    return await service.validate_token(request.token)


@router.get("/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    return current_user
