import hashlib
from datetime import datetime, timedelta, timezone

from shems.config import settings
from shems.core.security.jwt_handler import (
    create_access_token,
    create_refresh_token,
    decode_refresh_token,
)
from shems.core.security.password import hash_password, verify_password
from shems.domains.auth.manager import AuthManager
from shems.domains.auth.models import User
from shems.domains.auth.schemas import (
    LoginRequest,
    SignupRequest,
    TokenResponse,
    ValidateTokenResponse,
)
from shems.exceptions import AlreadyExistsException, NotFoundException, UnauthorizedException


class AuthService:
    def __init__(self, manager: AuthManager):
        self.manager = manager

    async def signup(self, request: SignupRequest) -> TokenResponse:
        existing = await self.manager.get_by_email(request.email)
        if existing:
            raise AlreadyExistsException("User", "email")

        hashed = hash_password(request.password)
        user = await self.manager.create_user(request.email, hashed, request.persona_type)
        return await self._issue_tokens(user)

    async def login(self, request: LoginRequest) -> TokenResponse:
        user = await self.manager.get_by_email(request.email)
        if not user or not verify_password(request.password, user.hashed_password):
            raise UnauthorizedException("Invalid email or password")
        if not user.is_active:
            raise UnauthorizedException("Account is inactive")
        return await self._issue_tokens(user)

    async def refresh(self, refresh_token: str) -> TokenResponse:
        payload = decode_refresh_token(refresh_token)
        if not payload:
            raise UnauthorizedException("Invalid or expired refresh token")

        user = await self.manager.get_by_id(payload["sub"])
        if not user or not user.is_active:
            raise UnauthorizedException("User not found or inactive")

        refresh_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
        session = await self.manager.get_session_by_refresh_hash(refresh_hash)
        if not session:
            raise UnauthorizedException("Session not found or revoked")

        await self.manager.invalidate_session(session.id)
        return await self._issue_tokens(user)

    async def logout(self, user: User, refresh_token: str | None = None) -> None:
        if refresh_token:
            refresh_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
            session = await self.manager.get_session_by_refresh_hash(refresh_hash)
            if session:
                await self.manager.invalidate_session(session.id)
        else:
            await self.manager.invalidate_all_user_sessions(user.id)

    async def validate_token(self, token: str) -> ValidateTokenResponse:
        from shems.core.security.jwt_handler import decode_access_token
        payload = decode_access_token(token)
        if not payload:
            return ValidateTokenResponse(valid=False)
        user = await self.manager.get_by_id(payload["sub"])
        if not user or not user.is_active:
            return ValidateTokenResponse(valid=False)
        return ValidateTokenResponse(
            valid=True,
            user_id=str(user.id),
            persona_type=user.persona_type.value,
        )

    async def _issue_tokens(self, user: User) -> TokenResponse:
        access_token = create_access_token(
            subject=str(user.id), persona_type=user.persona_type.value
        )
        refresh_token = create_refresh_token(subject=str(user.id))
        expires_at = datetime.now(timezone.utc) + timedelta(
            days=settings.refresh_token_expire_days
        )
        await self.manager.create_session(
            user_id=user.id,
            access_token=access_token,
            refresh_token=refresh_token,
            expires_at=expires_at,
        )
        return TokenResponse(access_token=access_token, refresh_token=refresh_token)
