"""
Grid domain API routes — Priya (Grid Manager) persona.

All endpoints require GRID_MANAGER persona except zone listing.
"""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from shems.dependencies import get_current_user, get_db
from shems.domains.auth.models import PersonaType, User
from shems.domains.grid.schemas import (
    AnomalyAlertAcknowledgeRequest,
    AnomalyAlertResponse,
    DemandForecastResponse,
    DemandResponseEventCreate,
    DemandResponseEventResponse,
    GridZoneResponse,
    ZoneLoadSummaryResponse,
)
from shems.domains.grid.service import GridService
from shems.exceptions import ForbiddenException

router = APIRouter(prefix="/grid", tags=["grid"])


def _require_grid_manager(user: User) -> User:
    if user.persona_type != PersonaType.GRID_MANAGER:
        raise ForbiddenException("Grid management requires GRID_MANAGER persona")
    return user


# ── Zones ─────────────────────────────────────────────────────────────────────

@router.get("/zones", response_model=list[GridZoneResponse])
async def list_zones(
    _: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    svc = GridService(db)
    return await svc.list_zones()


@router.get("/zones/{zone_id}", response_model=GridZoneResponse)
async def get_zone(
    zone_id: uuid.UUID,
    _: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    svc = GridService(db)
    return await svc.get_zone(zone_id)


@router.get("/zones/{zone_id}/summary", response_model=ZoneLoadSummaryResponse)
async def get_zone_summary(
    zone_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _require_grid_manager(current_user)
    svc = GridService(db)
    return await svc.get_zone_load_summary(zone_id)


# ── Demand forecasts ──────────────────────────────────────────────────────────

@router.get("/zones/{zone_id}/forecasts", response_model=list[DemandForecastResponse])
async def get_latest_forecasts(
    zone_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _require_grid_manager(current_user)
    svc = GridService(db)
    return await svc.get_latest_forecasts(zone_id)


@router.get(
    "/zones/{zone_id}/forecasts/history", response_model=list[DemandForecastResponse]
)
async def get_forecast_history(
    zone_id: uuid.UUID,
    horizon_hours: int = Query(1, description="Forecast horizon: 1, 6, 24, or 48"),
    limit: int = Query(48, le=200),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _require_grid_manager(current_user)
    svc = GridService(db)
    return await svc.get_forecast_history(zone_id, horizon_hours, limit)


# ── Anomaly alerts ────────────────────────────────────────────────────────────

@router.get("/zones/{zone_id}/alerts", response_model=list[AnomalyAlertResponse])
async def list_alerts(
    zone_id: uuid.UUID,
    unacknowledged_only: bool = Query(False),
    limit: int = Query(50, le=200),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _require_grid_manager(current_user)
    svc = GridService(db)
    return await svc.list_alerts(zone_id, unacknowledged_only, limit)


@router.post("/alerts/{alert_id}/acknowledge", response_model=AnomalyAlertResponse)
async def acknowledge_alert(
    alert_id: uuid.UUID,
    body: AnomalyAlertAcknowledgeRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _require_grid_manager(current_user)
    svc = GridService(db)
    return await svc.acknowledge_alert(alert_id, current_user.id)


# ── Demand response events ────────────────────────────────────────────────────

@router.post(
    "/demand-response",
    response_model=DemandResponseEventResponse,
    status_code=201,
)
async def create_dr_event(
    data: DemandResponseEventCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _require_grid_manager(current_user)
    svc = GridService(db)
    return await svc.create_dr_event(data, triggered_by=current_user.id)


@router.get(
    "/zones/{zone_id}/demand-response",
    response_model=list[DemandResponseEventResponse],
)
async def list_dr_events(
    zone_id: uuid.UUID,
    limit: int = Query(20, le=100),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _require_grid_manager(current_user)
    svc = GridService(db)
    return await svc.list_dr_events(zone_id, limit)


@router.post(
    "/demand-response/{event_id}/complete",
    response_model=DemandResponseEventResponse,
)
async def complete_dr_event(
    event_id: uuid.UUID,
    actual_load_reduction_kw: float = Query(..., gt=0),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _require_grid_manager(current_user)
    svc = GridService(db)
    return await svc.complete_dr_event(event_id, actual_load_reduction_kw)
