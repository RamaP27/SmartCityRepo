"""Pydantic schemas for the grid domain (Priya persona — Grid Manager)."""
from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, field_validator


class GridZoneResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    zone_name: str
    district_code: str
    city: str
    total_households: int
    peak_capacity_kw: float
    created_at: datetime


class GridLoadReadingResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    zone_id: uuid.UUID
    timestamp: datetime
    current_load_kw: float
    capacity_utilization_pct: float
    source: str


class DemandForecastResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    zone_id: uuid.UUID
    forecast_timestamp: datetime
    horizon_hours: int
    predicted_load_kw: float
    confidence_lower: float
    confidence_upper: float
    model_version: str
    generated_at: datetime


class AnomalyAlertResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    zone_id: uuid.UUID
    household_id: uuid.UUID | None
    detected_at: datetime
    anomaly_type: str
    severity: str
    anomaly_score: float
    is_acknowledged: bool


class AnomalyAlertAcknowledgeRequest(BaseModel):
    acknowledged: bool = True


class DemandResponseEventCreate(BaseModel):
    zone_id: uuid.UUID
    target_load_reduction_kw: float
    incentive_offer_inr: float = 0.0
    started_at: datetime

    @field_validator("target_load_reduction_kw")
    @classmethod
    def positive_reduction(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("target_load_reduction_kw must be positive")
        return v


class DemandResponseEventResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    zone_id: uuid.UUID
    triggered_by: uuid.UUID
    trigger_type: str
    status: str
    target_load_reduction_kw: float
    actual_load_reduction_kw: float | None
    households_targeted: int
    incentive_offer_inr: float
    started_at: datetime
    ended_at: datetime | None
    created_at: datetime


class ZoneLoadSummaryResponse(BaseModel):
    """Current load summary for a zone."""
    zone_id: uuid.UUID
    zone_name: str
    current_load_kw: float | None
    peak_capacity_kw: float
    utilization_pct: float | None
    latest_forecast_1h: DemandForecastResponse | None
    active_dr_events: int
    unacknowledged_anomalies: int
