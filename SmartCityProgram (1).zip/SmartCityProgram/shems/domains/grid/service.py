"""
Grid domain service layer — business logic for Priya (Grid Manager) persona.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession

from shems.domains.grid.manager import GridManager
from shems.domains.grid.schemas import (
    DemandResponseEventCreate,
    ZoneLoadSummaryResponse,
)
from shems.exceptions import ForbiddenException, NotFoundException


class GridService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.mgr = GridManager(db)

    async def list_zones(self):
        return await self.mgr.list_zones()

    async def get_zone(self, zone_id: uuid.UUID):
        zone = await self.mgr.get_zone(zone_id)
        if not zone:
            raise NotFoundException(f"Grid zone {zone_id} not found")
        return zone

    async def get_zone_load_summary(self, zone_id: uuid.UUID) -> ZoneLoadSummaryResponse:
        zone = await self.get_zone(zone_id)

        latest_reading = await self.mgr.get_latest_load_reading(zone_id)
        current_load = latest_reading.current_load_kw if latest_reading else None
        utilization = latest_reading.capacity_utilization_pct if latest_reading else None

        forecasts = await self.mgr.get_latest_forecasts(zone_id)
        forecast_1h = next(
            (f for f in forecasts if f.horizon_hours == 1), None
        )

        active_dr = await self.mgr.count_active_dr_events(zone_id)
        unacked_anomalies = await self.mgr.count_unacknowledged(zone_id)

        return ZoneLoadSummaryResponse(
            zone_id=zone_id,
            zone_name=zone.zone_name,
            current_load_kw=current_load,
            peak_capacity_kw=zone.peak_capacity_kw,
            utilization_pct=utilization,
            latest_forecast_1h=forecast_1h,
            active_dr_events=active_dr,
            unacknowledged_anomalies=unacked_anomalies,
        )

    # ── Demand forecasts ──────────────────────────────────────────────────────

    async def get_latest_forecasts(self, zone_id: uuid.UUID):
        await self.get_zone(zone_id)   # 404 guard
        return await self.mgr.get_latest_forecasts(zone_id)

    async def get_forecast_history(
        self, zone_id: uuid.UUID, horizon_hours: int, limit: int = 48
    ):
        await self.get_zone(zone_id)
        return await self.mgr.get_forecast_history(zone_id, horizon_hours, limit)

    # ── Anomaly alerts ────────────────────────────────────────────────────────

    async def list_alerts(
        self, zone_id: uuid.UUID, unacknowledged_only: bool = False, limit: int = 50
    ):
        await self.get_zone(zone_id)
        return await self.mgr.list_zone_alerts(zone_id, unacknowledged_only, limit)

    async def acknowledge_alert(
        self, alert_id: uuid.UUID, user_id: uuid.UUID
    ):
        alert = await self.mgr.acknowledge_alert(alert_id, user_id)
        if not alert:
            raise NotFoundException(f"Anomaly alert {alert_id} not found")
        await self.db.commit()
        await self.db.refresh(alert)
        return alert

    # ── Demand response events ────────────────────────────────────────────────

    async def create_dr_event(
        self,
        data: DemandResponseEventCreate,
        triggered_by: uuid.UUID,
    ):
        await self.get_zone(data.zone_id)
        event = await self.mgr.create_dr_event(
            zone_id=data.zone_id,
            triggered_by=triggered_by,
            target_load_reduction_kw=data.target_load_reduction_kw,
            incentive_offer_inr=data.incentive_offer_inr,
            started_at=data.started_at,
        )
        await self.db.commit()
        await self.db.refresh(event)
        return event

    async def list_dr_events(self, zone_id: uuid.UUID, limit: int = 20):
        await self.get_zone(zone_id)
        return await self.mgr.list_dr_events(zone_id, limit)

    async def complete_dr_event(
        self,
        event_id: uuid.UUID,
        actual_load_reduction_kw: float,
    ):
        event = await self.mgr.complete_dr_event(event_id, actual_load_reduction_kw)
        if not event:
            raise NotFoundException(f"Demand response event {event_id} not found")
        await self.db.commit()
        await self.db.refresh(event)
        return event
