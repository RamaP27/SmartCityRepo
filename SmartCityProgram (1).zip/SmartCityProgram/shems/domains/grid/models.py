import enum
import uuid
from datetime import datetime

from sqlalchemy import DateTime, Enum as SAEnum, Float, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from shems.database import Base, TimestampMixin


class GridLoadSource(str, enum.Enum):
    SCADA = "SCADA"
    SYNTHETIC = "SYNTHETIC"
    ESTIMATED = "ESTIMATED"


class AnomalyType(str, enum.Enum):
    CONSUMPTION_SPIKE = "CONSUMPTION_SPIKE"
    METER_FAULT = "METER_FAULT"
    UNUSUAL_PATTERN = "UNUSUAL_PATTERN"
    GRID_STRESS = "GRID_STRESS"


class AlertSeverity(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class DRTriggerType(str, enum.Enum):
    MANUAL = "MANUAL"
    AUTOMATED_ML = "AUTOMATED_ML"
    SCHEDULED = "SCHEDULED"


class DRStatus(str, enum.Enum):
    PENDING = "PENDING"
    ACTIVE = "ACTIVE"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class GridZone(Base, TimestampMixin):
    __tablename__ = "grid_zones"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    zone_name: Mapped[str] = mapped_column(String(100), nullable=False)
    district_code: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    city: Mapped[str] = mapped_column(String(100), nullable=False)
    total_households: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    peak_capacity_kw: Mapped[float] = mapped_column(Float, nullable=False)


class GridLoadReading(Base):
    """TimescaleDB hypertable — partitioned on timestamp."""
    __tablename__ = "grid_load_readings"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    zone_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("grid_zones.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    current_load_kw: Mapped[float] = mapped_column(Float, nullable=False)
    capacity_utilization_pct: Mapped[float] = mapped_column(Float, nullable=False)
    source: Mapped[GridLoadSource] = mapped_column(
        SAEnum(GridLoadSource), nullable=False, default=GridLoadSource.SCADA
    )


class DemandForecast(Base, TimestampMixin):
    __tablename__ = "demand_forecasts"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    zone_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("grid_zones.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    forecast_timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    horizon_hours: Mapped[int] = mapped_column(Integer, nullable=False)
    predicted_load_kw: Mapped[float] = mapped_column(Float, nullable=False)
    confidence_lower: Mapped[float] = mapped_column(Float, nullable=False)
    confidence_upper: Mapped[float] = mapped_column(Float, nullable=False)
    model_version: Mapped[str] = mapped_column(String(50), nullable=False, default="v1")
    generated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class AnomalyAlert(Base, TimestampMixin):
    __tablename__ = "anomaly_alerts"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    zone_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("grid_zones.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    household_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("households.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    detected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    anomaly_type: Mapped[AnomalyType] = mapped_column(SAEnum(AnomalyType), nullable=False)
    severity: Mapped[AlertSeverity] = mapped_column(SAEnum(AlertSeverity), nullable=False)
    anomaly_score: Mapped[float] = mapped_column(Float, nullable=False)
    is_acknowledged: Mapped[bool] = mapped_column(
        __import__("sqlalchemy").Boolean, default=False, nullable=False
    )
    acknowledged_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )


class DemandResponseEvent(Base, TimestampMixin):
    __tablename__ = "demand_response_events"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    zone_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("grid_zones.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    triggered_by: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    trigger_type: Mapped[DRTriggerType] = mapped_column(SAEnum(DRTriggerType), nullable=False)
    status: Mapped[DRStatus] = mapped_column(
        SAEnum(DRStatus), nullable=False, default=DRStatus.PENDING
    )
    target_load_reduction_kw: Mapped[float] = mapped_column(Float, nullable=False)
    actual_load_reduction_kw: Mapped[float | None] = mapped_column(Float, nullable=True)
    households_targeted: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    incentive_offer_inr: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
