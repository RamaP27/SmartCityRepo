"""
Grid domain data-access layer.

Handles GridZone, DemandForecast, AnomalyAlert, and DemandResponseEvent records.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import and_, desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from shems.domains.grid.models import (
    AnomalyAlert,
    AnomalyType,
    DemandForecast,
    DemandResponseEvent,
    DRStatus,
    DRTriggerType,
    GridLoadReading,
    GridZone,
)


class GridManager:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ── GridZone ─────────────────────────────────────────────────────────────

    async def list_zones(self) -> list[GridZone]:
        result = await self.db.execute(select(GridZone).order_by(GridZone.zone_name))
        return list(result.scalars().all())

    async def get_zone(self, zone_id: uuid.UUID) -> GridZone | None:
        result = await self.db.execute(
            select(GridZone).where(GridZone.id == zone_id)
        )
        return result.scalar_one_or_none()

    # ── DemandForecast ────────────────────────────────────────────────────────

    async def get_latest_forecasts(
        self, zone_id: uuid.UUID
    ) -> list[DemandForecast]:
        """Return one forecast per horizon (most recently generated)."""
        # Subquery: max generated_at per horizon
        subq = (
            select(
                DemandForecast.horizon_hours,
                func.max(DemandForecast.generated_at).label("max_gen"),
            )
            .where(DemandForecast.zone_id == zone_id)
            .group_by(DemandForecast.horizon_hours)
            .subquery()
        )
        result = await self.db.execute(
            select(DemandForecast).join(
                subq,
                and_(
                    DemandForecast.zone_id == zone_id,
                    DemandForecast.horizon_hours == subq.c.horizon_hours,
                    DemandForecast.generated_at == subq.c.max_gen,
                ),
            )
        )
        return list(result.scalars().all())

    async def get_forecast_history(
        self,
        zone_id: uuid.UUID,
        horizon_hours: int,
        limit: int = 48,
    ) -> list[DemandForecast]:
        result = await self.db.execute(
            select(DemandForecast)
            .where(
                and_(
                    DemandForecast.zone_id == zone_id,
                    DemandForecast.horizon_hours == horizon_hours,
                )
            )
            .order_by(desc(DemandForecast.generated_at))
            .limit(limit)
        )
        return list(result.scalars().all())

    # ── AnomalyAlert ─────────────────────────────────────────────────────────

    async def create_anomaly_alert(
        self,
        zone_id: uuid.UUID,
        household_id: uuid.UUID,
        anomaly_score: float,
        severity: str,
        anomaly_type: AnomalyType = AnomalyType.UNUSUAL_PATTERN,
    ) -> AnomalyAlert:
        from shems.domains.grid.models import AlertSeverity

        alert = AnomalyAlert(
            zone_id=zone_id,
            household_id=household_id,
            detected_at=datetime.now(timezone.utc),
            anomaly_type=anomaly_type,
            severity=AlertSeverity(severity),
            anomaly_score=anomaly_score,
            is_acknowledged=False,
        )
        self.db.add(alert)
        return alert

    async def list_zone_alerts(
        self,
        zone_id: uuid.UUID,
        unacknowledged_only: bool = False,
        limit: int = 50,
    ) -> list[AnomalyAlert]:
        stmt = (
            select(AnomalyAlert)
            .where(AnomalyAlert.zone_id == zone_id)
            .order_by(desc(AnomalyAlert.detected_at))
            .limit(limit)
        )
        if unacknowledged_only:
            stmt = stmt.where(AnomalyAlert.is_acknowledged == False)  # noqa: E712
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def acknowledge_alert(
        self, alert_id: uuid.UUID, user_id: uuid.UUID
    ) -> AnomalyAlert | None:
        result = await self.db.execute(
            select(AnomalyAlert).where(AnomalyAlert.id == alert_id)
        )
        alert = result.scalar_one_or_none()
        if alert:
            alert.is_acknowledged = True
            alert.acknowledged_by = user_id
        return alert

    async def count_unacknowledged(self, zone_id: uuid.UUID) -> int:
        result = await self.db.execute(
            select(func.count(AnomalyAlert.id)).where(
                and_(
                    AnomalyAlert.zone_id == zone_id,
                    AnomalyAlert.is_acknowledged == False,  # noqa: E712
                )
            )
        )
        return result.scalar() or 0

    # ── DemandResponseEvent ───────────────────────────────────────────────────

    async def create_dr_event(
        self,
        zone_id: uuid.UUID,
        triggered_by: uuid.UUID,
        target_load_reduction_kw: float,
        incentive_offer_inr: float,
        started_at: datetime,
        trigger_type: DRTriggerType = DRTriggerType.MANUAL,
    ) -> DemandResponseEvent:
        # Count households in zone
        from shems.domains.household.models import Household

        count_result = await self.db.execute(
            select(func.count(Household.id)).where(
                Household.district_id == zone_id
            )
        )
        household_count = count_result.scalar() or 0

        event = DemandResponseEvent(
            zone_id=zone_id,
            triggered_by=triggered_by,
            trigger_type=trigger_type,
            status=DRStatus.PENDING,
            target_load_reduction_kw=target_load_reduction_kw,
            incentive_offer_inr=incentive_offer_inr,
            households_targeted=household_count,
            started_at=started_at,
        )
        self.db.add(event)
        return event

    async def list_dr_events(
        self, zone_id: uuid.UUID, limit: int = 20
    ) -> list[DemandResponseEvent]:
        result = await self.db.execute(
            select(DemandResponseEvent)
            .where(DemandResponseEvent.zone_id == zone_id)
            .order_by(desc(DemandResponseEvent.started_at))
            .limit(limit)
        )
        return list(result.scalars().all())

    async def complete_dr_event(
        self,
        event_id: uuid.UUID,
        actual_load_reduction_kw: float,
    ) -> DemandResponseEvent | None:
        result = await self.db.execute(
            select(DemandResponseEvent).where(DemandResponseEvent.id == event_id)
        )
        event = result.scalar_one_or_none()
        if event:
            event.status = DRStatus.COMPLETED
            event.actual_load_reduction_kw = actual_load_reduction_kw
            event.ended_at = datetime.now(timezone.utc)
        return event

    async def count_active_dr_events(self, zone_id: uuid.UUID) -> int:
        result = await self.db.execute(
            select(func.count(DemandResponseEvent.id)).where(
                and_(
                    DemandResponseEvent.zone_id == zone_id,
                    DemandResponseEvent.status.in_([DRStatus.PENDING, DRStatus.ACTIVE]),
                )
            )
        )
        return result.scalar() or 0

    # ── Load readings ─────────────────────────────────────────────────────────

    async def get_latest_load_reading(
        self, zone_id: uuid.UUID
    ) -> GridLoadReading | None:
        result = await self.db.execute(
            select(GridLoadReading)
            .where(GridLoadReading.zone_id == zone_id)
            .order_by(desc(GridLoadReading.timestamp))
            .limit(1)
        )
        return result.scalar_one_or_none()
