import uuid
from datetime import date, time

from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from shems.domains.tariff.models import RateWindow, TariffZone, WindowType


class TariffManager:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_zone_by_id(self, zone_id: uuid.UUID) -> TariffZone | None:
        result = await self.db.execute(
            select(TariffZone)
            .options(selectinload(TariffZone.rate_windows))
            .where(TariffZone.id == zone_id)
        )
        return result.scalar_one_or_none()

    async def list_zones(self) -> list[TariffZone]:
        result = await self.db.execute(
            select(TariffZone).options(selectinload(TariffZone.rate_windows))
        )
        return list(result.scalars().all())

    async def get_active_rate_window(
        self,
        zone_id: uuid.UUID,
        check_time: time,
        check_day: str,
        check_date: date,
    ) -> RateWindow | None:
        result = await self.db.execute(
            select(RateWindow).where(
                and_(
                    RateWindow.tariff_zone_id == zone_id,
                    RateWindow.effective_from <= check_date,
                    (RateWindow.effective_until == None) | (RateWindow.effective_until >= check_date),  # noqa: E711
                )
            )
        )
        windows = result.scalars().all()
        for window in windows:
            if check_day.upper() in [d.upper() for d in window.days_of_week]:
                if window.start_time <= check_time <= window.end_time:
                    return window
        return None

    async def get_upcoming_windows(
        self, zone_id: uuid.UUID, days: int = 7
    ) -> list[RateWindow]:
        today = date.today()
        result = await self.db.execute(
            select(RateWindow).where(
                and_(
                    RateWindow.tariff_zone_id == zone_id,
                    RateWindow.effective_from <= today,
                    (RateWindow.effective_until == None) | (RateWindow.effective_until >= today),  # noqa: E711
                )
            ).order_by(RateWindow.start_time)
        )
        return list(result.scalars().all())

    async def create_zone(self, **kwargs) -> TariffZone:
        zone = TariffZone(**kwargs)
        self.db.add(zone)
        await self.db.commit()
        await self.db.refresh(zone)
        return zone

    async def create_rate_window(self, tariff_zone_id: uuid.UUID, **kwargs) -> RateWindow:
        window = RateWindow(tariff_zone_id=tariff_zone_id, **kwargs)
        self.db.add(window)
        await self.db.commit()
        await self.db.refresh(window)
        return window
