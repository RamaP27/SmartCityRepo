import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from shems.dependencies import get_db
from shems.domains.tariff.manager import TariffManager
from shems.domains.tariff.schemas import CurrentRateResponse, RateWindowResponse, TariffZoneResponse
from shems.domains.tariff.service import TariffService

router = APIRouter()


def get_tariff_service(db: AsyncSession = Depends(get_db)) -> TariffService:
    return TariffService(TariffManager(db))


@router.get("/zones", response_model=list[TariffZoneResponse])
async def list_zones(service: TariffService = Depends(get_tariff_service)):
    return await service.list_zones()


@router.get("/zones/{zone_id}/current", response_model=CurrentRateResponse)
async def get_current_rate(
    zone_id: uuid.UUID,
    service: TariffService = Depends(get_tariff_service),
):
    return await service.get_current_rate(zone_id)


@router.get("/zones/{zone_id}/schedule", response_model=list[RateWindowResponse])
async def get_upcoming_windows(
    zone_id: uuid.UUID,
    days: int = 7,
    service: TariffService = Depends(get_tariff_service),
):
    return await service.get_upcoming_windows(zone_id, days)
