import uuid
from datetime import date, time

from pydantic import BaseModel, ConfigDict

from shems.domains.tariff.models import WindowType


class RateWindowResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    tariff_zone_id: uuid.UUID
    window_type: WindowType
    start_time: time
    end_time: time
    days_of_week: list
    rate_per_kwh: float
    effective_from: date
    effective_until: date | None


class TariffZoneResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    zone_name: str
    utility_provider: str
    currency: str
    rate_windows: list[RateWindowResponse] = []


class CurrentRateResponse(BaseModel):
    window_type: WindowType
    rate_per_kwh: float
    currency: str
    window_start: time
    window_end: time
