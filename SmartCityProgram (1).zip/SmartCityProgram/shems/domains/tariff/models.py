import enum
import uuid
from datetime import date, time

from sqlalchemy import Date, Enum as SAEnum, Float, ForeignKey, JSON, String, Time
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shems.database import Base, TimestampMixin


class WindowType(str, enum.Enum):
    PEAK = "PEAK"
    OFF_PEAK = "OFF_PEAK"
    SUPER_OFF_PEAK = "SUPER_OFF_PEAK"


class TariffZone(Base, TimestampMixin):
    __tablename__ = "tariff_zones"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    district_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    zone_name: Mapped[str] = mapped_column(String(100), nullable=False)
    utility_provider: Mapped[str] = mapped_column(String(100), nullable=False)
    currency: Mapped[str] = mapped_column(String(10), nullable=False, default="INR")

    rate_windows: Mapped[list["RateWindow"]] = relationship(
        back_populates="tariff_zone", cascade="all, delete-orphan"
    )


class RateWindow(Base, TimestampMixin):
    __tablename__ = "rate_windows"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tariff_zone_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tariff_zones.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    window_type: Mapped[WindowType] = mapped_column(SAEnum(WindowType), nullable=False)
    start_time: Mapped[time] = mapped_column(Time, nullable=False)
    end_time: Mapped[time] = mapped_column(Time, nullable=False)
    days_of_week: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    rate_per_kwh: Mapped[float] = mapped_column(Float, nullable=False)
    effective_from: Mapped[date] = mapped_column(Date, nullable=False)
    effective_until: Mapped[date | None] = mapped_column(Date, nullable=True)

    tariff_zone: Mapped["TariffZone"] = relationship(back_populates="rate_windows")
