import uuid
from datetime import date, datetime, timezone

from shems.domains.tariff.manager import TariffManager
from shems.domains.tariff.schemas import CurrentRateResponse, RateWindowResponse, TariffZoneResponse
from shems.exceptions import NotFoundException

DAY_MAP = {0: "MON", 1: "TUE", 2: "WED", 3: "THU", 4: "FRI", 5: "SAT", 6: "SUN"}


class TariffService:
    def __init__(self, manager: TariffManager):
        self.manager = manager

    async def list_zones(self) -> list[TariffZoneResponse]:
        zones = await self.manager.list_zones()
        return [TariffZoneResponse.model_validate(z) for z in zones]

    async def get_current_rate(self, zone_id: uuid.UUID) -> CurrentRateResponse:
        now = datetime.now(timezone.utc)
        check_time = now.time()
        check_day = DAY_MAP[now.weekday()]
        check_date = now.date()

        window = await self.manager.get_active_rate_window(
            zone_id, check_time, check_day, check_date
        )
        if not window:
            raise NotFoundException("Rate window for current time")

        zone = await self.manager.get_zone_by_id(zone_id)
        return CurrentRateResponse(
            window_type=window.window_type,
            rate_per_kwh=window.rate_per_kwh,
            currency=zone.currency if zone else "INR",
            window_start=window.start_time,
            window_end=window.end_time,
        )

    async def get_upcoming_windows(
        self, zone_id: uuid.UUID, days: int = 7
    ) -> list[RateWindowResponse]:
        windows = await self.manager.get_upcoming_windows(zone_id, days)
        return [RateWindowResponse.model_validate(w) for w in windows]
