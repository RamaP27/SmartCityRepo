import uuid
from datetime import datetime

from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from shems.domains.household.models import Device, DeviceSchedule, EnergyReading, Household


class HouseholdManager:
    def __init__(self, db: AsyncSession):
        self.db = db

    # --- Household ---

    async def get_by_user_id(self, user_id: uuid.UUID) -> Household | None:
        result = await self.db.execute(
            select(Household).where(Household.user_id == user_id)
        )
        return result.scalar_one_or_none()

    async def get_by_id(self, household_id: uuid.UUID) -> Household | None:
        result = await self.db.execute(
            select(Household).where(Household.id == household_id)
        )
        return result.scalar_one_or_none()

    async def create(self, user_id: uuid.UUID, **kwargs) -> Household:
        household = Household(user_id=user_id, **kwargs)
        self.db.add(household)
        await self.db.commit()
        await self.db.refresh(household)
        return household

    async def update(self, household: Household, **kwargs) -> Household:
        for key, value in kwargs.items():
            if value is not None:
                setattr(household, key, value)
        await self.db.commit()
        await self.db.refresh(household)
        return household

    # --- Devices ---

    async def get_device(self, device_id: uuid.UUID, household_id: uuid.UUID) -> Device | None:
        result = await self.db.execute(
            select(Device).where(
                Device.id == device_id, Device.household_id == household_id
            )
        )
        return result.scalar_one_or_none()

    async def list_devices(self, household_id: uuid.UUID) -> list[Device]:
        result = await self.db.execute(
            select(Device).where(Device.household_id == household_id).order_by(Device.created_at)
        )
        return list(result.scalars().all())

    async def create_device(self, household_id: uuid.UUID, **kwargs) -> Device:
        device = Device(household_id=household_id, **kwargs)
        self.db.add(device)
        await self.db.commit()
        await self.db.refresh(device)
        return device

    async def update_device(self, device: Device, **kwargs) -> Device:
        for key, value in kwargs.items():
            if value is not None:
                setattr(device, key, value)
        await self.db.commit()
        await self.db.refresh(device)
        return device

    async def delete_device(self, device: Device) -> None:
        await self.db.delete(device)
        await self.db.commit()

    # --- Energy Readings ---

    async def create_reading(self, **kwargs) -> EnergyReading:
        reading = EnergyReading(**kwargs)
        self.db.add(reading)
        await self.db.commit()
        await self.db.refresh(reading)
        return reading

    async def bulk_create_readings(self, readings: list[dict]) -> int:
        objects = [EnergyReading(**r) for r in readings]
        self.db.add_all(objects)
        await self.db.commit()
        return len(objects)

    async def get_readings(
        self,
        household_id: uuid.UUID,
        from_dt: datetime,
        to_dt: datetime,
        device_id: uuid.UUID | None = None,
    ) -> list[EnergyReading]:
        filters = [
            EnergyReading.household_id == household_id,
            EnergyReading.timestamp >= from_dt,
            EnergyReading.timestamp <= to_dt,
        ]
        if device_id:
            filters.append(EnergyReading.device_id == device_id)

        result = await self.db.execute(
            select(EnergyReading).where(and_(*filters)).order_by(EnergyReading.timestamp)
        )
        return list(result.scalars().all())

    # --- Schedules ---

    async def list_schedules(self, household_id: uuid.UUID) -> list[DeviceSchedule]:
        result = await self.db.execute(
            select(DeviceSchedule)
            .join(Device)
            .where(Device.household_id == household_id, DeviceSchedule.is_active == True)  # noqa: E712
        )
        return list(result.scalars().all())

    async def create_schedule(self, device_id: uuid.UUID, **kwargs) -> DeviceSchedule:
        schedule = DeviceSchedule(device_id=device_id, **kwargs)
        self.db.add(schedule)
        await self.db.commit()
        await self.db.refresh(schedule)
        return schedule

    async def get_schedule(
        self, schedule_id: uuid.UUID, household_id: uuid.UUID
    ) -> DeviceSchedule | None:
        result = await self.db.execute(
            select(DeviceSchedule)
            .join(Device)
            .where(DeviceSchedule.id == schedule_id, Device.household_id == household_id)
        )
        return result.scalar_one_or_none()

    async def deactivate_schedule(self, schedule: DeviceSchedule) -> None:
        schedule.is_active = False
        await self.db.commit()
