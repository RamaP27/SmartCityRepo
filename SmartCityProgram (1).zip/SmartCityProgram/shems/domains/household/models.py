import enum
import uuid
from datetime import datetime, time

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum as SAEnum,
    Float,
    ForeignKey,
    Integer,
    JSON,
    String,
    Time,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shems.database import Base, TimestampMixin


class EcosystemType(str, enum.Enum):
    GOOGLE_HOME = "GOOGLE_HOME"
    APPLE_HOMEKIT = "APPLE_HOMEKIT"
    ZIGBEE = "ZIGBEE"
    MANUAL = "MANUAL"


class DeviceType(str, enum.Enum):
    EV_CHARGER = "EV_CHARGER"
    HVAC = "HVAC"
    WASHER = "WASHER"
    DRYER = "DRYER"
    DISHWASHER = "DISHWASHER"
    LIGHTING = "LIGHTING"
    REFRIGERATOR = "REFRIGERATOR"
    WATER_HEATER = "WATER_HEATER"
    OTHER = "OTHER"


class ScheduleType(str, enum.Enum):
    OFF_PEAK_AUTO = "OFF_PEAK_AUTO"
    MANUAL = "MANUAL"
    AI_SUGGESTED = "AI_SUGGESTED"


class ReadingSource(str, enum.Enum):
    SMART_METER = "SMART_METER"
    DEVICE_API = "DEVICE_API"
    MANUAL_ENTRY = "MANUAL_ENTRY"


class Household(Base, TimestampMixin):
    __tablename__ = "households"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )
    address_hash: Mapped[str] = mapped_column(String(64), nullable=False)  # SHA-256, DPDP compliant
    district_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("grid_zones.id", ondelete="SET NULL"), nullable=True
    )
    smart_meter_id: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    ecosystem_type: Mapped[EcosystemType] = mapped_column(
        SAEnum(EcosystemType), nullable=False, default=EcosystemType.MANUAL
    )
    # OAuth tokens / MQTT credentials — encrypted at rest (AES-256 via app-layer encryption)
    ecosystem_credentials: Mapped[str | None] = mapped_column(
        __import__("sqlalchemy").Text, nullable=True
    )
    square_footage: Mapped[int | None] = mapped_column(Integer, nullable=True)
    occupant_count: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    devices: Mapped[list["Device"]] = relationship(
        back_populates="household", cascade="all, delete-orphan"
    )
    energy_readings: Mapped[list["EnergyReading"]] = relationship(
        back_populates="household", cascade="all, delete-orphan"
    )


class Device(Base, TimestampMixin):
    __tablename__ = "devices"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    household_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("households.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    external_device_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    device_type: Mapped[DeviceType] = mapped_column(SAEnum(DeviceType), nullable=False)
    rated_power_watts: Mapped[float | None] = mapped_column(Float, nullable=True)
    is_schedulable: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_online: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    ecosystem: Mapped[EcosystemType] = mapped_column(
        SAEnum(EcosystemType), nullable=False, default=EcosystemType.MANUAL
    )

    household: Mapped["Household"] = relationship(back_populates="devices")
    schedules: Mapped[list["DeviceSchedule"]] = relationship(
        back_populates="device", cascade="all, delete-orphan"
    )
    energy_readings: Mapped[list["EnergyReading"]] = relationship(back_populates="device")


class EnergyReading(Base):
    """TimescaleDB hypertable — partitioned on timestamp."""
    __tablename__ = "energy_readings"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    household_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("households.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    device_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("devices.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    consumption_kwh: Mapped[float] = mapped_column(Float, nullable=False)
    cost_estimate_inr: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    is_peak_hour: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    source: Mapped[ReadingSource] = mapped_column(
        SAEnum(ReadingSource), nullable=False, default=ReadingSource.SMART_METER
    )

    household: Mapped["Household"] = relationship(back_populates="energy_readings")
    device: Mapped["Device | None"] = relationship(back_populates="energy_readings")


class DeviceSchedule(Base, TimestampMixin):
    __tablename__ = "device_schedules"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("devices.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    schedule_type: Mapped[ScheduleType] = mapped_column(SAEnum(ScheduleType), nullable=False)
    start_time: Mapped[time] = mapped_column(Time, nullable=False)
    end_time: Mapped[time] = mapped_column(Time, nullable=False)
    days_of_week: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_by_ai: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    device: Mapped["Device"] = relationship(back_populates="schedules")
