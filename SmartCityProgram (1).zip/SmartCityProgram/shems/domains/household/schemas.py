import uuid
from datetime import datetime, time

from pydantic import BaseModel, ConfigDict, field_validator

from shems.domains.household.models import DeviceType, EcosystemType, ReadingSource, ScheduleType


# --- Household ---

class HouseholdCreate(BaseModel):
    address_hash: str
    smart_meter_id: str | None = None
    ecosystem_type: EcosystemType = EcosystemType.MANUAL
    square_footage: int | None = None
    occupant_count: int = 1


class HouseholdUpdate(BaseModel):
    smart_meter_id: str | None = None
    ecosystem_type: EcosystemType | None = None
    square_footage: int | None = None
    occupant_count: int | None = None


class HouseholdResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    user_id: uuid.UUID
    address_hash: str
    smart_meter_id: str | None
    ecosystem_type: EcosystemType
    square_footage: int | None
    occupant_count: int
    created_at: datetime


# --- Device ---

class DeviceCreate(BaseModel):
    name: str
    device_type: DeviceType
    rated_power_watts: float | None = None
    is_schedulable: bool = False
    ecosystem: EcosystemType = EcosystemType.MANUAL
    external_device_id: str | None = None


class DeviceUpdate(BaseModel):
    name: str | None = None
    rated_power_watts: float | None = None
    is_schedulable: bool | None = None
    is_online: bool | None = None


class DeviceResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    household_id: uuid.UUID
    name: str
    device_type: DeviceType
    rated_power_watts: float | None
    is_schedulable: bool
    is_online: bool
    ecosystem: EcosystemType
    created_at: datetime


# --- Energy Reading ---

class EnergyReadingResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    household_id: uuid.UUID
    device_id: uuid.UUID | None
    timestamp: datetime
    consumption_kwh: float
    cost_estimate_inr: float
    is_peak_hour: bool
    source: ReadingSource


# --- Device Schedule ---

class DeviceScheduleCreate(BaseModel):
    schedule_type: ScheduleType = ScheduleType.MANUAL
    start_time: time
    end_time: time
    days_of_week: list[str]

    @field_validator("days_of_week")
    @classmethod
    def validate_days(cls, v: list[str]) -> list[str]:
        valid = {"MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"}
        for day in v:
            if day.upper() not in valid:
                raise ValueError(f"Invalid day: {day}. Use MON, TUE, WED, THU, FRI, SAT, SUN")
        return [d.upper() for d in v]


class DeviceScheduleResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    device_id: uuid.UUID
    schedule_type: ScheduleType
    start_time: time
    end_time: time
    days_of_week: list
    is_active: bool
    created_by_ai: bool
    created_at: datetime
