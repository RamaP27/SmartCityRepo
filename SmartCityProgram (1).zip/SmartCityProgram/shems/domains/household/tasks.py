"""
Household domain Celery tasks (Phase 3).

  - poll_ecosystem_devices   every 5 min  — sync device states from IoT adapters
  - execute_device_schedules every 1 min  — fire scheduled on/off commands
"""
import asyncio
import logging

from shems.celery_app import celery_app
from shems.database import AsyncSessionLocal

logger = logging.getLogger(__name__)


# ── Poll ecosystem device states ──────────────────────────────────────────────

@celery_app.task(name="shems.domains.household.tasks.poll_ecosystem_devices", bind=True, max_retries=2)
def poll_ecosystem_devices(self):
    """Pull latest device states from all ecosystem adapters and update EnergyReadings."""
    asyncio.run(_poll_devices_inner())


async def _poll_devices_inner():
    from shems.domains.household.models import Device, EnergyReading, Household, ReadingSource
    from shems.domains.household.integrations.adapter_factory import AdapterFactory
    from sqlalchemy import select
    from datetime import datetime, timezone
    import json

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(
                Household.id,
                Household.ecosystem_type,
                Household.ecosystem_credentials,
            ).where(Household.ecosystem_type != "MANUAL")
        )
        households = result.fetchall()

        total_readings = 0
        for h in households:
            try:
                adapter = AdapterFactory.create(h.ecosystem_type)
                creds = json.loads(h.ecosystem_credentials) if h.ecosystem_credentials else {}
                if not await adapter.authenticate(creds):
                    continue

                device_states = await adapter.discover_devices(h.id)
                for state in device_states:
                    if state.power_watts is None:
                        continue
                    kwh_15min = (state.power_watts / 1000) * 0.25  # 15-min interval
                    db.add(EnergyReading(
                        household_id=h.id,
                        timestamp=datetime.now(timezone.utc),
                        consumption_kwh=kwh_15min,
                        cost_estimate_inr=0.0,
                        is_peak_hour=False,
                        source=ReadingSource.DEVICE_API,
                    ))
                    total_readings += 1

            except Exception as exc:
                logger.error("poll_ecosystem_devices: household=%s error: %s", h.id, exc)

        if total_readings:
            await db.commit()

    logger.info("poll_ecosystem_devices: %d readings written", total_readings)


# ── Execute device schedules ──────────────────────────────────────────────────

@celery_app.task(name="shems.domains.household.tasks.execute_device_schedules", bind=True, max_retries=2)
def execute_device_schedules(self):
    """Check active device schedules and fire on/off commands at the right time."""
    asyncio.run(_execute_schedules_inner())


async def _execute_schedules_inner():
    from shems.domains.household.models import Device, DeviceSchedule, Household, ScheduleType
    from shems.domains.household.integrations.adapter_factory import AdapterFactory
    from shems.core.events.event_bus import publish
    from shems.core.events.event_types import DeviceScheduleExecutedEvent
    from sqlalchemy import and_, select
    from datetime import datetime, timezone, time
    import json

    now = datetime.now(timezone.utc)
    current_time = now.time().replace(second=0, microsecond=0)
    # Map weekday int to 3-letter name
    day_map = {0: "MON", 1: "TUE", 2: "WED", 3: "THU", 4: "FRI", 5: "SAT", 6: "SUN"}
    today_name = day_map[now.weekday()]

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(DeviceSchedule, Device, Household)
            .join(Device, DeviceSchedule.device_id == Device.id)
            .join(Household, Device.household_id == Household.id)
            .where(
                and_(
                    DeviceSchedule.is_active == True,  # noqa: E712
                )
            )
        )
        rows = result.fetchall()

        executed = 0
        for schedule, device, household in rows:
            days = schedule.days_of_week if isinstance(schedule.days_of_week, list) else []
            if today_name not in days and "ALL" not in days:
                continue

            # Check if it's time to turn on or off
            sched_start = schedule.start_time.replace(second=0, microsecond=0)
            sched_end = schedule.end_time.replace(second=0, microsecond=0)

            action = None
            if abs((sched_start.hour * 60 + sched_start.minute) - (current_time.hour * 60 + current_time.minute)) <= 1:
                action = "on"
            elif abs((sched_end.hour * 60 + sched_end.minute) - (current_time.hour * 60 + current_time.minute)) <= 1:
                action = "off"

            if not action:
                continue

            try:
                adapter = AdapterFactory.create(household.ecosystem_type)
                creds = json.loads(household.ecosystem_credentials) if household.ecosystem_credentials else {}
                if await adapter.authenticate(creds):
                    success = await adapter.send_command(
                        __import__(
                            "shems.domains.household.integrations.base_adapter",
                            fromlist=["DeviceCommand"],
                        ).DeviceCommand(
                            external_device_id=device.external_device_id,
                            action=action,
                        )
                    )
                    if success:
                        await publish(DeviceScheduleExecutedEvent(
                            household_id=household.id,
                            device_id=device.id,
                            device_name=device.name,
                            action=action,
                            scheduled_reason=schedule.schedule_type.value,
                        ))
                        executed += 1
            except Exception as exc:
                logger.error(
                    "execute_device_schedules: device=%s action=%s error: %s",
                    device.id, action, exc,
                )

    logger.info("execute_device_schedules: %d commands fired", executed)
