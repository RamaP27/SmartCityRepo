import hashlib
import uuid
from datetime import datetime, timezone

from shems.domains.household.manager import HouseholdManager
from shems.domains.household.models import Household
from shems.domains.household.schemas import (
    DeviceCreate,
    DeviceResponse,
    DeviceScheduleCreate,
    DeviceScheduleResponse,
    DeviceUpdate,
    EnergyReadingResponse,
    HouseholdCreate,
    HouseholdResponse,
    HouseholdUpdate,
)
from shems.exceptions import AlreadyExistsException, ForbiddenException, NotFoundException


class HouseholdService:
    def __init__(self, manager: HouseholdManager):
        self.manager = manager

    # --- Household ---

    async def get_or_404(self, user_id: uuid.UUID) -> Household:
        household = await self.manager.get_by_user_id(user_id)
        if not household:
            raise NotFoundException("Household")
        return household

    async def create_household(
        self, user_id: uuid.UUID, request: HouseholdCreate
    ) -> HouseholdResponse:
        existing = await self.manager.get_by_user_id(user_id)
        if existing:
            raise AlreadyExistsException("Household")

        address_hash = self._hash_address(request.address_hash)
        household = await self.manager.create(
            user_id=user_id,
            address_hash=address_hash,
            smart_meter_id=request.smart_meter_id,
            ecosystem_type=request.ecosystem_type,
            square_footage=request.square_footage,
            occupant_count=request.occupant_count,
        )
        return HouseholdResponse.model_validate(household)

    async def get_household(self, user_id: uuid.UUID) -> HouseholdResponse:
        household = await self.get_or_404(user_id)
        return HouseholdResponse.model_validate(household)

    async def update_household(
        self, user_id: uuid.UUID, request: HouseholdUpdate
    ) -> HouseholdResponse:
        household = await self.get_or_404(user_id)
        updated = await self.manager.update(household, **request.model_dump(exclude_none=True))
        return HouseholdResponse.model_validate(updated)

    # --- Devices ---

    async def list_devices(self, user_id: uuid.UUID) -> list[DeviceResponse]:
        household = await self.get_or_404(user_id)
        devices = await self.manager.list_devices(household.id)
        return [DeviceResponse.model_validate(d) for d in devices]

    async def add_device(self, user_id: uuid.UUID, request: DeviceCreate) -> DeviceResponse:
        household = await self.get_or_404(user_id)
        device = await self.manager.create_device(
            household_id=household.id, **request.model_dump()
        )
        return DeviceResponse.model_validate(device)

    async def update_device(
        self, user_id: uuid.UUID, device_id: uuid.UUID, request: DeviceUpdate
    ) -> DeviceResponse:
        household = await self.get_or_404(user_id)
        device = await self.manager.get_device(device_id, household.id)
        if not device:
            raise NotFoundException("Device", str(device_id))
        updated = await self.manager.update_device(device, **request.model_dump(exclude_none=True))
        return DeviceResponse.model_validate(updated)

    async def remove_device(self, user_id: uuid.UUID, device_id: uuid.UUID) -> None:
        household = await self.get_or_404(user_id)
        device = await self.manager.get_device(device_id, household.id)
        if not device:
            raise NotFoundException("Device", str(device_id))
        await self.manager.delete_device(device)

    # --- Readings ---

    async def get_readings(
        self,
        user_id: uuid.UUID,
        from_dt: datetime,
        to_dt: datetime,
        device_id: uuid.UUID | None = None,
    ) -> list[EnergyReadingResponse]:
        household = await self.get_or_404(user_id)
        readings = await self.manager.get_readings(household.id, from_dt, to_dt, device_id)
        return [EnergyReadingResponse.model_validate(r) for r in readings]

    # --- Schedules ---

    async def list_schedules(self, user_id: uuid.UUID) -> list[DeviceScheduleResponse]:
        household = await self.get_or_404(user_id)
        schedules = await self.manager.list_schedules(household.id)
        return [DeviceScheduleResponse.model_validate(s) for s in schedules]

    async def create_schedule(
        self, user_id: uuid.UUID, device_id: uuid.UUID, request: DeviceScheduleCreate
    ) -> DeviceScheduleResponse:
        household = await self.get_or_404(user_id)
        device = await self.manager.get_device(device_id, household.id)
        if not device:
            raise NotFoundException("Device", str(device_id))
        if not device.is_schedulable:
            raise ForbiddenException("Device is not schedulable")
        schedule = await self.manager.create_schedule(device_id=device_id, **request.model_dump())
        return DeviceScheduleResponse.model_validate(schedule)

    async def delete_schedule(self, user_id: uuid.UUID, schedule_id: uuid.UUID) -> None:
        household = await self.get_or_404(user_id)
        schedule = await self.manager.get_schedule(schedule_id, household.id)
        if not schedule:
            raise NotFoundException("Schedule", str(schedule_id))
        await self.manager.deactivate_schedule(schedule)

    @staticmethod
    def _hash_address(address: str) -> str:
        return hashlib.sha256(address.encode()).hexdigest()
