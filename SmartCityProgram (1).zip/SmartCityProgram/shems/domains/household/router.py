import uuid
from datetime import datetime, timezone, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from shems.dependencies import get_current_user, get_db
from shems.domains.auth.models import User
from shems.domains.household.manager import HouseholdManager
from shems.domains.household.schemas import (
    DeviceCreate,
    DeviceResponse,
    DeviceScheduleCreate,
    DeviceScheduleResponse,
    DeviceUpdate,
    EnergyReadingResponse,
    HouseholdCreate,
    HouseholdResponse,
    HouseholdUpdate,
)
from shems.domains.household.service import HouseholdService

router = APIRouter()


def get_household_service(db: AsyncSession = Depends(get_db)) -> HouseholdService:
    return HouseholdService(HouseholdManager(db))


@router.post("/me", response_model=HouseholdResponse, status_code=201)
async def create_household(
    request: HouseholdCreate,
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    return await service.create_household(current_user.id, request)


@router.get("/me", response_model=HouseholdResponse)
async def get_household(
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    return await service.get_household(current_user.id)


@router.put("/me", response_model=HouseholdResponse)
async def update_household(
    request: HouseholdUpdate,
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    return await service.update_household(current_user.id, request)


# --- Devices ---

@router.get("/me/devices", response_model=list[DeviceResponse])
async def list_devices(
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    return await service.list_devices(current_user.id)


@router.post("/me/devices", response_model=DeviceResponse, status_code=201)
async def add_device(
    request: DeviceCreate,
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    return await service.add_device(current_user.id, request)


@router.put("/me/devices/{device_id}", response_model=DeviceResponse)
async def update_device(
    device_id: uuid.UUID,
    request: DeviceUpdate,
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    return await service.update_device(current_user.id, device_id, request)


@router.delete("/me/devices/{device_id}", status_code=204)
async def remove_device(
    device_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    await service.remove_device(current_user.id, device_id)


# --- Energy Readings ---

@router.get("/me/readings", response_model=list[EnergyReadingResponse])
async def get_readings(
    from_dt: Annotated[datetime | None, Query(alias="from")] = None,
    to_dt: Annotated[datetime | None, Query(alias="to")] = None,
    device_id: uuid.UUID | None = None,
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    now = datetime.now(timezone.utc)
    from_dt = from_dt or (now - timedelta(days=7))
    to_dt = to_dt or now
    return await service.get_readings(current_user.id, from_dt, to_dt, device_id)


@router.get("/me/devices/{device_id}/readings", response_model=list[EnergyReadingResponse])
async def get_device_readings(
    device_id: uuid.UUID,
    from_dt: Annotated[datetime | None, Query(alias="from")] = None,
    to_dt: Annotated[datetime | None, Query(alias="to")] = None,
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    now = datetime.now(timezone.utc)
    from_dt = from_dt or (now - timedelta(days=7))
    to_dt = to_dt or now
    return await service.get_readings(current_user.id, from_dt, to_dt, device_id)


# --- Schedules ---

@router.get("/me/schedules", response_model=list[DeviceScheduleResponse])
async def list_schedules(
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    return await service.list_schedules(current_user.id)


@router.post("/me/devices/{device_id}/schedules", response_model=DeviceScheduleResponse, status_code=201)
async def create_schedule(
    device_id: uuid.UUID,
    request: DeviceScheduleCreate,
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    return await service.create_schedule(current_user.id, device_id, request)


@router.delete("/me/schedules/{schedule_id}", status_code=204)
async def delete_schedule(
    schedule_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    service: HouseholdService = Depends(get_household_service),
):
    await service.delete_schedule(current_user.id, schedule_id)


# ── Phase 3: IoT sync + AI scheduling ────────────────────────────────────────

@router.post("/me/sync", status_code=202)
async def sync_ecosystem_devices(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Trigger immediate IoT ecosystem sync for the authenticated household."""
    from shems.domains.household.tasks import poll_ecosystem_devices
    poll_ecosystem_devices.delay()
    return {"message": "Ecosystem sync queued"}


@router.get("/me/schedules/ai-suggest")
async def ai_suggest_schedules(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Return AI-generated off-peak schedule suggestions for all schedulable devices.
    Suggestions are NOT persisted — the user accepts them via POST /me/devices/{id}/schedules.
    """
    from shems.domains.household.ai_scheduler import SuggestedSchedule, generate_suggestions
    from shems.domains.household.manager import HouseholdManager
    from sqlalchemy import select
    from shems.domains.household.models import Household

    result = await db.execute(
        select(Household.id).where(Household.user_id == current_user.id)
    )
    household_id = result.scalar_one_or_none()
    if not household_id:
        return {"suggestions": []}

    suggestions = await generate_suggestions(household_id, db)
    return {
        "suggestions": [
            {
                "device_id": str(s.device_id),
                "device_name": s.device_name,
                "device_type": s.device_type,
                "suggested_start": s.suggested_start.strftime("%H:%M"),
                "suggested_end": s.suggested_end.strftime("%H:%M"),
                "days_of_week": s.days_of_week,
                "reason": s.reason,
                "estimated_savings_pct": s.estimated_savings_pct,
            }
            for s in suggestions
        ]
    }
