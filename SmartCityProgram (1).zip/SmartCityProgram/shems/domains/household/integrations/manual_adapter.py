"""
Manual adapter — for households without a smart home ecosystem.

No real device control. Authenticate always succeeds.
Discover returns an empty list. Commands are no-ops that log intent.
This allows Marcus-persona users (software-only, no hardware) to exist
in the system without error paths.
"""
from __future__ import annotations

import logging
import uuid

from shems.domains.household.integrations.base_adapter import (
    BaseEcosystemAdapter,
    DeviceCommand,
    DeviceState,
)

logger = logging.getLogger(__name__)


class ManualAdapter(BaseEcosystemAdapter):
    ecosystem_name = "MANUAL"

    async def authenticate(self, credentials: dict[str, str]) -> bool:
        return True

    async def discover_devices(self, household_id: uuid.UUID) -> list[DeviceState]:
        return []

    async def get_device_state(self, external_device_id: str) -> DeviceState | None:
        return None

    async def send_command(self, command: DeviceCommand) -> bool:
        logger.info(
            "ManualAdapter: command=%s device=%s (no-op, manual ecosystem)",
            command.action, command.external_device_id,
        )
        return True
