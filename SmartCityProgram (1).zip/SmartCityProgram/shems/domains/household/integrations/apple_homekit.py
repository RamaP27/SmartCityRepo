"""
Apple HomeKit adapter.

HomeKit Accessory Protocol (HAP) does not have a cloud REST API.
Integration uses the HomeKit Controller HTTP bridge pattern:
  - homebridge (Node.js) or hap-python expose a local REST API
  - SHEMS communicates with the homebridge instance over LAN/VPN

Bridge base URL configured via household ecosystem_credentials:
  {"bridge_url": "http://192.168.1.100:8581", "api_key": "..."}

Characteristics mapped:
  - On/Off:        HAP characteristic 25 (On)
  - CurrentPower:  HAP characteristic E3 (watts, Eve Energy extension)

Ref: https://github.com/homebridge/homebridge
     https://github.com/ebaauw/homebridge-hue
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx

from shems.domains.household.integrations.base_adapter import (
    BaseEcosystemAdapter,
    DeviceCommand,
    DeviceState,
)

logger = logging.getLogger(__name__)

# HAP characteristic UUIDs (short form)
_CHAR_ON = "25"
_CHAR_CURRENT_POWER = "E3"   # Eve Energy extension


class AppleHomeKitAdapter(BaseEcosystemAdapter):
    ecosystem_name = "APPLE_HOMEKIT"

    def __init__(self):
        self._bridge_url: str | None = None
        self._api_key: str | None = None

    async def authenticate(self, credentials: dict[str, str]) -> bool:
        self._bridge_url = credentials.get("bridge_url", "").rstrip("/")
        self._api_key = credentials.get("api_key", "")
        if not self._bridge_url:
            logger.warning("AppleHomeKitAdapter: bridge_url not provided")
            return False
        # Test connectivity with a simple ping
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(
                    f"{self._bridge_url}/api",
                    headers=self._auth_headers(),
                )
            return resp.is_success
        except httpx.RequestError as exc:
            logger.error("AppleHomeKitAdapter: bridge unreachable: %s", exc)
            return False

    async def discover_devices(self, household_id: uuid.UUID) -> list[DeviceState]:
        """List all accessories from the homebridge bridge."""
        data = await self._get("/api/accessories")
        if not data:
            return []

        devices = []
        for acc in data:
            state = self._parse_accessory(acc)
            if state:
                devices.append(state)

        logger.info(
            "AppleHomeKitAdapter: discovered %d accessories for household=%s",
            len(devices), household_id,
        )
        return devices

    async def get_device_state(self, external_device_id: str) -> DeviceState | None:
        data = await self._get(f"/api/accessories/{external_device_id}")
        return self._parse_accessory(data) if data else None

    async def send_command(self, command: DeviceCommand) -> bool:
        """
        Write a HAP characteristic value.
        action="on"  → sets characteristic 25 to True
        action="off" → sets characteristic 25 to False
        """
        char_map = {
            "on":  {"characteristicType": _CHAR_ON, "value": True},
            "off": {"characteristicType": _CHAR_ON, "value": False},
        }
        payload = char_map.get(command.action)
        if not payload:
            payload = {
                "characteristicType": command.params.get("characteristic", _CHAR_ON),
                "value": command.params.get("value"),
            }

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.put(
                    f"{self._bridge_url}/api/accessories/{command.external_device_id}",
                    json=payload,
                    headers=self._auth_headers(),
                )
            if resp.is_success:
                logger.info(
                    "AppleHomeKitAdapter: command=%s sent to device=%s",
                    command.action, command.external_device_id,
                )
                return True
            logger.error(
                "AppleHomeKitAdapter: command failed %d: %s",
                resp.status_code, resp.text[:200],
            )
            return False
        except httpx.RequestError as exc:
            logger.error("AppleHomeKitAdapter: request error: %s", exc)
            return False

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._api_key}"}

    async def _get(self, path: str) -> Any:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    f"{self._bridge_url}{path}",
                    headers=self._auth_headers(),
                )
            if resp.is_success:
                return resp.json()
        except httpx.RequestError as exc:
            logger.error("AppleHomeKitAdapter: GET %s failed: %s", path, exc)
        return None

    @staticmethod
    def _parse_accessory(acc: dict[str, Any]) -> DeviceState | None:
        if not acc:
            return None

        # Find On characteristic
        is_on = False
        power_watts = None
        for svc in acc.get("serviceCharacteristics", []):
            if svc.get("type") == _CHAR_ON:
                is_on = bool(svc.get("value", False))
            elif svc.get("type") == _CHAR_CURRENT_POWER:
                try:
                    power_watts = float(svc.get("value", 0))
                except (TypeError, ValueError):
                    pass

        return DeviceState(
            external_device_id=str(acc.get("uniqueId", acc.get("aid", ""))),
            name=acc.get("serviceName", acc.get("humanType", "Unknown")),
            is_on=is_on,
            power_watts=power_watts,
            last_seen=datetime.now(timezone.utc),
            raw=acc,
        )
