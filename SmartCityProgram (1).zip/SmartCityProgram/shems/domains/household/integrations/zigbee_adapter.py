"""
Zigbee2MQTT adapter.

Communicates with a zigbee2mqtt bridge over MQTT (paho-mqtt async wrapper).

MQTT topics:
  - Subscribe: zigbee2mqtt/<device_friendly_name>   → device state updates
  - Publish:   zigbee2mqtt/<device_friendly_name>/set → commands (JSON)
  - Subscribe: zigbee2mqtt/bridge/devices            → device list

Credentials format (household.ecosystem_credentials):
  {
    "broker_host": "192.168.1.50",
    "broker_port": 1883,
    "username": "mqtt_user",
    "password": "mqtt_pass"
  }

Since paho-mqtt is synchronous, we wrap blocking calls in a thread executor
for use within async contexts.
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any

import paho.mqtt.client as mqtt

from shems.domains.household.integrations.base_adapter import (
    BaseEcosystemAdapter,
    DeviceCommand,
    DeviceState,
)

logger = logging.getLogger(__name__)

_EXECUTOR = ThreadPoolExecutor(max_workers=4, thread_name_prefix="zigbee")
_BRIDGE_DEVICES_TOPIC = "zigbee2mqtt/bridge/devices"
_CONNECT_TIMEOUT = 5   # seconds


class ZigbeeAdapter(BaseEcosystemAdapter):
    ecosystem_name = "ZIGBEE"

    def __init__(self):
        self._broker_host: str = "localhost"
        self._broker_port: int = 1883
        self._username: str | None = None
        self._password: str | None = None
        self._client: mqtt.Client | None = None
        self._devices_cache: list[dict[str, Any]] = []
        self._state_cache: dict[str, dict] = {}

    async def authenticate(self, credentials: dict[str, str]) -> bool:
        self._broker_host = credentials.get("broker_host", "localhost")
        self._broker_port = int(credentials.get("broker_port", 1883))
        self._username = credentials.get("username")
        self._password = credentials.get("password")

        connected = await asyncio.get_event_loop().run_in_executor(
            _EXECUTOR, self._connect_sync
        )
        return connected

    async def discover_devices(self, household_id: uuid.UUID) -> list[DeviceState]:
        if not self._client or not self._client.is_connected():
            logger.warning("ZigbeeAdapter: not connected, cannot discover devices")
            return []

        # Request device list via retained bridge/devices message
        discovered: list[dict] = []
        ready = asyncio.Event()

        def on_bridge_devices(client, userdata, msg):
            try:
                discovered.extend(json.loads(msg.payload))
            except Exception:
                pass
            ready.set()

        self._client.subscribe(_BRIDGE_DEVICES_TOPIC)
        self._client.message_callback_add(_BRIDGE_DEVICES_TOPIC, on_bridge_devices)

        try:
            await asyncio.wait_for(ready.wait(), timeout=5.0)
        except asyncio.TimeoutError:
            logger.warning("ZigbeeAdapter: device discovery timed out")

        devices = [self._parse_device(d) for d in discovered if d.get("type") != "Coordinator"]
        logger.info(
            "ZigbeeAdapter: discovered %d devices for household=%s",
            len(devices), household_id,
        )
        return [d for d in devices if d is not None]

    async def get_device_state(self, external_device_id: str) -> DeviceState | None:
        """
        Fetch current state by publishing a get request to zigbee2mqtt/<name>/get
        and waiting for the response on zigbee2mqtt/<name>.
        """
        if not self._client or not self._client.is_connected():
            return None

        received: dict = {}
        ready = asyncio.Event()
        topic = f"zigbee2mqtt/{external_device_id}"

        def on_state(client, userdata, msg):
            try:
                received.update(json.loads(msg.payload))
            except Exception:
                pass
            ready.set()

        self._client.subscribe(topic)
        self._client.message_callback_add(topic, on_state)
        self._client.publish(f"{topic}/get", json.dumps({"state": ""}))

        try:
            await asyncio.wait_for(ready.wait(), timeout=3.0)
        except asyncio.TimeoutError:
            pass

        if received:
            return DeviceState(
                external_device_id=external_device_id,
                name=external_device_id,
                is_on=received.get("state", "OFF").upper() == "ON",
                power_watts=received.get("power"),
                last_seen=datetime.now(timezone.utc),
                raw=received,
            )
        return None

    async def send_command(self, command: DeviceCommand) -> bool:
        if not self._client or not self._client.is_connected():
            logger.error("ZigbeeAdapter: not connected")
            return False

        topic = f"zigbee2mqtt/{command.external_device_id}/set"
        if command.action in ("on", "off"):
            payload = json.dumps({"state": command.action.upper()})
        elif command.action == "set_brightness":
            payload = json.dumps({
                "state": "ON",
                "brightness": command.params.get("brightness", 255),
            })
        elif command.action == "set_color_temp":
            payload = json.dumps({
                "color_temp": command.params.get("color_temp", 370),
            })
        else:
            payload = json.dumps(command.params)

        info = self._client.publish(topic, payload)
        success = info.rc == mqtt.MQTT_ERR_SUCCESS
        if success:
            logger.info(
                "ZigbeeAdapter: command=%s published to %s", command.action, topic
            )
        else:
            logger.error("ZigbeeAdapter: publish failed rc=%d", info.rc)
        return success

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _connect_sync(self) -> bool:
        """Blocking connect — run in thread executor."""
        client = mqtt.Client(client_id=f"shems-{uuid.uuid4().hex[:8]}")
        if self._username:
            client.username_pw_set(self._username, self._password)

        connected_flag = [False]

        def on_connect(c, userdata, flags, rc):
            connected_flag[0] = rc == 0

        client.on_connect = on_connect

        try:
            client.connect(self._broker_host, self._broker_port, keepalive=60)
            client.loop_start()
            import time
            deadline = time.time() + _CONNECT_TIMEOUT
            while time.time() < deadline:
                if connected_flag[0]:
                    break
                time.sleep(0.1)
        except Exception as exc:
            logger.error("ZigbeeAdapter: connection error: %s", exc)
            return False

        if connected_flag[0]:
            self._client = client
            logger.info(
                "ZigbeeAdapter: connected to %s:%d", self._broker_host, self._broker_port
            )
        return connected_flag[0]

    @staticmethod
    def _parse_device(raw: dict[str, Any]) -> DeviceState | None:
        if not raw:
            return None
        return DeviceState(
            external_device_id=raw.get("friendly_name", raw.get("ieee_address", "")),
            name=raw.get("friendly_name", "Unknown Zigbee Device"),
            is_on=False,  # State fetched separately via get_device_state()
            power_watts=None,
            last_seen=datetime.now(timezone.utc),
            raw=raw,
        )
