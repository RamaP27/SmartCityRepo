"""
Google Home adapter.

Uses the Smart Device Management (SDM) API via OAuth 2.0 + httpx.

OAuth flow:
  1. User redirected to Google consent screen (handled by frontend).
  2. Frontend exchanges auth code → access/refresh tokens via POST /oauth2/token.
  3. Tokens stored per-household in the Household.ecosystem_token (encrypted at rest).
  4. This adapter uses the stored access token; refreshes automatically on 401.

Scopes required: https://www.googleapis.com/auth/sdm.service

Ref: https://developers.google.com/nest/device-access/api
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx

from shems.domains.household.integrations.base_adapter import (
    BaseEcosystemAdapter,
    DeviceCommand,
    DeviceState,
)

logger = logging.getLogger(__name__)

_SDM_BASE = "https://smartdevicemanagement.googleapis.com/v1"
_TOKEN_URL = "https://oauth2.googleapis.com/token"

# Device type mapping: SDM trait → SHEMS DeviceType
_TRAIT_MAP = {
    "sdm.devices.types.THERMOSTAT": "HVAC",
    "sdm.devices.types.DISPLAY": "OTHER",
    "sdm.devices.types.CAMERA": "OTHER",
    "sdm.devices.types.DOORBELL": "OTHER",
    "sdm.devices.types.SWITCH": "OTHER",
}


class GoogleHomeAdapter(BaseEcosystemAdapter):
    ecosystem_name = "GOOGLE_HOME"

    def __init__(self, client_id: str, client_secret: str, project_id: str):
        self._client_id = client_id
        self._client_secret = client_secret
        self._project_id = project_id
        self._access_token: str | None = None
        self._refresh_token: str | None = None

    async def authenticate(self, credentials: dict[str, str]) -> bool:
        """
        Exchange refresh_token for a fresh access token.
        credentials = {"refresh_token": "...", "access_token": "..."}
        """
        self._refresh_token = credentials.get("refresh_token")
        self._access_token = credentials.get("access_token")

        if not self._refresh_token:
            logger.warning("GoogleHomeAdapter: no refresh_token provided")
            return False

        refreshed = await self._refresh_access_token()
        return refreshed

    async def discover_devices(self, household_id: uuid.UUID) -> list[DeviceState]:
        """List all devices in the user's SDM project."""
        url = f"{_SDM_BASE}/enterprises/{self._project_id}/devices"
        data = await self._get(url)
        if not data:
            return []

        devices = []
        for raw in data.get("devices", []):
            state = self._parse_device(raw)
            if state:
                devices.append(state)

        logger.info(
            "GoogleHomeAdapter: discovered %d devices for household=%s",
            len(devices), household_id,
        )
        return devices

    async def get_device_state(self, external_device_id: str) -> DeviceState | None:
        url = f"{_SDM_BASE}/{external_device_id}"
        data = await self._get(url)
        return self._parse_device(data) if data else None

    async def send_command(self, command: DeviceCommand) -> bool:
        """
        Execute an SDM command (e.g. thermostat setpoint, switch toggle).
        Supported actions: "on", "off", "set_temperature"
        """
        url = f"{_SDM_BASE}/{command.external_device_id}:executeCommand"
        payload = self._build_sdm_command(command)
        if payload is None:
            logger.warning("GoogleHomeAdapter: unsupported action %s", command.action)
            return False

        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                url,
                json=payload,
                headers=self._auth_headers(),
            )
            if resp.status_code == 401:
                await self._refresh_access_token()
                resp = await client.post(url, json=payload, headers=self._auth_headers())

            if resp.is_success:
                logger.info(
                    "GoogleHomeAdapter: command=%s sent to device=%s",
                    command.action, command.external_device_id,
                )
                return True

            logger.error(
                "GoogleHomeAdapter: command failed status=%d body=%s",
                resp.status_code, resp.text[:200],
            )
            return False

    # ── Internal helpers ──────────────────────────────────────────────────────

    async def _refresh_access_token(self) -> bool:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                _TOKEN_URL,
                data={
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                    "refresh_token": self._refresh_token,
                    "grant_type": "refresh_token",
                },
            )
        if resp.is_success:
            self._access_token = resp.json().get("access_token")
            return True
        logger.error("GoogleHomeAdapter: token refresh failed: %s", resp.text[:200])
        return False

    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._access_token}"}

    async def _get(self, url: str) -> dict[str, Any] | None:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(url, headers=self._auth_headers())
            if resp.status_code == 401:
                await self._refresh_access_token()
                resp = await client.get(url, headers=self._auth_headers())
            if resp.is_success:
                return resp.json()
        logger.warning("GoogleHomeAdapter: GET %s failed: %d", url, resp.status_code)
        return None

    @staticmethod
    def _parse_device(raw: dict[str, Any]) -> DeviceState | None:
        if not raw:
            return None
        traits = raw.get("traits", {})
        connectivity = traits.get("sdm.devices.traits.Connectivity", {})
        is_on = connectivity.get("status", "OFFLINE") == "ONLINE"
        fan = traits.get("sdm.devices.traits.Fan", {})
        power_watts = None  # SDM doesn't expose wattage directly

        return DeviceState(
            external_device_id=raw.get("name", ""),
            name=raw.get("displayName", raw.get("name", "Unknown")),
            is_on=is_on,
            power_watts=power_watts,
            last_seen=datetime.now(timezone.utc),
            raw=raw,
        )

    @staticmethod
    def _build_sdm_command(cmd: DeviceCommand) -> dict[str, Any] | None:
        if cmd.action == "set_temperature":
            return {
                "command": "sdm.devices.commands.ThermostatTemperatureSetpoint.SetHeat",
                "params": {"heatCelsius": cmd.params.get("temperature_c", 22.0)},
            }
        # Generic switch trait (custom integrations)
        if cmd.action in ("on", "off"):
            return {
                "command": "sdm.devices.commands.Switch.Set",
                "params": {"on": cmd.action == "on"},
            }
        return None
