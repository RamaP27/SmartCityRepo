"""
Adapter factory — returns the correct BaseEcosystemAdapter for a given ecosystem type.

Usage:
    adapter = AdapterFactory.create("GOOGLE_HOME")
    await adapter.authenticate(credentials)
    devices = await adapter.discover_devices(household_id)
"""
from __future__ import annotations

import logging

from shems.config import settings
from shems.domains.household.integrations.base_adapter import BaseEcosystemAdapter

logger = logging.getLogger(__name__)


class AdapterFactory:
    @staticmethod
    def create(ecosystem_type: str) -> BaseEcosystemAdapter:
        """
        Factory method. Returns an uninitialised adapter.
        Caller must call authenticate() before use.
        """
        ecosystem = ecosystem_type.upper()

        if ecosystem == "GOOGLE_HOME":
            from shems.domains.household.integrations.google_home import GoogleHomeAdapter
            return GoogleHomeAdapter(
                client_id=settings.google_home_client_id,
                client_secret=settings.google_home_client_secret,
                project_id=settings.google_home_project_id,
            )

        if ecosystem == "APPLE_HOMEKIT":
            from shems.domains.household.integrations.apple_homekit import AppleHomeKitAdapter
            return AppleHomeKitAdapter()

        if ecosystem == "ZIGBEE":
            from shems.domains.household.integrations.zigbee_adapter import ZigbeeAdapter
            return ZigbeeAdapter()

        if ecosystem == "MANUAL":
            from shems.domains.household.integrations.manual_adapter import ManualAdapter
            return ManualAdapter()

        raise ValueError(f"Unsupported ecosystem type: {ecosystem_type!r}")
