"""
Base IoT ecosystem adapter — Strategy pattern.

Each concrete adapter (GoogleHome, AppleHomeKit, Zigbee) must implement this interface.
The adapter is responsible for:
  1. OAuth / MQTT authentication
  2. Device discovery & listing
  3. Reading current device state / power consumption
  4. Sending on/off/schedule commands

All methods are async so they can be called from FastAPI routes or Celery tasks.
"""
from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class DeviceState:
    """Normalised device state returned by any adapter."""
    external_device_id: str
    name: str
    is_on: bool
    power_watts: float | None         # None if device doesn't report wattage
    last_seen: datetime
    raw: dict[str, Any] = field(default_factory=dict)  # provider-specific payload


@dataclass
class DeviceCommand:
    """Command to send to a device via its ecosystem."""
    external_device_id: str
    action: str                       # "on" | "off" | "set_schedule"
    params: dict[str, Any] = field(default_factory=dict)


class BaseEcosystemAdapter(ABC):
    """
    Abstract base class for all IoT ecosystem adapters.

    Subclasses must implement:
      - authenticate()
      - discover_devices()
      - get_device_state()
      - send_command()
    """

    ecosystem_name: str = "unknown"

    @abstractmethod
    async def authenticate(self, credentials: dict[str, str]) -> bool:
        """
        Perform OAuth / MQTT auth.
        Returns True if successful.
        Stores tokens internally for subsequent calls.
        """

    @abstractmethod
    async def discover_devices(self, household_id: uuid.UUID) -> list[DeviceState]:
        """
        Return all controllable devices linked to this household's account.
        """

    @abstractmethod
    async def get_device_state(self, external_device_id: str) -> DeviceState | None:
        """
        Fetch current state for a single device. Returns None if unreachable.
        """

    @abstractmethod
    async def send_command(self, command: DeviceCommand) -> bool:
        """
        Send a command to a device. Returns True on success.
        """

    async def turn_on(self, external_device_id: str) -> bool:
        return await self.send_command(
            DeviceCommand(external_device_id=external_device_id, action="on")
        )

    async def turn_off(self, external_device_id: str) -> bool:
        return await self.send_command(
            DeviceCommand(external_device_id=external_device_id, action="off")
        )
