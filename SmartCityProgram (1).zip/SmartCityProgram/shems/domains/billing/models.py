import enum
import uuid
from datetime import date, datetime

from sqlalchemy import Boolean, Date, DateTime, Enum as SAEnum, Float, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from shems.database import Base, TimestampMixin


class AlertType(str, enum.Enum):
    WARNING_THRESHOLD = "WARNING_THRESHOLD"
    CAP_REACHED = "CAP_REACHED"
    PEAK_SPIKE = "PEAK_SPIKE"


class NotificationChannel(str, enum.Enum):
    PUSH = "PUSH"
    SMS = "SMS"
    EMAIL = "EMAIL"


class BillingAccount(Base, TimestampMixin):
    __tablename__ = "billing_accounts"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )
    tariff_zone_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tariff_zones.id", ondelete="SET NULL"),
        nullable=True,
    )
    utility_provider: Mapped[str] = mapped_column(String(100), nullable=False)
    meter_reference: Mapped[str | None] = mapped_column(String(100), nullable=True)
    billing_cycle_day: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    currency: Mapped[str] = mapped_column(String(10), nullable=False, default="INR")

    spending_caps: Mapped[list["SpendingCap"]] = relationship(
        back_populates="billing_account", cascade="all, delete-orphan"
    )
    overage_alerts: Mapped[list["OverageAlert"]] = relationship(
        back_populates="billing_account", cascade="all, delete-orphan"
    )
    usage_summaries: Mapped[list["UsageSummary"]] = relationship(
        back_populates="billing_account", cascade="all, delete-orphan"
    )


class SpendingCap(Base, TimestampMixin):
    __tablename__ = "spending_caps"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    billing_account_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("billing_accounts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    monthly_cap_inr: Mapped[float] = mapped_column(Float, nullable=False)
    warning_threshold_pct: Mapped[float] = mapped_column(Float, nullable=False, default=80.0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    billing_account: Mapped["BillingAccount"] = relationship(back_populates="spending_caps")


class OverageAlert(Base, TimestampMixin):
    __tablename__ = "overage_alerts"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    billing_account_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("billing_accounts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    alert_type: Mapped[AlertType] = mapped_column(SAEnum(AlertType), nullable=False)
    triggered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    current_spend_inr: Mapped[float] = mapped_column(Float, nullable=False)
    cap_inr: Mapped[float] = mapped_column(Float, nullable=False)
    notification_sent: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    channel: Mapped[NotificationChannel] = mapped_column(
        SAEnum(NotificationChannel), nullable=False, default=NotificationChannel.PUSH
    )

    billing_account: Mapped["BillingAccount"] = relationship(back_populates="overage_alerts")


class UsageSummary(Base, TimestampMixin):
    """Materialized daily by Celery — never computed on read."""
    __tablename__ = "usage_summaries"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    billing_account_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("billing_accounts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    period_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    total_kwh: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    peak_kwh: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    off_peak_kwh: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    estimated_cost_inr: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    potential_savings_inr: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)

    billing_account: Mapped["BillingAccount"] = relationship(back_populates="usage_summaries")
