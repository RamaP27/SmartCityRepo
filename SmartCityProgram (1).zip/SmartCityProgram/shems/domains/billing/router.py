from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from shems.dependencies import get_current_user, get_db
from shems.domains.auth.models import User
from shems.domains.billing.manager import BillingManager
from shems.domains.billing.schemas import (
    BillingAccountCreate,
    BillingAccountResponse,
    BillingAccountUpdate,
    OverageAlertResponse,
    SavingsTipResponse,
    SpendingCapCreate,
    SpendingCapResponse,
    UsageBreakdownResponse,
)
from shems.domains.billing.service import BillingService

router = APIRouter()


def get_billing_service(db: AsyncSession = Depends(get_db)) -> BillingService:
    return BillingService(BillingManager(db))


# --- Account ---

@router.post("/me/account", response_model=BillingAccountResponse, status_code=201)
async def create_account(
    request: BillingAccountCreate,
    current_user: User = Depends(get_current_user),
    service: BillingService = Depends(get_billing_service),
):
    return await service.create_account(current_user.id, request)


@router.get("/me/account", response_model=BillingAccountResponse)
async def get_account(
    current_user: User = Depends(get_current_user),
    service: BillingService = Depends(get_billing_service),
):
    return await service.get_account(current_user.id)


@router.put("/me/account", response_model=BillingAccountResponse)
async def update_account(
    request: BillingAccountUpdate,
    current_user: User = Depends(get_current_user),
    service: BillingService = Depends(get_billing_service),
):
    return await service.update_account(current_user.id, request)


# --- Spending Cap ---

@router.post("/me/spending-cap", response_model=SpendingCapResponse, status_code=201)
async def set_spending_cap(
    request: SpendingCapCreate,
    current_user: User = Depends(get_current_user),
    service: BillingService = Depends(get_billing_service),
):
    return await service.set_spending_cap(current_user.id, request)


@router.get("/me/spending-cap", response_model=SpendingCapResponse)
async def get_spending_cap(
    current_user: User = Depends(get_current_user),
    service: BillingService = Depends(get_billing_service),
):
    return await service.get_spending_cap(current_user.id)


# --- Alerts ---

@router.get("/me/alerts", response_model=list[OverageAlertResponse])
async def list_alerts(
    current_user: User = Depends(get_current_user),
    service: BillingService = Depends(get_billing_service),
):
    return await service.list_alerts(current_user.id)


@router.get("/me/alerts/active", response_model=list[OverageAlertResponse])
async def list_active_alerts(
    current_user: User = Depends(get_current_user),
    service: BillingService = Depends(get_billing_service),
):
    return await service.list_alerts(current_user.id, active_only=True)


# --- Usage & Cost ---

@router.get("/me/usage/breakdown", response_model=UsageBreakdownResponse)
async def get_usage_breakdown(
    period: str = Query(default="month", pattern="^(today|week|month)$"),
    current_user: User = Depends(get_current_user),
    service: BillingService = Depends(get_billing_service),
):
    return await service.get_usage_breakdown(current_user.id, period)


@router.get("/me/tips", response_model=list[SavingsTipResponse])
async def get_savings_tips(
    current_user: User = Depends(get_current_user),
    service: BillingService = Depends(get_billing_service),
):
    return await service.get_savings_tips(current_user.id)
