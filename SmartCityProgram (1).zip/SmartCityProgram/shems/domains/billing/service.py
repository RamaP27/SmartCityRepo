import uuid
from datetime import date, datetime, timedelta, timezone

from shems.domains.billing.manager import BillingManager
from shems.domains.billing.models import AlertType, BillingAccount
from shems.domains.billing.schemas import (
    BillingAccountCreate,
    BillingAccountResponse,
    BillingAccountUpdate,
    OverageAlertResponse,
    SavingsTipResponse,
    SpendingCapCreate,
    SpendingCapResponse,
    UsageBreakdownResponse,
    UsageSummaryResponse,
)
from shems.exceptions import AlreadyExistsException, NotFoundException


class BillingService:
    def __init__(self, manager: BillingManager):
        self.manager = manager

    # --- Account ---

    async def create_account(
        self, user_id: uuid.UUID, request: BillingAccountCreate
    ) -> BillingAccountResponse:
        existing = await self.manager.get_by_user_id(user_id)
        if existing:
            raise AlreadyExistsException("Billing account")
        account = await self.manager.create_account(user_id=user_id, **request.model_dump())
        return BillingAccountResponse.model_validate(account)

    async def get_account(self, user_id: uuid.UUID) -> BillingAccountResponse:
        account = await self._get_or_404(user_id)
        return BillingAccountResponse.model_validate(account)

    async def update_account(
        self, user_id: uuid.UUID, request: BillingAccountUpdate
    ) -> BillingAccountResponse:
        account = await self._get_or_404(user_id)
        updated = await self.manager.update_account(account, **request.model_dump(exclude_none=True))
        return BillingAccountResponse.model_validate(updated)

    # --- Spending Cap ---

    async def set_spending_cap(
        self, user_id: uuid.UUID, request: SpendingCapCreate
    ) -> SpendingCapResponse:
        account = await self._get_or_404(user_id)
        cap = await self.manager.create_cap(
            billing_account_id=account.id, **request.model_dump()
        )
        return SpendingCapResponse.model_validate(cap)

    async def get_spending_cap(self, user_id: uuid.UUID) -> SpendingCapResponse:
        account = await self._get_or_404(user_id)
        cap = await self.manager.get_active_cap(account.id)
        if not cap:
            raise NotFoundException("Spending cap")
        return SpendingCapResponse.model_validate(cap)

    # --- Alerts ---

    async def list_alerts(
        self, user_id: uuid.UUID, active_only: bool = False
    ) -> list[OverageAlertResponse]:
        account = await self._get_or_404(user_id)
        alerts = await self.manager.list_alerts(account.id, active_only)
        return [OverageAlertResponse.model_validate(a) for a in alerts]

    # --- Usage & Cost ---

    async def get_usage_breakdown(
        self, user_id: uuid.UUID, period: str = "month"
    ) -> UsageBreakdownResponse:
        account = await self._get_or_404(user_id)
        from_date, to_date = self._period_to_dates(period)
        summaries = await self.manager.get_usage_summaries(account.id, from_date, to_date)

        total_kwh = sum(s.total_kwh for s in summaries)
        peak_kwh = sum(s.peak_kwh for s in summaries)
        off_peak_kwh = sum(s.off_peak_kwh for s in summaries)
        total_cost = sum(s.estimated_cost_inr for s in summaries)
        potential_savings = sum(s.potential_savings_inr for s in summaries)

        # Approximate cost split proportionally
        peak_cost = total_cost * (peak_kwh / total_kwh) if total_kwh > 0 else 0.0
        off_peak_cost = total_cost - peak_cost

        return UsageBreakdownResponse(
            period=period,
            total_kwh=round(total_kwh, 3),
            peak_kwh=round(peak_kwh, 3),
            off_peak_kwh=round(off_peak_kwh, 3),
            estimated_cost_inr=round(total_cost, 2),
            potential_savings_inr=round(potential_savings, 2),
            peak_cost_inr=round(peak_cost, 2),
            off_peak_cost_inr=round(off_peak_cost, 2),
        )

    async def get_savings_tips(self, user_id: uuid.UUID) -> list[SavingsTipResponse]:
        account = await self._get_or_404(user_id)
        today = date.today()
        from_date = today - timedelta(days=30)
        summaries = await self.manager.get_usage_summaries(account.id, from_date, today)

        if not summaries:
            return [
                SavingsTipResponse(
                    rank=1,
                    title="Link your meter",
                    description="Connect your smart meter ID to start tracking usage in real time.",
                    estimated_savings_inr=0.0,
                )
            ]

        total_potential = sum(s.potential_savings_inr for s in summaries)
        peak_kwh = sum(s.peak_kwh for s in summaries)
        tips = []

        if peak_kwh > 0:
            tips.append(
                SavingsTipResponse(
                    rank=1,
                    title="Shift peak-hour usage to off-peak",
                    description=(
                        f"You used {round(peak_kwh, 1)} kWh during peak hours last 30 days. "
                        "Running appliances after 10 PM can cut costs significantly."
                    ),
                    estimated_savings_inr=round(total_potential * 0.6, 2),
                )
            )
        tips.append(
            SavingsTipResponse(
                rank=len(tips) + 1,
                title="Set a spending cap",
                description="Get instant alerts before your bill surprises you.",
                estimated_savings_inr=round(total_potential * 0.2, 2),
            )
        )
        tips.append(
            SavingsTipResponse(
                rank=len(tips) + 1,
                title="Review standby consumption",
                description="Devices on standby can account for 10% of your bill. Unplug when not in use.",
                estimated_savings_inr=round(total_potential * 0.2, 2),
            )
        )
        return tips[:3]

    # --- Internal: spending cap check (called by Celery task) ---

    async def check_and_fire_alerts(self, billing_account_id: uuid.UUID) -> None:
        account = await self.manager.get_by_id(billing_account_id)
        if not account:
            return
        cap = await self.manager.get_active_cap(billing_account_id)
        if not cap:
            return

        now = datetime.now(timezone.utc)
        month_spend = await self.manager.get_month_total_spend(
            billing_account_id, now.year, now.month
        )

        spend_pct = (month_spend / cap.monthly_cap_inr) * 100 if cap.monthly_cap_inr > 0 else 0

        if spend_pct >= 100:
            alert_type = AlertType.CAP_REACHED
        elif spend_pct >= cap.warning_threshold_pct:
            alert_type = AlertType.WARNING_THRESHOLD
        else:
            return

        # Deduplicate: only fire once per hour per alert type
        one_hour_ago = now - timedelta(hours=1)
        recent = await self.manager.get_recent_alert(billing_account_id, alert_type, one_hour_ago)
        if recent:
            return

        await self.manager.create_alert(
            billing_account_id=billing_account_id,
            alert_type=alert_type,
            triggered_at=now,
            current_spend_inr=month_spend,
            cap_inr=cap.monthly_cap_inr,
        )

    # --- Helpers ---

    async def _get_or_404(self, user_id: uuid.UUID) -> BillingAccount:
        account = await self.manager.get_by_user_id(user_id)
        if not account:
            raise NotFoundException("Billing account")
        return account

    @staticmethod
    def _period_to_dates(period: str) -> tuple[date, date]:
        today = date.today()
        if period == "today":
            return today, today
        if period == "week":
            return today - timedelta(days=7), today
        if period == "month":
            return today.replace(day=1), today
        # Default: current month
        return today.replace(day=1), today
