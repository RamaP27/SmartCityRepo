import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, field_validator

from shems.domains.billing.models import AlertType, NotificationChannel


# --- Billing Account ---

class BillingAccountCreate(BaseModel):
    utility_provider: str
    meter_reference: str | None = None
    billing_cycle_day: int = 1
    tariff_zone_id: uuid.UUID | None = None

    @field_validator("billing_cycle_day")
    @classmethod
    def validate_cycle_day(cls, v: int) -> int:
        if not 1 <= v <= 28:
            raise ValueError("billing_cycle_day must be between 1 and 28")
        return v


class BillingAccountUpdate(BaseModel):
    utility_provider: str | None = None
    meter_reference: str | None = None
    billing_cycle_day: int | None = None
    tariff_zone_id: uuid.UUID | None = None


class BillingAccountResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    user_id: uuid.UUID
    utility_provider: str
    meter_reference: str | None
    billing_cycle_day: int
    currency: str
    tariff_zone_id: uuid.UUID | None
    created_at: datetime


# --- Spending Cap ---

class SpendingCapCreate(BaseModel):
    monthly_cap_inr: float
    warning_threshold_pct: float = 80.0

    @field_validator("warning_threshold_pct")
    @classmethod
    def validate_threshold(cls, v: float) -> float:
        if not 1.0 <= v <= 99.0:
            raise ValueError("warning_threshold_pct must be between 1 and 99")
        return v

    @field_validator("monthly_cap_inr")
    @classmethod
    def validate_cap(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("monthly_cap_inr must be positive")
        return v


class SpendingCapResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    billing_account_id: uuid.UUID
    monthly_cap_inr: float
    warning_threshold_pct: float
    is_active: bool
    created_at: datetime


# --- Overage Alert ---

class OverageAlertResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    billing_account_id: uuid.UUID
    alert_type: AlertType
    triggered_at: datetime
    current_spend_inr: float
    cap_inr: float
    notification_sent: bool
    channel: NotificationChannel


# --- Usage ---

class UsageSummaryResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    billing_account_id: uuid.UUID
    period_date: date
    total_kwh: float
    peak_kwh: float
    off_peak_kwh: float
    estimated_cost_inr: float
    potential_savings_inr: float


class UsageBreakdownResponse(BaseModel):
    period: str
    total_kwh: float
    peak_kwh: float
    off_peak_kwh: float
    estimated_cost_inr: float
    potential_savings_inr: float
    peak_cost_inr: float
    off_peak_cost_inr: float


class SavingsTipResponse(BaseModel):
    rank: int
    title: str
    description: str
    estimated_savings_inr: float
