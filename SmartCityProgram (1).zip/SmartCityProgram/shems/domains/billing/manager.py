import uuid
from datetime import date, datetime

from sqlalchemy import and_, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from shems.domains.billing.models import (
    AlertType,
    BillingAccount,
    OverageAlert,
    SpendingCap,
    UsageSummary,
)


class BillingManager:
    def __init__(self, db: AsyncSession):
        self.db = db

    # --- Billing Account ---

    async def get_by_user_id(self, user_id: uuid.UUID) -> BillingAccount | None:
        result = await self.db.execute(
            select(BillingAccount).where(BillingAccount.user_id == user_id)
        )
        return result.scalar_one_or_none()

    async def get_by_id(self, account_id: uuid.UUID) -> BillingAccount | None:
        result = await self.db.execute(
            select(BillingAccount).where(BillingAccount.id == account_id)
        )
        return result.scalar_one_or_none()

    async def create_account(self, user_id: uuid.UUID, **kwargs) -> BillingAccount:
        account = BillingAccount(user_id=user_id, **kwargs)
        self.db.add(account)
        await self.db.commit()
        await self.db.refresh(account)
        return account

    async def update_account(self, account: BillingAccount, **kwargs) -> BillingAccount:
        for key, value in kwargs.items():
            if value is not None:
                setattr(account, key, value)
        await self.db.commit()
        await self.db.refresh(account)
        return account

    async def list_all_accounts(self) -> list[BillingAccount]:
        result = await self.db.execute(select(BillingAccount))
        return list(result.scalars().all())

    # --- Spending Cap ---

    async def get_active_cap(self, billing_account_id: uuid.UUID) -> SpendingCap | None:
        result = await self.db.execute(
            select(SpendingCap).where(
                SpendingCap.billing_account_id == billing_account_id,
                SpendingCap.is_active == True,  # noqa: E712
            )
        )
        return result.scalar_one_or_none()

    async def create_cap(self, billing_account_id: uuid.UUID, **kwargs) -> SpendingCap:
        # Deactivate existing caps first
        await self.db.execute(
            update(SpendingCap)
            .where(SpendingCap.billing_account_id == billing_account_id)
            .values(is_active=False)
        )
        cap = SpendingCap(billing_account_id=billing_account_id, **kwargs)
        self.db.add(cap)
        await self.db.commit()
        await self.db.refresh(cap)
        return cap

    async def deactivate_cap(self, cap_id: uuid.UUID) -> None:
        await self.db.execute(
            update(SpendingCap).where(SpendingCap.id == cap_id).values(is_active=False)
        )
        await self.db.commit()

    # --- Overage Alerts ---

    async def create_alert(self, billing_account_id: uuid.UUID, **kwargs) -> OverageAlert:
        alert = OverageAlert(billing_account_id=billing_account_id, **kwargs)
        self.db.add(alert)
        await self.db.commit()
        await self.db.refresh(alert)
        return alert

    async def get_recent_alert(
        self, billing_account_id: uuid.UUID, alert_type: AlertType, since: datetime
    ) -> OverageAlert | None:
        """Check if an alert of this type was already fired since `since`."""
        result = await self.db.execute(
            select(OverageAlert).where(
                and_(
                    OverageAlert.billing_account_id == billing_account_id,
                    OverageAlert.alert_type == alert_type,
                    OverageAlert.triggered_at >= since,
                )
            )
        )
        return result.scalar_one_or_none()

    async def list_alerts(
        self,
        billing_account_id: uuid.UUID,
        active_only: bool = False,
    ) -> list[OverageAlert]:
        filters = [OverageAlert.billing_account_id == billing_account_id]
        if active_only:
            filters.append(OverageAlert.notification_sent == False)  # noqa: E712
        result = await self.db.execute(
            select(OverageAlert)
            .where(and_(*filters))
            .order_by(OverageAlert.triggered_at.desc())
        )
        return list(result.scalars().all())

    # --- Usage Summaries ---

    async def get_usage_summaries(
        self,
        billing_account_id: uuid.UUID,
        from_date: date,
        to_date: date,
    ) -> list[UsageSummary]:
        result = await self.db.execute(
            select(UsageSummary)
            .where(
                and_(
                    UsageSummary.billing_account_id == billing_account_id,
                    UsageSummary.period_date >= from_date,
                    UsageSummary.period_date <= to_date,
                )
            )
            .order_by(UsageSummary.period_date)
        )
        return list(result.scalars().all())

    async def upsert_daily_summary(
        self, billing_account_id: uuid.UUID, period_date: date, **kwargs
    ) -> UsageSummary:
        result = await self.db.execute(
            select(UsageSummary).where(
                and_(
                    UsageSummary.billing_account_id == billing_account_id,
                    UsageSummary.period_date == period_date,
                )
            )
        )
        summary = result.scalar_one_or_none()
        if summary:
            for key, value in kwargs.items():
                setattr(summary, key, value)
        else:
            summary = UsageSummary(
                billing_account_id=billing_account_id,
                period_date=period_date,
                **kwargs,
            )
            self.db.add(summary)
        await self.db.commit()
        await self.db.refresh(summary)
        return summary

    async def get_month_total_spend(
        self, billing_account_id: uuid.UUID, year: int, month: int
    ) -> float:
        from sqlalchemy import extract
        result = await self.db.execute(
            select(func.coalesce(func.sum(UsageSummary.estimated_cost_inr), 0.0)).where(
                and_(
                    UsageSummary.billing_account_id == billing_account_id,
                    extract("year", UsageSummary.period_date) == year,
                    extract("month", UsageSummary.period_date) == month,
                )
            )
        )
        return float(result.scalar_one())
