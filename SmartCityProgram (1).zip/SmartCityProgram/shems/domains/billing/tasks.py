"""
Celery tasks for billing domain.

- check_spending_caps: runs every 15 minutes, checks all active caps and fires alerts
- compute_daily_usage_summaries: runs nightly, materializes UsageSummary from EnergyReading
"""
import asyncio
import logging
from datetime import date, datetime, timedelta, timezone

from shems.celery_app import celery_app

logger = logging.getLogger(__name__)


@celery_app.task(
    name="shems.domains.billing.tasks.check_spending_caps",
    bind=True,
    max_retries=3,
    default_retry_delay=60,
)
def check_spending_caps(self):
    """Check all active spending caps and fire overage alerts if thresholds are breached."""
    try:
        asyncio.run(_check_all_spending_caps())
    except Exception as exc:
        logger.error("check_spending_caps failed: %s", exc)
        raise self.retry(exc=exc)


async def _check_all_spending_caps():
    from shems.database import AsyncSessionLocal
    from shems.domains.billing.manager import BillingManager
    from shems.domains.billing.service import BillingService

    async with AsyncSessionLocal() as db:
        manager = BillingManager(db)
        service = BillingService(manager)
        accounts = await manager.list_all_accounts()
        logger.info("Checking spending caps for %d accounts", len(accounts))
        for account in accounts:
            try:
                await service.check_and_fire_alerts(account.id)
            except Exception as exc:
                logger.error(
                    "Failed to check cap for account %s: %s", account.id, exc
                )


@celery_app.task(
    name="shems.domains.billing.tasks.compute_daily_usage_summaries",
    bind=True,
    max_retries=3,
    default_retry_delay=300,
)
def compute_daily_usage_summaries(self):
    """Materialize yesterday's UsageSummary from EnergyReading for all billing accounts."""
    try:
        yesterday = date.today() - timedelta(days=1)
        asyncio.run(_compute_summaries_for_date(yesterday))
    except Exception as exc:
        logger.error("compute_daily_usage_summaries failed: %s", exc)
        raise self.retry(exc=exc)


async def _compute_summaries_for_date(target_date: date):
    from shems.database import AsyncSessionLocal
    from shems.domains.billing.manager import BillingManager
    from shems.domains.household.manager import HouseholdManager
    from sqlalchemy import and_, select, func
    from shems.domains.household.models import EnergyReading
    from shems.domains.billing.models import BillingAccount

    async with AsyncSessionLocal() as db:
        billing_manager = BillingManager(db)
        accounts = await billing_manager.list_all_accounts()

        from datetime import datetime, timezone
        day_start = datetime(target_date.year, target_date.month, target_date.day, tzinfo=timezone.utc)
        day_end = day_start + timedelta(days=1)

        for account in accounts:
            try:
                # Get household for this user
                from shems.domains.household.models import Household
                household_result = await db.execute(
                    select(Household).where(Household.user_id == account.user_id)
                )
                household = household_result.scalar_one_or_none()
                if not household:
                    continue

                # Aggregate readings for the day
                agg_result = await db.execute(
                    select(
                        func.coalesce(func.sum(EnergyReading.consumption_kwh), 0.0).label("total_kwh"),
                        func.coalesce(
                            func.sum(
                                EnergyReading.consumption_kwh.op("*")(
                                    EnergyReading.is_peak_hour.cast(__import__("sqlalchemy").Integer)
                                )
                            ), 0.0
                        ).label("peak_kwh"),
                        func.coalesce(func.sum(EnergyReading.cost_estimate_inr), 0.0).label("total_cost"),
                    ).where(
                        and_(
                            EnergyReading.household_id == household.id,
                            EnergyReading.timestamp >= day_start,
                            EnergyReading.timestamp < day_end,
                        )
                    )
                )
                row = agg_result.one()
                total_kwh = float(row.total_kwh)
                peak_kwh = float(row.peak_kwh)
                off_peak_kwh = total_kwh - peak_kwh
                total_cost = float(row.total_cost)

                # Potential savings: if peak usage had been charged at off-peak rate
                # Use a rough 40% discount assumption when tariff zone unknown
                potential_savings = peak_kwh * total_cost * 0.4 / total_kwh if total_kwh > 0 else 0.0

                await billing_manager.upsert_daily_summary(
                    billing_account_id=account.id,
                    period_date=target_date,
                    total_kwh=total_kwh,
                    peak_kwh=peak_kwh,
                    off_peak_kwh=off_peak_kwh,
                    estimated_cost_inr=total_cost,
                    potential_savings_inr=round(potential_savings, 2),
                )
            except Exception as exc:
                logger.error(
                    "Failed to compute summary for account %s on %s: %s",
                    account.id,
                    target_date,
                    exc,
                )
