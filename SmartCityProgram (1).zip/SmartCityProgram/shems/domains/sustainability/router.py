"""Sustainability domain API routes."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from shems.dependencies import get_current_user, get_db
from shems.domains.auth.models import User
from shems.domains.household.models import Household
from shems.domains.sustainability.schemas import (
    CarbonOffsetGoalCreate,
    CarbonOffsetGoalResponse,
    CarbonScoreResponse,
    SustainabilitySummaryResponse,
)
from shems.domains.sustainability.service import SustainabilityService
from shems.exceptions import ForbiddenException, NotFoundException

router = APIRouter(prefix="/sustainability", tags=["sustainability"])


async def _require_household(user: User, db: AsyncSession) -> uuid.UUID:
    result = await db.execute(
        select(Household.id).where(Household.user_id == user.id)
    )
    household_id = result.scalar_one_or_none()
    if not household_id:
        raise ForbiddenException("No household linked to this account")
    return household_id


@router.get("/me", response_model=SustainabilitySummaryResponse)
async def get_sustainability_summary(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Return latest score, active goal, cluster benchmark, and tips."""
    household_id = await _require_household(current_user, db)
    svc = SustainabilityService(db)
    return await svc.get_summary(household_id)


@router.get("/me/scores", response_model=list[CarbonScoreResponse])
async def get_score_history(
    limit: int = 12,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    household_id = await _require_household(current_user, db)
    svc = SustainabilityService(db)
    return await svc.get_score_history(household_id, limit=limit)


@router.post("/me/goals", response_model=CarbonOffsetGoalResponse, status_code=201)
async def create_goal(
    data: CarbonOffsetGoalCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    household_id = await _require_household(current_user, db)
    svc = SustainabilityService(db)
    return await svc.create_goal(household_id, data)


@router.delete("/me/goals/{goal_id}", response_model=CarbonOffsetGoalResponse)
async def cancel_goal(
    goal_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    household_id = await _require_household(current_user, db)
    svc = SustainabilityService(db)
    return await svc.cancel_goal(household_id, goal_id)
