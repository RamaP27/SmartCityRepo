"""
Sustainability domain service — business logic layer.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from shems.domains.sustainability.manager import SustainabilityManager
from shems.domains.sustainability.models import GoalStatus
from shems.domains.sustainability.schemas import (
    CarbonOffsetGoalCreate,
    SustainabilitySummaryResponse,
)
from shems.exceptions import NotFoundException


class SustainabilityService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.mgr = SustainabilityManager(db)

    async def get_summary(self, household_id: uuid.UUID) -> SustainabilitySummaryResponse:
        """Return latest score, active goal, cluster benchmark, and tips."""
        latest_score = await self.mgr.get_latest_score(household_id)
        goal = await self.mgr.get_active_goal(household_id)

        cluster_benchmark = None
        if latest_score:
            cluster_benchmark = await self.mgr.get_cluster_benchmark(
                latest_score.cluster_key
            )

        tips = self._tips_for_score(latest_score)

        return SustainabilitySummaryResponse(
            latest_score=latest_score,
            goal=goal,
            cluster_benchmark=cluster_benchmark,
            tips=tips,
        )

    async def get_score_history(
        self, household_id: uuid.UUID, limit: int = 12
    ):
        return await self.mgr.get_score_history(household_id, limit=limit)

    async def create_goal(
        self, household_id: uuid.UUID, data: CarbonOffsetGoalCreate
    ):
        goal = await self.mgr.create_goal(
            household_id=household_id,
            target_reduction_pct=data.target_reduction_pct,
            target_date=data.target_date,
            baseline_monthly_kwh=data.baseline_monthly_kwh,
        )
        await self.db.commit()
        await self.db.refresh(goal)
        return goal

    async def cancel_goal(self, household_id: uuid.UUID, goal_id: uuid.UUID):
        goal = await self.mgr.update_goal_status(goal_id, GoalStatus.CANCELLED)
        if not goal or goal.household_id != household_id:
            raise NotFoundException("Carbon offset goal not found")
        await self.db.commit()
        return goal

    # ── Helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _tips_for_score(score) -> list[str]:
        """Return actionable tips based on grade."""
        if score is None:
            return [
                "Start tracking your energy usage to get a sustainability score.",
                "Shift heavy appliances (washing machine, dishwasher) to off-peak hours.",
                "Set a carbon offset goal to stay motivated.",
            ]

        grade = score.grade
        if grade == "A+":
            return [
                "Outstanding! You are in the top 5% of your cluster.",
                "Consider sharing your practices with your community.",
                "Explore rooftop solar to go carbon-neutral.",
            ]
        if grade == "A":
            return [
                "Great efficiency! A small push to off-peak usage can get you to A+.",
                "Check if standby power accounts for >5% of your consumption.",
                "Smart power strips can cut phantom loads by up to 10%.",
            ]
        if grade == "B":
            return [
                "You are doing well. Try shifting AC usage to off-peak windows.",
                "Water heater timers can save 10-15% on heating costs.",
                "Enable eco-mode on all devices where available.",
            ]
        if grade == "C":
            return [
                "Review peak-hour appliance use — ToU tariffs make this costly.",
                "Check for energy leaks: old appliances can waste 20% more energy.",
                "Set a monthly budget goal to cut usage by 10%.",
            ]
        # grade D
        return [
            "Your consumption is significantly above your cluster average.",
            "Prioritise replacing any appliance rated below BEE 3-star.",
            "Consider an energy audit to identify the biggest savings opportunities.",
        ]
