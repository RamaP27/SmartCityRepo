import enum
import uuid
from datetime import datetime

from sqlalchemy import DateTime, Enum as SAEnum, Float, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from shems.database import Base, TimestampMixin


class GoalStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"
    ACHIEVED = "ACHIEVED"
    MISSED = "MISSED"
    CANCELLED = "CANCELLED"


class CarbonScore(Base, TimestampMixin):
    __tablename__ = "carbon_scores"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    household_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("households.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    period_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    period_end: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    total_kwh: Mapped[float] = mapped_column(Float, nullable=False)
    carbon_kg: Mapped[float] = mapped_column(Float, nullable=False)
    score: Mapped[float] = mapped_column(Float, nullable=False)   # 0–100
    grade: Mapped[str] = mapped_column(String(3), nullable=False)  # A+/A/B/C/D
    percentile_rank: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    cluster_key: Mapped[str] = mapped_column(String(30), nullable=False, default="")
    computed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class SustainabilityBenchmark(Base, TimestampMixin):
    __tablename__ = "sustainability_benchmarks"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    cluster_key: Mapped[str] = mapped_column(String(30), nullable=False, index=True)
    period_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    period_end: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    median_kwh: Mapped[float] = mapped_column(Float, nullable=False)
    p75_kwh: Mapped[float] = mapped_column(Float, nullable=False)
    sample_size: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    computed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class CarbonOffsetGoal(Base, TimestampMixin):
    __tablename__ = "carbon_offset_goals"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    household_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("households.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    target_reduction_pct: Mapped[float] = mapped_column(Float, nullable=False)
    target_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    baseline_monthly_kwh: Mapped[float] = mapped_column(Float, nullable=False)
    status: Mapped[GoalStatus] = mapped_column(
        SAEnum(GoalStatus, name="goalstatus"), nullable=False, default=GoalStatus.ACTIVE
    )
