"""Pydantic schemas for the sustainability domain."""
from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class CarbonScoreResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    household_id: uuid.UUID
    period_start: datetime
    period_end: datetime
    total_kwh: float
    carbon_kg: float
    score: float
    grade: str
    percentile_rank: float
    cluster_key: str
    computed_at: datetime


class CarbonOffsetGoalCreate(BaseModel):
    target_reduction_pct: float   # 1-99
    target_date: datetime
    baseline_monthly_kwh: float


class CarbonOffsetGoalResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    household_id: uuid.UUID
    target_reduction_pct: float
    target_date: datetime
    baseline_monthly_kwh: float
    status: str
    created_at: datetime


class SustainabilityBenchmarkResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    cluster_key: str
    period_start: datetime
    period_end: datetime
    median_kwh: float
    p75_kwh: float
    sample_size: int
    computed_at: datetime


class SustainabilitySummaryResponse(BaseModel):
    """Aggregated response for the /me/sustainability endpoint."""
    latest_score: CarbonScoreResponse | None
    goal: CarbonOffsetGoalResponse | None
    cluster_benchmark: SustainabilityBenchmarkResponse | None
    tips: list[str]
