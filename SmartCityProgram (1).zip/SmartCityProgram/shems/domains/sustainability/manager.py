"""
Sustainability domain data-access layer.

Manages CarbonScore, CarbonOffsetGoal, and SustainabilityBenchmark records.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import and_, desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from shems.domains.sustainability.models import (
    CarbonOffsetGoal,
    CarbonScore,
    GoalStatus,
    SustainabilityBenchmark,
)


class SustainabilityManager:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ── CarbonScore ──────────────────────────────────────────────────────────

    async def get_latest_score(self, household_id: uuid.UUID) -> CarbonScore | None:
        result = await self.db.execute(
            select(CarbonScore)
            .where(CarbonScore.household_id == household_id)
            .order_by(desc(CarbonScore.computed_at))
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def get_score_history(
        self, household_id: uuid.UUID, limit: int = 12
    ) -> list[CarbonScore]:
        result = await self.db.execute(
            select(CarbonScore)
            .where(CarbonScore.household_id == household_id)
            .order_by(desc(CarbonScore.computed_at))
            .limit(limit)
        )
        return list(result.scalars().all())

    async def upsert_score(
        self,
        household_id: uuid.UUID,
        period_start: datetime,
        period_end: datetime,
        total_kwh: float,
        carbon_kg: float,
        score: float,
        grade: str,
        percentile_rank: float,
        cluster_key: str,
    ) -> CarbonScore:
        """Insert or overwrite score for a given household+period_start."""
        result = await self.db.execute(
            select(CarbonScore).where(
                and_(
                    CarbonScore.household_id == household_id,
                    CarbonScore.period_start == period_start,
                )
            )
        )
        existing = result.scalar_one_or_none()
        if existing:
            existing.period_end = period_end
            existing.total_kwh = total_kwh
            existing.carbon_kg = carbon_kg
            existing.score = score
            existing.grade = grade
            existing.percentile_rank = percentile_rank
            existing.cluster_key = cluster_key
            existing.computed_at = datetime.now(timezone.utc)
            return existing

        obj = CarbonScore(
            household_id=household_id,
            period_start=period_start,
            period_end=period_end,
            total_kwh=total_kwh,
            carbon_kg=carbon_kg,
            score=score,
            grade=grade,
            percentile_rank=percentile_rank,
            cluster_key=cluster_key,
            computed_at=datetime.now(timezone.utc),
        )
        self.db.add(obj)
        return obj

    # ── CarbonOffsetGoal ─────────────────────────────────────────────────────

    async def get_active_goal(self, household_id: uuid.UUID) -> CarbonOffsetGoal | None:
        result = await self.db.execute(
            select(CarbonOffsetGoal).where(
                and_(
                    CarbonOffsetGoal.household_id == household_id,
                    CarbonOffsetGoal.status == GoalStatus.ACTIVE,
                )
            )
        )
        return result.scalar_one_or_none()

    async def create_goal(
        self,
        household_id: uuid.UUID,
        target_reduction_pct: float,
        target_date: datetime,
        baseline_monthly_kwh: float,
    ) -> CarbonOffsetGoal:
        # Deactivate existing active goal
        existing = await self.get_active_goal(household_id)
        if existing:
            existing.status = GoalStatus.CANCELLED

        goal = CarbonOffsetGoal(
            household_id=household_id,
            target_reduction_pct=target_reduction_pct,
            target_date=target_date,
            baseline_monthly_kwh=baseline_monthly_kwh,
            status=GoalStatus.ACTIVE,
        )
        self.db.add(goal)
        return goal

    async def update_goal_status(
        self, goal_id: uuid.UUID, status: GoalStatus
    ) -> CarbonOffsetGoal | None:
        result = await self.db.execute(
            select(CarbonOffsetGoal).where(CarbonOffsetGoal.id == goal_id)
        )
        goal = result.scalar_one_or_none()
        if goal:
            goal.status = status
        return goal

    # ── SustainabilityBenchmark ──────────────────────────────────────────────

    async def get_cluster_benchmark(
        self, cluster_key: str
    ) -> SustainabilityBenchmark | None:
        result = await self.db.execute(
            select(SustainabilityBenchmark)
            .where(SustainabilityBenchmark.cluster_key == cluster_key)
            .order_by(desc(SustainabilityBenchmark.computed_at))
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def upsert_benchmark(
        self,
        cluster_key: str,
        period_start: datetime,
        period_end: datetime,
        median_kwh: float,
        p75_kwh: float,
        sample_size: int,
    ) -> SustainabilityBenchmark:
        result = await self.db.execute(
            select(SustainabilityBenchmark).where(
                and_(
                    SustainabilityBenchmark.cluster_key == cluster_key,
                    SustainabilityBenchmark.period_start == period_start,
                )
            )
        )
        existing = result.scalar_one_or_none()
        if existing:
            existing.period_end = period_end
            existing.median_kwh = median_kwh
            existing.p75_kwh = p75_kwh
            existing.sample_size = sample_size
            existing.computed_at = datetime.now(timezone.utc)
            return existing

        obj = SustainabilityBenchmark(
            cluster_key=cluster_key,
            period_start=period_start,
            period_end=period_end,
            median_kwh=median_kwh,
            p75_kwh=p75_kwh,
            sample_size=sample_size,
            computed_at=datetime.now(timezone.utc),
        )
        self.db.add(obj)
        return obj
