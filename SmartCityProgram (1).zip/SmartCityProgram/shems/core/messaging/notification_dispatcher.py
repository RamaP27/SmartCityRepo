"""
Notification dispatcher — Firebase Cloud Messaging (push) + Twilio (SMS).

Design:
  - `NotificationDispatcher` is a singleton created at startup.
  - Firebase is used for Marcus (spending alerts) and Sarah (sustainability milestones).
  - Twilio SMS is used for Priya (critical grid alerts) and HIGH/CRITICAL anomalies.
  - Falls back gracefully when credentials are not configured (dev environment).

The dispatcher listens on the event bus:
  - OverageAlertTriggeredEvent     → push to Marcus
  - AnomalyDetectedEvent           → push to Sarah/Marcus; SMS if CRITICAL
  - DemandResponseTriggeredEvent   → SMS to Priya
  - SustainabilityMilestoneEvent   → push to Sarah
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

from shems.config import settings

logger = logging.getLogger(__name__)


@dataclass
class NotificationPayload:
    title: str
    body: str
    data: dict | None = None


class NotificationDispatcher:
    """Thin wrapper over Firebase Admin SDK and Twilio REST client."""

    _firebase_initialised = False

    def __init__(self):
        self._twilio_client = None
        self._init_firebase()
        self._init_twilio()

    def _init_firebase(self):
        if not settings.firebase_credentials_path:
            logger.info("NotificationDispatcher: Firebase not configured — push disabled")
            return
        try:
            import firebase_admin
            from firebase_admin import credentials

            if not firebase_admin._apps:
                cred = credentials.Certificate(settings.firebase_credentials_path)
                firebase_admin.initialize_app(cred)
            NotificationDispatcher._firebase_initialised = True
            logger.info("NotificationDispatcher: Firebase initialised")
        except Exception as exc:
            logger.error("NotificationDispatcher: Firebase init failed: %s", exc)

    def _init_twilio(self):
        if not settings.twilio_account_sid or not settings.twilio_auth_token:
            logger.info("NotificationDispatcher: Twilio not configured — SMS disabled")
            return
        try:
            from twilio.rest import Client

            self._twilio_client = Client(
                settings.twilio_account_sid, settings.twilio_auth_token
            )
            logger.info("NotificationDispatcher: Twilio initialised")
        except Exception as exc:
            logger.error("NotificationDispatcher: Twilio init failed: %s", exc)

    # ── Push notifications ────────────────────────────────────────────────────

    async def send_push(self, fcm_token: str, payload: NotificationPayload) -> bool:
        """Send a Firebase push notification to a single device token."""
        if not self._firebase_initialised:
            logger.debug("Push skipped (Firebase not configured): %s", payload.title)
            return False
        if not fcm_token:
            return False

        try:
            from firebase_admin import messaging

            message = messaging.Message(
                notification=messaging.Notification(
                    title=payload.title,
                    body=payload.body,
                ),
                data={k: str(v) for k, v in (payload.data or {}).items()},
                token=fcm_token,
            )
            messaging.send(message)
            logger.info("Push sent: %s → token=...%s", payload.title, fcm_token[-6:])
            return True
        except Exception as exc:
            logger.error("Push failed: %s", exc)
            return False

    # ── SMS ───────────────────────────────────────────────────────────────────

    async def send_sms(self, to_phone: str, body: str) -> bool:
        """Send an SMS via Twilio to an E.164 phone number."""
        if not self._twilio_client:
            logger.debug("SMS skipped (Twilio not configured): %s", body[:60])
            return False
        if not to_phone:
            return False

        try:
            message = self._twilio_client.messages.create(
                body=body,
                from_=settings.twilio_from_number,
                to=to_phone,
            )
            logger.info("SMS sent to %s SID=%s", to_phone, message.sid)
            return True
        except Exception as exc:
            logger.error("SMS failed to %s: %s", to_phone, exc)
            return False


# ── Singleton ─────────────────────────────────────────────────────────────────

_dispatcher: NotificationDispatcher | None = None


def get_dispatcher() -> NotificationDispatcher:
    global _dispatcher
    if _dispatcher is None:
        _dispatcher = NotificationDispatcher()
    return _dispatcher


# ── Event bus handlers ────────────────────────────────────────────────────────

def register_handlers():
    """
    Register all notification handlers on the event bus.
    Call once at application startup (in main.py lifespan).
    """
    from shems.core.events.event_bus import on
    from shems.core.events.event_types import (
        AnomalyDetectedEvent,
        DemandResponseTriggeredEvent,
        OverageAlertTriggeredEvent,
        SustainabilityMilestoneEvent,
    )

    @on(OverageAlertTriggeredEvent)
    async def handle_overage_alert(event: OverageAlertTriggeredEvent):
        disp = get_dispatcher()
        payload = NotificationPayload(
            title="⚡ Spending Alert",
            body=f"You've spent ₹{event.current_spend_inr:.0f} of your ₹{event.cap_inr:.0f} cap ({event.alert_type.replace('_', ' ').title()})",
            data={"type": "OVERAGE_ALERT", "billing_account_id": str(event.billing_account_id)},
        )
        # FCM token looked up from user's device registration (handled by frontend)
        # For now we log; production lookup would query a device_tokens table
        logger.info("OverageAlert event for user=%s — push payload ready", event.user_id)

    @on(AnomalyDetectedEvent)
    async def handle_anomaly(event: AnomalyDetectedEvent):
        disp = get_dispatcher()
        push_payload = NotificationPayload(
            title="🔍 Energy Anomaly Detected",
            body=f"Unusual consumption pattern detected — severity: {event.severity}",
            data={
                "type": "ANOMALY_ALERT",
                "severity": event.severity,
                "household_id": str(event.household_id),
            },
        )
        if event.user_fcm_token:
            await disp.send_push(event.user_fcm_token, push_payload)

        # SMS for CRITICAL anomalies
        if event.severity == "CRITICAL" and event.user_phone:
            await disp.send_sms(
                event.user_phone,
                f"SHEMS CRITICAL ALERT: Severe energy anomaly detected at your home. Score: {event.anomaly_score:.3f}. Check the SHEMS app immediately.",
            )

    @on(DemandResponseTriggeredEvent)
    async def handle_dr_triggered(event: DemandResponseTriggeredEvent):
        disp = get_dispatcher()
        utilization = (event.predicted_load_kw / event.peak_capacity_kw * 100) if event.peak_capacity_kw else 0
        if event.grid_manager_phone:
            await disp.send_sms(
                event.grid_manager_phone,
                f"SHEMS DR ALERT: Zone '{event.zone_name}' forecast at {utilization:.0f}% capacity "
                f"({event.predicted_load_kw:.0f}/{event.peak_capacity_kw:.0f} kW). "
                f"Auto-DR event {event.dr_event_id} triggered.",
            )

    @on(SustainabilityMilestoneEvent)
    async def handle_sustainability_milestone(event: SustainabilityMilestoneEvent):
        disp = get_dispatcher()
        improvement = event.new_score - event.previous_score
        push_payload = NotificationPayload(
            title="🌱 Sustainability Milestone!",
            body=f"Your score improved by {improvement:.1f} points → {event.new_score:.0f}/100 (Grade {event.grade})",
            data={
                "type": "SUSTAINABILITY_MILESTONE",
                "new_score": str(event.new_score),
                "grade": event.grade,
            },
        )
        if event.user_fcm_token:
            await disp.send_push(event.user_fcm_token, push_payload)
