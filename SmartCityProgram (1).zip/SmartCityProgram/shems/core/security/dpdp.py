"""
DPDP (Digital Personal Data Protection Act, 2023) compliance layer.

Three components:
  1. AuditLogMiddleware  — logs every API request with user_id, path, method, IP.
                           Writes to a structured JSONL file (rotated by the OS/logrotate).
  2. PIIMaskingFilter    — strips PII from log records before they reach any handler.
  3. DataRetentionManager — scheduled deletion of EnergyReadings older than retention_days.

Usage:
  app.add_middleware(AuditLogMiddleware)          # in main.py
  logging.root.addFilter(PIIMaskingFilter())      # in main.py lifespan

DPDP compliance notes:
  - No plaintext address stored (SHA-256 hash via household.address_hash).
  - Meter reading timestamps retained for settings.dpdp_data_retention_days (default 365).
  - All personal data access logged with requestor identity + timestamp.
  - Data deletion enforced by DataRetentionManager Celery task.
"""
from __future__ import annotations

import json
import logging
import re
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from shems.config import settings

logger = logging.getLogger(__name__)

# ── PII patterns to mask in logs ─────────────────────────────────────────────
_PII_PATTERNS = [
    (re.compile(r'"password"\s*:\s*"[^"]*"'), '"password": "***"'),
    (re.compile(r'"hashed_password"\s*:\s*"[^"]*"'), '"hashed_password": "***"'),
    (re.compile(r'"refresh_token"\s*:\s*"[^"]*"'), '"refresh_token": "***"'),
    (re.compile(r'"access_token"\s*:\s*"[^"]*"'), '"access_token": "***"'),
    (re.compile(r'"token_hash"\s*:\s*"[^"]*"'), '"token_hash": "***"'),
    # Phone numbers: +91XXXXXXXXXX or 10-digit
    (re.compile(r'\+91\d{10}'), '+91**********'),
    (re.compile(r'\b[6-9]\d{9}\b'), '**********'),
    # Email addresses
    (re.compile(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}'), '***@***.***'),
]


class PIIMaskingFilter(logging.Filter):
    """Logging filter that masks PII in log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            for pattern, replacement in _PII_PATTERNS:
                record.msg = pattern.sub(replacement, record.msg)
        if record.args:
            args = record.args
            if isinstance(args, tuple):
                masked = []
                for arg in args:
                    if isinstance(arg, str):
                        for pattern, replacement in _PII_PATTERNS:
                            arg = pattern.sub(replacement, arg)
                    masked.append(arg)
                record.args = tuple(masked)
        return True


# ── Audit log middleware ──────────────────────────────────────────────────────

class AuditLogMiddleware(BaseHTTPMiddleware):
    """
    Writes a JSONL audit record for every API request.
    Record fields:
      audit_id, timestamp, user_id, method, path, status_code,
      duration_ms, ip_address, user_agent
    """

    def __init__(self, app, log_path: str | None = None):
        super().__init__(app)
        self._log_path = Path(log_path or settings.dpdp_audit_log_path)
        self._log_path.parent.mkdir(parents=True, exist_ok=True)

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        start = time.perf_counter()
        user_id = None

        # Attempt to extract user_id from JWT without full validation
        # (full auth is handled by get_current_user dependency)
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            try:
                from shems.core.security.jwt_handler import decode_access_token
                token = auth_header.split(" ", 1)[1]
                payload = decode_access_token(token)
                user_id = payload.get("sub") if payload else None
            except Exception:
                pass

        response = await call_next(request)

        duration_ms = round((time.perf_counter() - start) * 1000, 1)

        # Skip health check from audit log
        if request.url.path == "/health":
            return response

        record = {
            "audit_id": str(uuid.uuid4()),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "user_id": user_id,
            "method": request.method,
            "path": request.url.path,
            "query": str(request.query_params) or None,
            "status_code": response.status_code,
            "duration_ms": duration_ms,
            "ip_address": request.client.host if request.client else None,
            "user_agent": request.headers.get("User-Agent", "")[:120],
        }

        try:
            with self._log_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except OSError as exc:
            logger.error("AuditLogMiddleware: write failed: %s", exc)

        return response


# ── Data retention manager ────────────────────────────────────────────────────

class DataRetentionManager:
    """
    Enforces DPDP data retention policy.
    Deletes EnergyReading and GridLoadReading rows older than retention_days.
    Called by a weekly Celery task.
    """

    def __init__(self, retention_days: int | None = None):
        self.retention_days = retention_days or settings.dpdp_data_retention_days

    async def purge_old_readings(self, db) -> dict[str, int]:
        """Delete readings older than retention_days. Returns counts per table."""
        from shems.domains.grid.models import GridLoadReading
        from shems.domains.household.models import EnergyReading
        from sqlalchemy import delete

        cutoff = datetime.now(timezone.utc) - timedelta(days=self.retention_days)

        energy_result = await db.execute(
            delete(EnergyReading).where(EnergyReading.timestamp < cutoff)
        )
        grid_result = await db.execute(
            delete(GridLoadReading).where(GridLoadReading.timestamp < cutoff)
        )

        await db.commit()

        counts = {
            "energy_readings_deleted": energy_result.rowcount,
            "grid_load_readings_deleted": grid_result.rowcount,
            "cutoff_date": cutoff.date().isoformat(),
        }
        logger.info(
            "DPDP data retention: deleted %d energy readings, %d grid readings (cutoff %s)",
            counts["energy_readings_deleted"],
            counts["grid_load_readings_deleted"],
            counts["cutoff_date"],
        )
        return counts

    async def purge_expired_sessions(self, db) -> int:
        """Delete expired auth sessions."""
        from shems.domains.auth.models import Session
        from sqlalchemy import delete

        now = datetime.now(timezone.utc)
        result = await db.execute(
            delete(Session).where(Session.expires_at < now)
        )
        await db.commit()
        count = result.rowcount
        logger.info("DPDP: purged %d expired sessions", count)
        return count

    async def anonymise_old_anomaly_alerts(self, db) -> int:
        """
        Nullify household_id on AnomalyAlert records older than 90 days
        (personal data minimisation).
        """
        from shems.domains.grid.models import AnomalyAlert
        from sqlalchemy import update

        cutoff = datetime.now(timezone.utc) - timedelta(days=90)
        result = await db.execute(
            update(AnomalyAlert)
            .where(
                AnomalyAlert.detected_at < cutoff,
                AnomalyAlert.household_id.is_not(None),
            )
            .values(household_id=None)
        )
        await db.commit()
        count = result.rowcount
        if count:
            logger.info("DPDP: anonymised %d old anomaly alert household IDs", count)
        return count
