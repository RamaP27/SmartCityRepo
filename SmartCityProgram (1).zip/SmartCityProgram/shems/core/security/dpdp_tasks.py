"""DPDP compliance Celery tasks."""
import asyncio
import logging

from shems.celery_app import celery_app
from shems.database import AsyncSessionLocal

logger = logging.getLogger(__name__)


@celery_app.task(name="shems.core.security.dpdp_tasks.run_data_retention", bind=True)
def run_data_retention(self):
    """Weekly DPDP data retention — delete old readings, purge sessions, anonymise alerts."""
    asyncio.run(_data_retention_inner())


async def _data_retention_inner():
    from shems.core.security.dpdp import DataRetentionManager

    async with AsyncSessionLocal() as db:
        mgr = DataRetentionManager()
        counts = await mgr.purge_old_readings(db)
        sessions_purged = await mgr.purge_expired_sessions(db)
        alerts_anonymised = await mgr.anonymise_old_anomaly_alerts(db)

        logger.info(
            "DPDP retention run complete: readings=%s sessions=%d alerts_anonymised=%d",
            counts, sessions_purged, alerts_anonymised,
        )
