import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class BaseEvent:
    event_id: uuid.UUID = field(default_factory=uuid.uuid4)
    occurred_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ── Phase 1 events ────────────────────────────────────────────────────────────

@dataclass
class OverageAlertTriggeredEvent(BaseEvent):
    billing_account_id: uuid.UUID = field(default_factory=uuid.uuid4)
    user_id: uuid.UUID = field(default_factory=uuid.uuid4)
    current_spend_inr: float = 0.0
    cap_inr: float = 0.0
    alert_type: str = "WARNING_THRESHOLD"


@dataclass
class MeterReadingReceivedEvent(BaseEvent):
    household_id: uuid.UUID = field(default_factory=uuid.uuid4)
    consumption_kwh: float = 0.0
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ── Phase 3 events ────────────────────────────────────────────────────────────

@dataclass
class AnomalyDetectedEvent(BaseEvent):
    """Fired when IsolationForest flags a household reading as anomalous."""
    household_id: uuid.UUID = field(default_factory=uuid.uuid4)
    zone_id: uuid.UUID = field(default_factory=uuid.uuid4)
    user_id: uuid.UUID = field(default_factory=uuid.uuid4)
    anomaly_score: float = 0.0
    severity: str = "LOW"
    # Push notification fields
    user_fcm_token: str = ""
    user_phone: str = ""


@dataclass
class DemandResponseTriggeredEvent(BaseEvent):
    """Fired when auto-DR triggers at 85% zone capacity forecast."""
    zone_id: uuid.UUID = field(default_factory=uuid.uuid4)
    zone_name: str = ""
    predicted_load_kw: float = 0.0
    peak_capacity_kw: float = 0.0
    dr_event_id: uuid.UUID = field(default_factory=uuid.uuid4)
    # Priya's contact details for SMS alert
    grid_manager_phone: str = ""


@dataclass
class SustainabilityMilestoneEvent(BaseEvent):
    """Fired when a household improves their sustainability score by 5+ points."""
    household_id: uuid.UUID = field(default_factory=uuid.uuid4)
    user_id: uuid.UUID = field(default_factory=uuid.uuid4)
    previous_score: float = 0.0
    new_score: float = 0.0
    grade: str = "B"
    user_fcm_token: str = ""


@dataclass
class DeviceScheduleExecutedEvent(BaseEvent):
    """Fired after a device schedule is successfully automated."""
    household_id: uuid.UUID = field(default_factory=uuid.uuid4)
    device_id: uuid.UUID = field(default_factory=uuid.uuid4)
    device_name: str = ""
    action: str = "on"
    scheduled_reason: str = "OFF_PEAK_AUTO"
