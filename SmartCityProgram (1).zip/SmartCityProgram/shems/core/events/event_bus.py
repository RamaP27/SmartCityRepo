import asyncio
import logging
from collections import defaultdict
from typing import Callable

logger = logging.getLogger(__name__)

_handlers: dict[type, list[Callable]] = defaultdict(list)


def on(event_type: type):
    """Decorator to register an async handler for an event type."""
    def decorator(func: Callable):
        _handlers[event_type].append(func)
        return func
    return decorator


async def publish(event):
    event_type = type(event)
    handlers = _handlers.get(event_type, [])
    if not handlers:
        return
    results = await asyncio.gather(
        *[handler(event) for handler in handlers],
        return_exceptions=True,
    )
    for result in results:
        if isinstance(result, Exception):
            logger.error("Event handler error for %s: %s", event_type.__name__, result)
